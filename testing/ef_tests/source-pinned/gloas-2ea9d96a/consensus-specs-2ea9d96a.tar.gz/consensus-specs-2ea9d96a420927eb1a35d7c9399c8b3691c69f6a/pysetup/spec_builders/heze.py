from pysetup.constants import HEZE

from .base import BaseSpecBuilder


class HezeSpecBuilder(BaseSpecBuilder):
    fork: str = HEZE

    @classmethod
    def imports(cls, preset_name: str):
        return f"""
from eth_consensus_specs.gloas import {preset_name} as gloas
"""

    @classmethod
    def sundry_functions(cls) -> str:
        return """
def cached_or_new_inclusion_list_store() -> InclusionListStore:
    return InclusionListStore(
        inclusion_lists=defaultdict(dict),
        equivocators=defaultdict(set),
    )
"""

    @classmethod
    def execution_engine_cls(cls) -> str:
        return """
class NoopExecutionEngine(ExecutionEngine):

    def notify_new_payload(self: ExecutionEngine,
                           execution_payload: ExecutionPayload,
                           parent_beacon_block_root: Root,
                           execution_requests_list: Sequence[bytes]) -> bool:
        return True

    def notify_forkchoice_updated(self: ExecutionEngine,
                                  head_block_hash: Hash32,
                                  safe_block_hash: Hash32,
                                  finalized_block_hash: Hash32,
                                  payload_attributes: PayloadAttributes | None,
                                  custody_columns: CustodyColumnBits | None) -> PayloadId | None:
        pass

    def get_payload(self: ExecutionEngine, payload_id: PayloadId) -> GetPayloadResponse:
        raise NotImplementedError("no default block production")

    def is_valid_block_hash(self: ExecutionEngine,
                            execution_payload: ExecutionPayload,
                            parent_beacon_block_root: Root,
                            execution_requests_list: Sequence[bytes]) -> bool:
        return True

    def is_valid_versioned_hashes(self: ExecutionEngine, new_payload_request: NewPayloadRequest) -> bool:
        return True

    def verify_and_notify_new_payload(self: ExecutionEngine,
                                      new_payload_request: NewPayloadRequest) -> bool:
        return True

    def get_inclusion_list(self: ExecutionEngine) -> GetInclusionListResponse:
        raise NotImplementedError("no default inclusion list production")

    def is_inclusion_list_satisfied(self: ExecutionEngine,
                                    execution_payload: ExecutionPayload,
                                    inclusion_list_transactions: Sequence[Transaction]) -> bool:
        return True


EXECUTION_ENGINE = NoopExecutionEngine()"""

    @classmethod
    def deprecate_functions(cls) -> set[str]:
        return {
            "initialize_ptc_window",
            "is_candidate_block",
            "onboard_builders_from_pending_deposits",
            "process_eth1_data",
            "process_eth1_data_reset",
            "upgrade_to_gloas",
            "voting_period_start_time",
        }
