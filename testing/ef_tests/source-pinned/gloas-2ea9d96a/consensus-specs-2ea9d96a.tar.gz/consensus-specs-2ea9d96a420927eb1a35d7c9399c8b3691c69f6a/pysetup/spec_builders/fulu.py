from pysetup.constants import FULU

from .base import BaseSpecBuilder


class FuluSpecBuilder(BaseSpecBuilder):
    fork: str = FULU

    @classmethod
    def imports(cls, preset_name: str):
        return f"""
from frozendict import frozendict
from eth_consensus_specs.electra import {preset_name} as electra
"""

    @classmethod
    def deprecate_config_vars(cls) -> set[str]:
        return {
            "BLOB_SIDECAR_SUBNET_COUNT_ELECTRA",
        }

    @classmethod
    def deprecate_containers(cls) -> set[str]:
        return {
            "BlobIdentifier",
            "BlobSidecar",
            "KZGCommitmentInclusionProof",
        }

    @classmethod
    def deprecate_functions(cls) -> set[str]:
        return {
            "apply_deposit",
            "compute_max_request_blob_sidecars",
            "compute_subnet_for_blob_sidecar",
            "get_blob_sidecars",
            "get_eth1_pending_deposit_count",
            "get_eth1_vote",
            "is_shuffling_stable",
            "process_deposit",
            "upgrade_to_electra",
            "validate_blob_sidecar_gossip",
            "verify_blob_sidecar_inclusion_proof",
        }

    @classmethod
    def sundry_functions(cls) -> str:
        return """
def retrieve_column_sidecars(beacon_block_root: Root) -> Sequence[DataColumnSidecar]:
    return []
"""

    @classmethod
    def hardcoded_func_dep_presets(cls, spec_object) -> dict[str, str]:
        return {
            "KZG_COMMITMENTS_INCLUSION_PROOF_DEPTH": spec_object.preset_vars[
                "KZG_COMMITMENTS_INCLUSION_PROOF_DEPTH"
            ].value,
        }
