from pysetup.constants import BELLATRIX

from .base import BaseSpecBuilder


class BellatrixSpecBuilder(BaseSpecBuilder):
    fork: str = BELLATRIX

    @classmethod
    def imports(cls, preset_name: str):
        return f"""
from typing import Protocol
from eth_consensus_specs.altair import {preset_name} as altair
from ssz.byte_arrays import ByteList, ByteVector
from eth_consensus_specs.utils.ssz.bytes import Bytes8
"""

    @classmethod
    def sundry_functions(cls) -> str:
        return """
ExecutionState = Any


def get_pow_block(hash: Hash32) -> PowBlock | None:
    return PowBlock(block_hash=hash, parent_hash=Hash32(), total_difficulty=Uint256(0))


def validator_is_connected(validator_index: ValidatorIndex) -> bool:
    return True"""

    @classmethod
    def execution_engine_cls(cls) -> str:
        return """
class NoopExecutionEngine(ExecutionEngine):

    def notify_new_payload(self: ExecutionEngine, execution_payload: ExecutionPayload) -> bool:
        return True

    def notify_forkchoice_updated(self: ExecutionEngine,
                                  head_block_hash: Hash32,
                                  safe_block_hash: Hash32,
                                  finalized_block_hash: Hash32,
                                  payload_attributes: PayloadAttributes | None) -> PayloadId | None:
        pass

    def get_payload(self: ExecutionEngine, payload_id: PayloadId) -> GetPayloadResponse:
        raise NotImplementedError("no default block production")

    def is_valid_block_hash(self: ExecutionEngine, execution_payload: ExecutionPayload) -> bool:
        return True

    def verify_and_notify_new_payload(self: ExecutionEngine,
                                      new_payload_request: NewPayloadRequest) -> bool:
        return True


EXECUTION_ENGINE = NoopExecutionEngine()"""

    @classmethod
    def deprecate_functions(cls) -> set[str]:
        return {
            "translate_participation",
            "upgrade_to_altair",
        }
