from pysetup.constants import ELECTRA

from .base import BaseSpecBuilder


class ElectraSpecBuilder(BaseSpecBuilder):
    fork: str = ELECTRA

    @classmethod
    def imports(cls, preset_name: str):
        return f"""
from eth_consensus_specs.deneb import {preset_name} as deneb
"""

    @classmethod
    def hardcoded_ssz_dep_constants(cls) -> dict[str, str]:
        return {
            "FINALIZED_ROOT_GINDEX_ELECTRA": "GeneralizedIndex(169)",
            "CURRENT_SYNC_COMMITTEE_GINDEX_ELECTRA": "GeneralizedIndex(86)",
            "NEXT_SYNC_COMMITTEE_GINDEX_ELECTRA": "GeneralizedIndex(87)",
        }

    @classmethod
    def deprecate_config_vars(cls) -> set[str]:
        return {
            "BLOB_SIDECAR_SUBNET_COUNT",
            "MAX_BLOBS_PER_BLOCK",
            "MAX_PER_EPOCH_ACTIVATION_CHURN_LIMIT",
        }

    @classmethod
    def deprecate_functions(cls) -> set[str]:
        return {
            "get_validator_activation_churn_limit",
            "upgrade_lc_bootstrap_to_deneb",
            "upgrade_lc_finality_update_to_deneb",
            "upgrade_lc_header_to_deneb",
            "upgrade_lc_optimistic_update_to_deneb",
            "upgrade_lc_store_to_deneb",
            "upgrade_lc_update_to_deneb",
            "upgrade_to_deneb",
        }

    @classmethod
    def execution_engine_cls(cls) -> str:
        return """
class NoopExecutionEngine(ExecutionEngine):

    def notify_new_payload(self: ExecutionEngine,
                           execution_payload: ExecutionPayload,
                           parent_beacon_block_root: Root,
                           execution_requests_list: Sequence[bytes]) -> bool:
        return True

    def notify_forkchoice_updated(self: ExecutionEngine,
                                  head_block_hash: Hash32,
                                  safe_block_hash: Hash32,
                                  finalized_block_hash: Hash32,
                                  payload_attributes: PayloadAttributes | None) -> PayloadId | None:
        pass

    def get_payload(self: ExecutionEngine, payload_id: PayloadId) -> GetPayloadResponse:
        raise NotImplementedError("no default block production")

    def is_valid_block_hash(self: ExecutionEngine,
                            execution_payload: ExecutionPayload,
                            parent_beacon_block_root: Root,
                            execution_requests_list: Sequence[bytes]) -> bool:
        return True

    def is_valid_versioned_hashes(self: ExecutionEngine, new_payload_request: NewPayloadRequest) -> bool:
        return True

    def verify_and_notify_new_payload(self: ExecutionEngine,
                                      new_payload_request: NewPayloadRequest) -> bool:
        return True


EXECUTION_ENGINE = NoopExecutionEngine()"""
