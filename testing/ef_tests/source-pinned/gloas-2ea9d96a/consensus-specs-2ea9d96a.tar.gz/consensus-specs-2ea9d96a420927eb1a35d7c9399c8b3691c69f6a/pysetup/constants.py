# Definitions in context.py
PHASE0 = "phase0"
ALTAIR = "altair"
BELLATRIX = "bellatrix"
CAPELLA = "capella"
DENEB = "deneb"
ELECTRA = "electra"
FULU = "fulu"
GLOAS = "gloas"
HEZE = "heze"
EIP7716 = "eip7716"
EIP8025 = "eip8025"
EIP8148 = "eip8148"
EIP8198 = "eip8198"
EIP8205 = "eip8205"
EIP8321 = "eip8321"


# The helper functions that are used when defining constants
CONSTANT_DEP_SUNDRY_CONSTANTS_FUNCTIONS = """
def ceillog2(x: int) -> Uint64:
    if x < 1:
        raise ValueError(f"ceillog2 accepts only positive values, x={x}")
    return Uint64((x - 1).bit_length())


def floorlog2(x: int) -> Uint64:
    if x < 1:
        raise ValueError(f"floorlog2 accepts only positive values, x={x}")
    return Uint64(x.bit_length() - 1)
"""


OPTIMIZED_BLS_AGGREGATE_PUBKEYS = """
def eth_aggregate_pubkeys(pubkeys: Sequence[BLSPubkey]) -> BLSPubkey:
    return bls.AggregatePKs(pubkeys)
"""
