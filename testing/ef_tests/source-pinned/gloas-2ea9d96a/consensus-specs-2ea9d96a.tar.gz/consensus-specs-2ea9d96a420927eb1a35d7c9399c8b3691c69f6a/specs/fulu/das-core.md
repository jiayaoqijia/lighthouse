# Fulu -- Data Availability Sampling Core

<!-- mdformat-toc start --slug=github --no-anchors --maxlevel=6 --minlevel=2 -->

- [Types](#types)
  - [`Cell`](#cell)
  - [`CellIndex`](#cellindex)
  - [`Cells`](#cells)
  - [`ColumnIndex`](#columnindex)
  - [`CustodyIndex`](#custodyindex)
  - [`DataColumn`](#datacolumn)
  - [`KZGCommitmentsInclusionProof`](#kzgcommitmentsinclusionproof)
  - [`Proofs`](#proofs)
  - [`RowIndex`](#rowindex)
- [Constants](#constants)
  - [Misc](#misc)
- [Presets](#presets)
  - [Blob](#blob)
  - [Size parameters](#size-parameters)
- [Configs](#configs)
  - [Custody setting](#custody-setting)
- [Containers](#containers)
  - [`DataColumnSidecar`](#datacolumnsidecar)
  - [`MatrixEntry`](#matrixentry)
- [Helpers](#helpers)
  - [`get_custody_groups`](#get_custody_groups)
  - [`compute_columns_for_custody_group`](#compute_columns_for_custody_group)
  - [`compute_matrix`](#compute_matrix)
  - [`recover_matrix`](#recover_matrix)
- [Custody](#custody)
  - [Custody requirement](#custody-requirement)
  - [Public, deterministic selection](#public-deterministic-selection)
- [Custody sampling](#custody-sampling)
- [Extended data](#extended-data)
- [Column gossip](#column-gossip)
  - [Parameters](#parameters)
- [Reconstruction and cross-seeding](#reconstruction-and-cross-seeding)
- [FAQs](#faqs)
  - [Why don't nodes custody rows?](#why-dont-nodes-custody-rows)
  - [Why don't we rotate custody over time?](#why-dont-we-rotate-custody-over-time)
  - [Does having a lot of column subnets make the network unstable?](#does-having-a-lot-of-column-subnets-make-the-network-unstable)

<!-- mdformat-toc end -->

## Types

### `Cell`

```python
class Cell(ByteVector):
    """
    The unit of extended blob data that has its own ``KZGProof``.
    """

    LENGTH = BYTES_PER_FIELD_ELEMENT * FIELD_ELEMENTS_PER_CELL
```

### `CellIndex`

```python
class CellIndex(Uint64):
    """
    The index of a cell within an extended blob.
    """
```

### `Cells`

```python
class Cells(Vector[Cell]):
    """
    The cells of a single extended blob.
    """

    LENGTH = CELLS_PER_EXT_BLOB
```

### `ColumnIndex`

```python
class ColumnIndex(Uint64):
    """
    The index of a column in the matrix of extended blob data.
    """
```

### `CustodyIndex`

```python
class CustodyIndex(Uint64):
    """
    The index of a custody group.
    """
```

### `DataColumn`

```python
class DataColumn(List[Cell]):
    """
    A column of the extended blob data matrix, with at most one cell per blob.
    """

    LIMIT = MAX_BLOB_COMMITMENTS_PER_BLOCK
```

### `KZGCommitmentsInclusionProof`

```python
class KZGCommitmentsInclusionProof(Vector[Bytes32]):
    """
    A Merkle branch proving a block's blob KZG commitments within
    ``BeaconBlockBody``.
    """

    LENGTH = KZG_COMMITMENTS_INCLUSION_PROOF_DEPTH
```

### `Proofs`

```python
class Proofs(Vector[KZGProof]):
    """
    The KZG proofs for the cells of a single extended blob.
    """

    LENGTH = CELLS_PER_EXT_BLOB
```

### `RowIndex`

```python
class RowIndex(Uint64):
    """
    The index of a row in the matrix of extended blob data.
    """
```

## Constants

The following values are (non-configurable) constants used throughout the
specification.

### Misc

| Name          | Value                 |
| ------------- | --------------------- |
| `UINT256_MAX` | `Uint256(2**256 - 1)` |

## Presets

### Blob

| Name                          | Value                                                    | Description                                              |
| ----------------------------- | -------------------------------------------------------- | -------------------------------------------------------- |
| `FIELD_ELEMENTS_PER_EXT_BLOB` | `2 * FIELD_ELEMENTS_PER_BLOB`                            | Number of field elements in a Reed-Solomon extended blob |
| `FIELD_ELEMENTS_PER_CELL`     | `Uint64(64)`                                             | Number of field elements in a cell                       |
| `CELLS_PER_EXT_BLOB`          | `FIELD_ELEMENTS_PER_EXT_BLOB // FIELD_ELEMENTS_PER_CELL` | The number of cells in an extended blob                  |

### Size parameters

| Name                | Value                                | Description                                   |
| ------------------- | ------------------------------------ | --------------------------------------------- |
| `NUMBER_OF_COLUMNS` | `Uint64(CELLS_PER_EXT_BLOB)` (= 128) | Number of columns in the extended data matrix |

## Configs

### Custody setting

| Name                       | Value         | Description                                                                       |
| -------------------------- | ------------- | --------------------------------------------------------------------------------- |
| `SAMPLES_PER_SLOT`         | `Uint64(8)`   | Minimum number of samples for an honest node                                      |
| `NUMBER_OF_CUSTODY_GROUPS` | `Uint64(128)` | Number of custody groups available for nodes to custody                           |
| `CUSTODY_REQUIREMENT`      | `Uint64(4)`   | Minimum number of custody groups an honest node custodies and serves samples from |

## Containers

### `DataColumnSidecar`

```python
class DataColumnSidecar(Container):
    index: ColumnIndex
    column: DataColumn
    kzg_commitments: BlobKZGCommitments
    kzg_proofs: KZGProofs
    signed_block_header: SignedBeaconBlockHeader
    kzg_commitments_inclusion_proof: KZGCommitmentsInclusionProof
```

### `MatrixEntry`

```python
class MatrixEntry(Container):
    cell: Cell
    kzg_proof: KZGProof
    column_index: ColumnIndex
    row_index: RowIndex
```

## Helpers

### `get_custody_groups`

```python
def get_custody_groups(node_id: NodeID, custody_group_count: Uint64) -> Sequence[CustodyIndex]:
    assert custody_group_count <= NUMBER_OF_CUSTODY_GROUPS

    # Skip computation if all groups are custodied
    if custody_group_count == NUMBER_OF_CUSTODY_GROUPS:
        return [CustodyIndex(index) for index in range(NUMBER_OF_CUSTODY_GROUPS)]

    current_id = Uint256(node_id)
    custody_groups: list[CustodyIndex] = []
    while len(custody_groups) < custody_group_count:
        custody_group = CustodyIndex(
            bytes_to_uint64(sha256(uint_to_bytes(current_id))[0:8]) % NUMBER_OF_CUSTODY_GROUPS
        )
        if custody_group not in custody_groups:
            custody_groups.append(custody_group)
        if current_id == UINT256_MAX:
            # Overflow prevention
            current_id = Uint256(0)
        else:
            current_id += 1

    assert len(custody_groups) == len(set(custody_groups))
    return sorted(custody_groups)
```

### `compute_columns_for_custody_group`

```python
def compute_columns_for_custody_group(custody_group: CustodyIndex) -> Sequence[ColumnIndex]:
    assert custody_group < NUMBER_OF_CUSTODY_GROUPS
    columns_per_group = NUMBER_OF_COLUMNS // NUMBER_OF_CUSTODY_GROUPS
    return [
        ColumnIndex(NUMBER_OF_CUSTODY_GROUPS * index + custody_group)
        for index in range(columns_per_group)
    ]
```

### `compute_matrix`

```python
def compute_matrix(blobs: Sequence[Blob]) -> Sequence[MatrixEntry]:
    """
    Return the full, flattened sequence of matrix entries.

    This helper demonstrates the relationship between blobs and the matrix of cells/proofs.
    The data structure for storing cells/proofs is implementation-dependent.
    """
    matrix = []
    for blob_index, blob in enumerate(blobs):
        cells, proofs = kzg.compute_cells_and_kzg_proofs(blob)
        for cell_index, (cell, proof) in enumerate(zip(cells, proofs, strict=True)):
            matrix.append(
                MatrixEntry(
                    cell=cell,
                    kzg_proof=proof,
                    column_index=ColumnIndex(cell_index),
                    row_index=RowIndex(blob_index),
                )
            )
    return matrix
```

*Note*: The function `kzg.compute_cells_and_kzg_proofs` is defined in
[cryptography-specs](https://github.com/ethereum/cryptography-specs) with the
following signature:

<!-- eth_consensus_specs: skip -->

```python
def compute_cells_and_kzg_proofs(blob: Blob) -> tuple[Cells, Proofs]:
    """
    Extend ``blob`` and return all the cells and proofs of the extended blob.
    """
```

### `recover_matrix`

```python
def recover_matrix(
    partial_matrix: Sequence[MatrixEntry], blob_count: Uint64
) -> Sequence[MatrixEntry]:
    """
    Recover the full, flattened sequence of matrix entries.

    This helper demonstrates how to apply ``kzg.recover_cells_and_kzg_proofs``.
    The data structure for storing cells/proofs is implementation-dependent.
    """
    matrix = []
    for blob_index in range(blob_count):
        cell_indices = [e.column_index for e in partial_matrix if e.row_index == blob_index]
        cells = [e.cell for e in partial_matrix if e.row_index == blob_index]
        recovered_cells, recovered_proofs = kzg.recover_cells_and_kzg_proofs(cell_indices, cells)
        for cell_index, (cell, proof) in enumerate(
            zip(recovered_cells, recovered_proofs, strict=True)
        ):
            matrix.append(
                MatrixEntry(
                    cell=cell,
                    kzg_proof=proof,
                    column_index=ColumnIndex(cell_index),
                    row_index=RowIndex(blob_index),
                )
            )
    return matrix
```

*Note*: The function `kzg.recover_cells_and_kzg_proofs` is defined in
[cryptography-specs](https://github.com/ethereum/cryptography-specs) with the
following signature:

<!-- eth_consensus_specs: skip -->

```python
def recover_cells_and_kzg_proofs(
    cell_indices: Sequence[CellIndex], cells: Sequence[Cell]
) -> tuple[Cells, Proofs]:
    """
    Recover all the cells and proofs of an extended blob given at least half of
    its cells.
    """
```

## Custody

### Custody requirement

Columns are grouped into custody groups. Nodes custodying a custody group MUST
custody all the columns in that group. When syncing, a node MUST backfill
columns from all of its custody groups.

A node *may* choose to custody and serve more than the minimum honesty
requirement. Such a node explicitly advertises a number greater than
`CUSTODY_REQUIREMENT` through the peer discovery mechanism, specifically by
setting a higher value in the `custody_group_count` field within its ENR. This
value can be increased up to `NUMBER_OF_CUSTODY_GROUPS`, indicating a super-full
node.

A node stores the custodied columns for the duration of the pruning period and
responds to peer requests for samples on those columns.

### Public, deterministic selection

The particular columns/groups that a node custodies are selected pseudo-randomly
as a function (`get_custody_groups`) of the node-id and custody size --
importantly this function can be run by any party as the inputs are all public.

*Note*: Increasing the `custody_size` parameter for a given `node_id` extends
the returned list (rather than being an entirely new shuffle) such that if
`custody_size` is unknown, the default `CUSTODY_REQUIREMENT` will be correct for
a subset of the node's custody.

## Custody sampling

At each slot, a node advertising `custody_group_count` downloads a minimum of
`sampling_size = max(SAMPLES_PER_SLOT, custody_group_count)` custody groups,
selected by `groups = get_custody_groups(node_id, sampling_size)`, to which
correspond the columns
`compute_columns_for_custody_group(group) for group in groups`. The custody
groups to custody, selected by
`get_custody_groups(node_id, custody_group_count)`, are then in particular a
subset of those to sample. Sampling is considered successful if the node manages
to retrieve all selected columns.

## Extended data

In this construction, we extend the blobs using a one-dimensional erasure coding
extension. The matrix comprises maximum `MAX_BLOBS_PER_BLOCK` rows and fixed
`NUMBER_OF_COLUMNS` columns, with each row containing a `Blob` and its
corresponding extension. `compute_matrix` demonstrates the relationship between
blobs and the matrix, a potential method of storing cells/proofs.

## Column gossip

### Parameters

Verifiable samples from their respective column are distributed on the assigned
subnet. To custody columns in a particular custody group, a node joins the
respective gossipsub subnets. If a node fails to get columns on the column
subnets, a node can also utilize the Req/Resp protocol to query the missing
columns from other peers.

## Reconstruction and cross-seeding

If the node obtains 50%+ of all the columns, it SHOULD reconstruct the full data
matrix via the `recover_matrix` helper. Nodes MAY delay this reconstruction
allowing time for other columns to arrive over the network. If delaying
reconstruction, nodes may use a random delay in order to desynchronize
reconstruction among nodes, thus reducing overall CPU load.

Once the node obtains a column through reconstruction, the node MUST expose the
new column as if it had received it over the network. If the node is subscribed
to the subnet corresponding to the column, it MUST send the reconstructed
`DataColumnSidecar` to its topic mesh neighbors. If instead the node is not
subscribed to the corresponding subnet, it SHOULD still expose the availability
of the `DataColumnSidecar` as part of the gossip emission process. After
exposing the reconstructed `DataColumnSidecar` to the network, the node MAY
delete the `DataColumnSidecar` if it is not part of the node's custody
requirement.

*Note*: A node always maintains a matrix view of the rows and columns they are
following, able to cross-reference and cross-seed in either direction.

*Note*: There are timing considerations to analyze -- at what point does a node
consider samples missing and choose to reconstruct and cross-seed.

*Note*: There may be anti-DoS and quality-of-service considerations around how
to send samples and consider samples -- is each individual sample a message or
are they sent in aggregate forms.

## FAQs

### Why don't nodes custody rows?

In the one-dimensional construction, a node samples the peers by requesting the
whole `DataColumnSidecar`. In reconstruction, a node can reconstruct all the
blobs by 50% of the columns. Note that nodes can still download the row via
`blob_sidecar_{subnet_id}` subnets.

The potential benefits of having row custody could include:

1. Allow for more "natural" distribution of data to consumers -- e.g., roll-ups
   -- but realistically, they won't know a priori which row their blob is going
   to be included in the block, so they would either need to listen to all rows
   or download a particular row after seeing the block. The former looks just
   like listening to column \[0, N) and the latter is req/resp instead of
   gossiping.
2. Help with some sort of distributed reconstruction. Those with full rows can
   compute extensions and seed missing samples to the network. This would either
   need to be able to send individual points on the gossip or would need some
   sort of req/resp faculty, potentially similar to an `IHAVEPOINTBITFIELD` and
   `IWANTSAMPLE`.

However, for simplicity, we don't assign row custody assignments to nodes in the
current design.

### Why don't we rotate custody over time?

To start with a simple, stable backbone, for now, we don't shuffle the custody
assignments via the deterministic custody selection helper `get_custody_groups`.
However, staggered rotation likely needs to happen on the order of the pruning
period to ensure subnets can be utilized for recovery. For example, introducing
an `epoch` argument allows the function to maintain stability over many epochs.

### Does having a lot of column subnets make the network unstable?

No, the number of subnets doesn't really matter. What matters to the network
stability is the number of nodes and the churn rate in the network. If the
number of the nodes is too low, it's likely to have a network partition when
some nodes are down. For the churn rate, if the churn rate is high, we even need
to have a higher number of nodes, since nodes are likely to be turned off more
often.
