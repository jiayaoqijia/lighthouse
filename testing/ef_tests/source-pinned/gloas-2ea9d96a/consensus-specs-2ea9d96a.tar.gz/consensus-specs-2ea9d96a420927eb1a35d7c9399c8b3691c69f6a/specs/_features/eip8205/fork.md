# EIP-8205 -- Fork Logic

*Note*: This document is a work-in-progress for researchers and implementers.

<!-- mdformat-toc start --slug=github --no-anchors --maxlevel=6 --minlevel=2 -->

- [Introduction](#introduction)
- [Configs](#configs)
- [Fork to EIP-8205](#fork-to-eip-8205)

<!-- mdformat-toc end -->

## Introduction

This document describes the process of the EIP-8205 upgrade.

## Configs

Warning: this configuration is not definitive.

| Name                   | Value                                 |
| ---------------------- | ------------------------------------- |
| `EIP8205_FORK_VERSION` | `Version("0xe8205000")`               |
| `EIP8205_FORK_EPOCH`   | `Epoch(18446744073709551615)` **TBD** |

## Fork to EIP-8205

If `state.slot % SLOTS_PER_EPOCH == 0` and
`compute_epoch_at_slot(state.slot) == EIP8205_FORK_EPOCH`, an irregular state
change is made to upgrade to EIP-8205.

The upgrade occurs after the completion of the inner loop of `process_slots`
that sets `state.slot` equal to `EIP8205_FORK_EPOCH * SLOTS_PER_EPOCH`.

The empty list is correct for a standalone activation: no historical execution
layer request can pre-populate the new field.

*Note*: `latest_execution_payload_bid` is copied unchanged. Its
`execution_requests_root` may commit to the pre-fork `ExecutionRequests` type,
whose root differs from the extended type even for identical content; the
upgrade cannot recompute it because the state stores only the commitment. The
coordinated upgrade that activates this feature must define how the first
post-fork block validates a full pre-fork parent.

```python
def upgrade_to_eip8205(pre: heze.BeaconState) -> BeaconState:
    epoch = heze.get_current_epoch(pre)
    post = BeaconState(
        genesis_time=pre.genesis_time,
        genesis_validators_root=pre.genesis_validators_root,
        slot=pre.slot,
        fork=Fork(
            previous_version=pre.fork.current_version,
            # [New in EIP8205]
            current_version=EIP8205_FORK_VERSION,
            epoch=epoch,
        ),
        latest_block_header=pre.latest_block_header,
        block_roots=pre.block_roots,
        state_roots=pre.state_roots,
        historical_roots=pre.historical_roots,
        validators=pre.validators,
        balances=pre.balances,
        randao_mixes=pre.randao_mixes,
        slashings=pre.slashings,
        previous_epoch_participation=pre.previous_epoch_participation,
        current_epoch_participation=pre.current_epoch_participation,
        justification_bits=pre.justification_bits,
        previous_justified_checkpoint=pre.previous_justified_checkpoint,
        current_justified_checkpoint=pre.current_justified_checkpoint,
        finalized_checkpoint=pre.finalized_checkpoint,
        inactivity_scores=pre.inactivity_scores,
        current_sync_committee=pre.current_sync_committee,
        next_sync_committee=pre.next_sync_committee,
        latest_block_hash=pre.latest_block_hash,
        next_withdrawal_index=pre.next_withdrawal_index,
        next_withdrawal_validator_index=pre.next_withdrawal_validator_index,
        historical_summaries=pre.historical_summaries,
        deposit_balance_to_consume=pre.deposit_balance_to_consume,
        exit_balance_to_consume=pre.exit_balance_to_consume,
        earliest_exit_epoch=pre.earliest_exit_epoch,
        consolidation_balance_to_consume=pre.consolidation_balance_to_consume,
        earliest_consolidation_epoch=pre.earliest_consolidation_epoch,
        pending_deposits=pre.pending_deposits,
        pending_partial_withdrawals=pre.pending_partial_withdrawals,
        pending_consolidations=pre.pending_consolidations,
        proposer_lookahead=pre.proposer_lookahead,
        builders=pre.builders,
        next_withdrawal_builder_index=pre.next_withdrawal_builder_index,
        execution_payload_availability=pre.execution_payload_availability,
        builder_pending_payments=pre.builder_pending_payments,
        builder_pending_withdrawals=pre.builder_pending_withdrawals,
        latest_execution_payload_bid=pre.latest_execution_payload_bid,
        payload_expected_withdrawals=pre.payload_expected_withdrawals,
        ptc_window=pre.ptc_window,
        # [New in EIP8205]
        validator_preregistrations=ValidatorPreregistrations(),
    )

    return post
```
