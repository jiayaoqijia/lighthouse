# EIP-8025 -- Networking

This document contains the networking specifications for EIP-8025.

*Note*: This specification is built upon [Gloas](../../gloas/p2p-interface.md)
and imports proof types from [beacon-chain.md](./beacon-chain.md).

EIP-8025 proofs propagate exclusively through gossip. No EIP-8025-specific
Req/Resp protocol is defined.

## Table of contents

<!-- mdformat-toc start --slug=github --no-anchors --maxlevel=6 --minlevel=2 -->

- [Table of contents](#table-of-contents)
- [Constants](#constants)
  - [Type-specific SSZ bounds](#type-specific-ssz-bounds)
- [Helpers](#helpers)
  - [Modified `Seen`](#modified-seen)
- [The gossip domain: gossipsub](#the-gossip-domain-gossipsub)
  - [Topics and messages](#topics-and-messages)
    - [Global topics](#global-topics)
      - [New `execution_proof`](#new-execution_proof)
- [The discovery domain: discv5](#the-discovery-domain-discv5)
  - [ENR structure](#enr-structure)
    - [Execution proof awareness](#execution-proof-awareness)

<!-- mdformat-toc end -->

## Constants

### Type-specific SSZ bounds

| Name                                       | Value             |
| ------------------------------------------ | ----------------- |
| `MAX_SIGNED_EXECUTION_PROOF_ENVELOPE_SIZE` | `Uint64(4194449)` |

## Helpers

### Modified `Seen`

```python
@dataclass
class Seen:
    proposer_slots: set[tuple[Slot, ValidatorIndex]]
    aggregator_epochs: set[tuple[Epoch, ValidatorIndex]]
    aggregate_data_roots: dict[tuple[Root, CommitteeIndex], set[tuple[bool, ...]]]
    voluntary_exit_indices: set[ValidatorIndex]
    proposer_slashing_indices: set[ValidatorIndex]
    attester_slashing_indices: set[ValidatorIndex]
    attestation_validator_epochs: set[tuple[Epoch, ValidatorIndex]]
    sync_contribution_aggregator_slots: set[tuple[Slot, ValidatorIndex, Uint64]]
    sync_contribution_data: dict[tuple[Slot, Root, Uint64], set[tuple[bool, ...]]]
    sync_message_validator_slots: set[tuple[Slot, ValidatorIndex, Uint64]]
    bls_to_execution_change_indices: set[ValidatorIndex]
    data_column_sidecar_tuples: set[tuple[Root, ColumnIndex]]
    execution_payloads: dict[Hash32, ExecutionPayload]
    execution_payload_envelopes: set[tuple[Root, BuilderIndex]]
    payload_attestation_validators: set[tuple[Slot, ValidatorIndex]]
    execution_payload_bid_counts: Counter[tuple[Slot, Hash32, Root, BuilderIndex]]
    best_execution_payload_bid: dict[tuple[Slot, Hash32, Root], Gwei]
    proposer_preferences: dict[tuple[Slot, Root], ProposerPreferences]
    # [New in EIP8025]
    execution_proof_roots: dict[Root, set[Root]]
    # [New in EIP8025]
    execution_proof_provers: set[tuple[Root, ProofType, ValidatorIndex]]
```

## The gossip domain: gossipsub

### Topics and messages

#### Global topics

##### New `execution_proof`

This topic is used to propagate `SignedExecutionProofEnvelope` messages.

```python
def validate_execution_proof_gossip(
    seen: Seen,
    store: Store,
    signed_proof_envelope: SignedExecutionProofEnvelope,
    proof_engine: ProofEngine,
) -> None:
    """
    Validate a SignedExecutionProofEnvelope for gossip propagation.
    Raises GossipIgnore or GossipReject on validation failure.
    """
    proof_envelope = signed_proof_envelope.message

    # [REJECT] The proof data is non-empty
    if len(proof_envelope.proof_data) == 0:
        raise GossipReject("execution proof is empty")

    # [REJECT] The proof type is supported
    if proof_envelope.proof_type not in get_supported_proof_types():
        raise GossipReject("unexpected execution proof type")

    beacon_block_root = proof_envelope.beacon_block_root

    # [IGNORE] The proof's beacon block has been seen
    if beacon_block_root not in store.blocks:
        raise GossipIgnore("execution proof's beacon block has not been seen")

    # [IGNORE] No valid proof is known for this beacon block and proof type
    if proof_envelope.proof_type in store.execution_proofs.get(beacon_block_root, {}):
        raise GossipIgnore("verified proof already known for this beacon block and proof type")

    proof_root = hash_tree_root(proof_envelope)

    # [IGNORE] The proof has not already been processed
    if proof_root in seen.execution_proof_roots.get(beacon_block_root, set()):
        raise GossipIgnore("execution proof has already been processed")

    # [IGNORE] This is the prover's first valid or invalid proof for this key
    validator_index = signed_proof_envelope.validator_index
    prover_key = (beacon_block_root, proof_envelope.proof_type, validator_index)
    if prover_key in seen.execution_proof_provers:
        raise GossipIgnore(
            "proof already seen from this prover for this beacon block and proof type"
        )

    # [IGNORE] The proof's execution payload is available
    if beacon_block_root not in store.payloads:
        raise GossipIgnore("execution proof's payload is unavailable")

    state = store.block_states[beacon_block_root]
    payload_envelope = store.payloads[beacon_block_root]

    # [REJECT] The execution proof envelope passes validation
    try:
        verify_execution_proof_envelope(state, signed_proof_envelope)
    except AssertionError:
        raise GossipReject("execution proof envelope is invalid") from None

    proof = get_execution_proof(
        state,
        proof_envelope,
        payload_envelope,
    )

    # Mark the authenticated proof and prover attempt as seen
    if beacon_block_root not in seen.execution_proof_roots:
        seen.execution_proof_roots[beacon_block_root] = set()
    seen.execution_proof_roots[beacon_block_root].add(proof_root)
    seen.execution_proof_provers.add(prover_key)

    # [REJECT] The execution proof is valid
    if not proof_engine.verify_execution_proof(proof):
        raise GossipReject("execution proof is invalid")
```

## The discovery domain: discv5

### ENR structure

#### Execution proof awareness

A new field is added to the ENR under the key `eproof` to facilitate discovery
and peering between nodes that participate in execution-proof gossip.

| Key      | Value                                    |
| -------- | ---------------------------------------- |
| `eproof` | Execution layer proof awareness, `Uint8` |

A node is considered execution proof-aware if the `eproof` key is present and
its value is not `0`. An execution proof-aware node subscribes to the
`execution_proof` gossip topic and implements its validation rules. Clients MAY
prefer execution proof-aware nodes when selecting peers for execution-proof
gossip.
