# Gloas Light Client -- Networking

<!-- mdformat-toc start --slug=github --no-anchors --maxlevel=6 --minlevel=2 -->

- [Networking](#networking)
  - [The gossip domain: gossipsub](#the-gossip-domain-gossipsub)
    - [Topics and messages](#topics-and-messages)
      - [Global topics](#global-topics)
        - [Modified `light_client_finality_update`](#modified-light_client_finality_update)
        - [Modified `light_client_optimistic_update`](#modified-light_client_optimistic_update)
  - [The Req/Resp domain](#the-reqresp-domain)
    - [Messages](#messages)
      - [GetLightClientBootstrap](#getlightclientbootstrap)
      - [LightClientUpdatesByRange](#lightclientupdatesbyrange)
      - [GetLightClientFinalityUpdate](#getlightclientfinalityupdate)
      - [GetLightClientOptimisticUpdate](#getlightclientoptimisticupdate)

<!-- mdformat-toc end -->

## Networking

The
[Electra light client networking specification](../../electra/light-client/p2p-interface.md)
is extended to exchange [Gloas light client data](./sync-protocol.md).

### The gossip domain: gossipsub

#### Topics and messages

##### Global topics

###### Modified `light_client_finality_update`

<!-- eth_consensus_specs: skip -->

| `fork_version`                                         | Message SSZ type                    |
| ------------------------------------------------------ | ----------------------------------- |
| `GENESIS_FORK_VERSION`                                 | n/a                                 |
| `ALTAIR_FORK_VERSION` through `BELLATRIX_FORK_VERSION` | `altair.LightClientFinalityUpdate`  |
| `CAPELLA_FORK_VERSION`                                 | `capella.LightClientFinalityUpdate` |
| `DENEB_FORK_VERSION`                                   | `deneb.LightClientFinalityUpdate`   |
| `ELECTRA_FORK_VERSION` through `FULU_FORK_VERSION`     | `electra.LightClientFinalityUpdate` |
| `GLOAS_FORK_VERSION` and later                         | `gloas.LightClientFinalityUpdate`   |

###### Modified `light_client_optimistic_update`

<!-- eth_consensus_specs: skip -->

| `fork_version`                                         | Message SSZ type                      |
| ------------------------------------------------------ | ------------------------------------- |
| `GENESIS_FORK_VERSION`                                 | n/a                                   |
| `ALTAIR_FORK_VERSION` through `BELLATRIX_FORK_VERSION` | `altair.LightClientOptimisticUpdate`  |
| `CAPELLA_FORK_VERSION`                                 | `capella.LightClientOptimisticUpdate` |
| `DENEB_FORK_VERSION`                                   | `deneb.LightClientOptimisticUpdate`   |
| `ELECTRA_FORK_VERSION` through `FULU_FORK_VERSION`     | `electra.LightClientOptimisticUpdate` |
| `GLOAS_FORK_VERSION` and later                         | `gloas.LightClientOptimisticUpdate`   |

### The Req/Resp domain

#### Messages

##### GetLightClientBootstrap

<!-- eth_consensus_specs: skip -->

| `fork_version`                                         | Response SSZ type              |
| ------------------------------------------------------ | ------------------------------ |
| `GENESIS_FORK_VERSION`                                 | n/a                            |
| `ALTAIR_FORK_VERSION` through `BELLATRIX_FORK_VERSION` | `altair.LightClientBootstrap`  |
| `CAPELLA_FORK_VERSION`                                 | `capella.LightClientBootstrap` |
| `DENEB_FORK_VERSION`                                   | `deneb.LightClientBootstrap`   |
| `ELECTRA_FORK_VERSION` through `FULU_FORK_VERSION`     | `electra.LightClientBootstrap` |
| `GLOAS_FORK_VERSION` and later                         | `gloas.LightClientBootstrap`   |

##### LightClientUpdatesByRange

<!-- eth_consensus_specs: skip -->

| `fork_version`                                         | Response chunk SSZ type     |
| ------------------------------------------------------ | --------------------------- |
| `GENESIS_FORK_VERSION`                                 | n/a                         |
| `ALTAIR_FORK_VERSION` through `BELLATRIX_FORK_VERSION` | `altair.LightClientUpdate`  |
| `CAPELLA_FORK_VERSION`                                 | `capella.LightClientUpdate` |
| `DENEB_FORK_VERSION`                                   | `deneb.LightClientUpdate`   |
| `ELECTRA_FORK_VERSION` through `FULU_FORK_VERSION`     | `electra.LightClientUpdate` |
| `GLOAS_FORK_VERSION` and later                         | `gloas.LightClientUpdate`   |

##### GetLightClientFinalityUpdate

<!-- eth_consensus_specs: skip -->

| `fork_version`                                         | Response SSZ type                   |
| ------------------------------------------------------ | ----------------------------------- |
| `GENESIS_FORK_VERSION`                                 | n/a                                 |
| `ALTAIR_FORK_VERSION` through `BELLATRIX_FORK_VERSION` | `altair.LightClientFinalityUpdate`  |
| `CAPELLA_FORK_VERSION`                                 | `capella.LightClientFinalityUpdate` |
| `DENEB_FORK_VERSION`                                   | `deneb.LightClientFinalityUpdate`   |
| `ELECTRA_FORK_VERSION` through `FULU_FORK_VERSION`     | `electra.LightClientFinalityUpdate` |
| `GLOAS_FORK_VERSION` and later                         | `gloas.LightClientFinalityUpdate`   |

##### GetLightClientOptimisticUpdate

<!-- eth_consensus_specs: skip -->

| `fork_version`                                         | Response SSZ type                     |
| ------------------------------------------------------ | ------------------------------------- |
| `GENESIS_FORK_VERSION`                                 | n/a                                   |
| `ALTAIR_FORK_VERSION` through `BELLATRIX_FORK_VERSION` | `altair.LightClientOptimisticUpdate`  |
| `CAPELLA_FORK_VERSION`                                 | `capella.LightClientOptimisticUpdate` |
| `DENEB_FORK_VERSION`                                   | `deneb.LightClientOptimisticUpdate`   |
| `ELECTRA_FORK_VERSION` through `FULU_FORK_VERSION`     | `electra.LightClientOptimisticUpdate` |
| `GLOAS_FORK_VERSION` and later                         | `gloas.LightClientOptimisticUpdate`   |
