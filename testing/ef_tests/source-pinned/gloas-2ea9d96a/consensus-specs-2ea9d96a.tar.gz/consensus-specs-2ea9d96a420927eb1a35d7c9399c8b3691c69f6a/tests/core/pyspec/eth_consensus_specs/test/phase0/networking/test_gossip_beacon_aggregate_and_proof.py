from eth_consensus_specs.test.context import (
    always_bls,
    default_activation_threshold,
    single_phase,
    spec_state_test,
    spec_test,
    with_all_phases,
    with_all_phases_from_to,
    with_custom_state,
    with_presets,
)
from eth_consensus_specs.test.helpers.attestations import (
    get_valid_attestation,
    sign_attestation,
)
from eth_consensus_specs.test.helpers.block import (
    build_empty_block_for_next_slot,
)
from eth_consensus_specs.test.helpers.constants import (
    DENEB,
    MAINNET,
    PHASE0,
)
from eth_consensus_specs.test.helpers.fork_choice import (
    get_genesis_forkchoice_store_and_block,
)
from eth_consensus_specs.test.helpers.forks import is_post_electra, is_post_gloas
from eth_consensus_specs.test.helpers.gossip import (
    get_filename,
    get_seen,
    run_validate_gossip,
    wrap_genesis_block,
)
from eth_consensus_specs.test.helpers.keys import privkeys
from eth_consensus_specs.test.helpers.state import (
    next_slot,
    state_transition_and_sign_block,
)


def large_validator_balances(spec):
    """
    Create enough validators to have committees with >= 32 members,
    so that there's a chance of non-aggregators (modulo >= 2).
    """
    num_validators = 32 * spec.SLOTS_PER_EPOCH
    return [spec.MAX_EFFECTIVE_BALANCE] * num_validators


def create_signed_aggregate_and_proof(spec, state, attestation, aggregator_index=None):
    """
    Create a valid SignedAggregateAndProof for the given attestation.
    """
    committee = spec.get_beacon_committee(state, attestation.data.slot, attestation.data.index)

    if aggregator_index is None:
        for index in committee:
            privkey = privkeys[index]
            selection_proof = spec.get_slot_signature(state, attestation.data.slot, privkey)
            if spec.is_aggregator(
                state, attestation.data.slot, attestation.data.index, selection_proof
            ):
                aggregator_index = index
                break

        if aggregator_index is None:
            aggregator_index = committee[0]

    privkey = privkeys[aggregator_index]
    aggregate_and_proof = spec.get_aggregate_and_proof(
        state, aggregator_index, attestation, privkey
    )
    signature = spec.get_aggregate_and_proof_signature(state, aggregate_and_proof, privkey)

    return spec.SignedAggregateAndProof(
        message=aggregate_and_proof,
        signature=signature,
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__valid(spec, state):
    """
    Test that a valid aggregate and proof passes gossip validation.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "valid"
    assert reason is None

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "valid",
            }
        ],
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__reject_committee_index_out_of_range(spec, state):
    """
    Test that an aggregate with committee index out of range is rejected.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    # Modify committee index to be out of range
    committee_count = spec.get_committee_count_per_slot(state, attestation.data.target.epoch)
    if is_post_electra(spec):
        # In Electra the committee index moved into ``committee_bits`` and
        # ``data.index`` must remain zero; encode an OOB index in committee_bits
        # at the smallest position that is both out-of-range and inside the bitvector.
        assert committee_count < spec.MAX_COMMITTEES_PER_SLOT
        oob_index = committee_count
        signed_agg.message.aggregate.committee_bits = spec.CommitteeBits(
            data=[i == oob_index for i in range(spec.MAX_COMMITTEES_PER_SLOT)]
        )
    else:
        signed_agg.message.aggregate.data.index = committee_count + 10

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "committee index out of range"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases_from_to(PHASE0, DENEB)
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__ignore_slot_not_within_range(spec, state):
    """
    Test that an aggregate from a slot too far in the future is ignored.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    yield get_filename(signed_agg), signed_agg

    # Set current time to be before the attestation's slot (too far in future)
    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)
    current_time_ms -= spec.config.MAXIMUM_GOSSIP_CLOCK_DISPARITY + 1

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "ignore"
    assert reason == "attestation slot not within propagation range"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "ignore",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__valid_within_clock_disparity(spec, state):
    """
    Test that an aggregate at exactly the clock disparity boundary is valid.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    yield get_filename(signed_agg), signed_agg

    # Set current time to exactly the boundary (should still be valid)
    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)
    current_time_ms -= spec.config.MAXIMUM_GOSSIP_CLOCK_DISPARITY

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "valid"
    assert reason is None

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "valid",
            }
        ],
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__reject_epoch_mismatch(spec, state):
    """
    Test that an aggregate whose epoch doesn't match target is rejected.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    # Modify target epoch to not match slot epoch
    signed_agg.message.aggregate.data.target.epoch = spec.Epoch(100)

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "attestation epoch does not match target epoch"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__ignore_already_seen_aggregate(spec, state):
    """
    Test that a duplicate aggregate data root is ignored.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    messages = []
    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    # First validation should pass
    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "valid"
    messages.append(
        {
            "current_time_ms": int(current_time_ms),
            "message": get_filename(signed_agg),
            "expected": "valid",
        }
    )

    # Second validation should be ignored (already seen aggregate data)
    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 100
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "ignore"
    assert reason == "already seen aggregate for this data"
    messages.append(
        {
            "current_time_ms": int(current_time_ms),
            "message": get_filename(signed_agg),
            "expected": "ignore",
            "reason": reason,
        }
    )

    yield "messages", "meta", messages


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__ignore_same_data_root_without_superset(spec, state):
    """
    Test that dedup does not trigger for the same aggregate data root unless
    a prior aggregate has a non-strict superset of aggregation bits.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    messages = []
    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(
        spec,
        state,
        signed=True,
        beacon_block_root=anchor_root,
        filter_participant_set=lambda participants: {min(participants)},
    )
    signed_agg_1 = create_signed_aggregate_and_proof(spec, state, attestation)

    yield get_filename(signed_agg_1), signed_agg_1

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    # First validation should pass and seed dedup state.
    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg_1,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "valid"
    assert reason is None
    messages.append(
        {
            "current_time_ms": int(current_time_ms),
            "message": get_filename(signed_agg_1),
            "expected": "valid",
        }
    )

    # Build a second, fully-signed aggregate for the same data whose bits are a
    # superset of (hence not a subset of) the first, so dedup cannot trigger.
    # Aggregate it under the same aggregator so only the aggregator-uniqueness
    # rule can produce the ignore. Building and signing with the final bits keeps
    # the inner and outer signatures valid, so the result is order-independent.
    assert len(signed_agg_1.message.aggregate.aggregation_bits) > 1, (
        "Need committee size > 1 for this test"
    )
    attestation_2 = get_valid_attestation(
        spec,
        state,
        signed=True,
        beacon_block_root=anchor_root,
        filter_participant_set=lambda participants: set(sorted(participants)[:2]),
    )
    signed_agg_2 = create_signed_aggregate_and_proof(
        spec, state, attestation_2, aggregator_index=signed_agg_1.message.aggregator_index
    )

    yield get_filename(signed_agg_2), signed_agg_2

    # Dedup should not trigger here; the ignore result is from the aggregator
    # uniqueness rule because aggregator/epoch are unchanged.
    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 100
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg_2,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "ignore"
    assert reason == "already seen aggregate for this epoch and aggregator"
    messages.append(
        {
            "current_time_ms": int(current_time_ms),
            "message": get_filename(signed_agg_2),
            "expected": "ignore",
            "reason": reason,
        }
    )

    yield "messages", "meta", messages


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__valid_two_aggregators_same_data(spec, state):
    """
    Test that two valid aggregates with the same data root but from different
    aggregators both pass validation (covering the case where aggregate_data_root
    is already in seen.aggregate_data_roots).
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    messages = []
    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    # Create two attestations with different single-participant aggregation bits
    # so neither is a superset of the other
    att_1 = get_valid_attestation(
        spec,
        state,
        signed=True,
        beacon_block_root=anchor_root,
        filter_participant_set=lambda participants: {min(participants)},
    )
    att_2 = get_valid_attestation(
        spec,
        state,
        signed=True,
        beacon_block_root=anchor_root,
        filter_participant_set=lambda participants: {sorted(participants)[1]},
    )
    committee = spec.get_beacon_committee(state, att_1.data.slot, att_1.data.index)

    # Find two different aggregators in the same committee
    aggregators = []
    for index in committee:
        privkey = privkeys[index]
        selection_proof = spec.get_slot_signature(state, att_1.data.slot, privkey)
        if spec.is_aggregator(state, att_1.data.slot, att_1.data.index, selection_proof):
            aggregators.append(index)
            if len(aggregators) == 2:
                break
    assert len(aggregators) == 2, "Need at least two aggregators in the committee"

    signed_agg_1 = create_signed_aggregate_and_proof(
        spec, state, att_1, aggregator_index=aggregators[0]
    )
    signed_agg_2 = create_signed_aggregate_and_proof(
        spec, state, att_2, aggregator_index=aggregators[1]
    )

    yield get_filename(signed_agg_1), signed_agg_1
    yield get_filename(signed_agg_2), signed_agg_2

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, att_1.data.slot)

    # First aggregate should pass
    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg_1,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "valid"
    assert reason is None
    messages.append(
        {
            "current_time_ms": int(current_time_ms),
            "message": get_filename(signed_agg_1),
            "expected": "valid",
        }
    )

    # Second aggregate (different aggregator, same data root) should also pass
    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 100
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg_2,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "valid"
    assert reason is None
    messages.append(
        {
            "current_time_ms": int(current_time_ms),
            "message": get_filename(signed_agg_2),
            "expected": "valid",
        }
    )

    yield "messages", "meta", messages


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__ignore_block_not_seen(spec, state):
    """
    Test that an aggregate for an unseen block is ignored.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    # Build and apply a block (but don't add to store)
    block = build_empty_block_for_next_slot(spec, state)
    signed_block = state_transition_and_sign_block(spec, state, block)

    # Create an attestation referencing the unseen block
    attestation = get_valid_attestation(
        spec, state, signed=True, beacon_block_root=signed_block.message.hash_tree_root()
    )
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "ignore"
    assert reason == "block being voted for has not been seen"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "ignore",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__reject_aggregation_bits_size_mismatch(spec, state):
    """
    Test that an aggregate with wrong aggregation bits size is rejected.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    # Modify aggregation_bits to have wrong length
    committee = spec.get_beacon_committee(state, attestation.data.slot, attestation.data.index)
    wrong_size = len(committee) + 5
    wrong_bits = [False] * wrong_size
    wrong_bits[0] = True
    signed_agg.message.aggregate.aggregation_bits = spec.AggregationBits(data=wrong_bits)

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "aggregation bits length does not match committee size"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__reject_aggregation_bits_size_mismatch_after_seen(
    spec, state
):
    """
    Test that an aggregate with wrong aggregation bits size is rejected even
    after a valid aggregate for the same data has already been seen.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    messages = []
    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg_1 = create_signed_aggregate_and_proof(spec, state, attestation)

    yield get_filename(signed_agg_1), signed_agg_1

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    # First validation should pass and seed dedup state.
    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg_1,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "valid"
    assert reason is None
    messages.append(
        {
            "current_time_ms": int(current_time_ms),
            "message": get_filename(signed_agg_1),
            "expected": "valid",
        }
    )

    # Build a second aggregate for the same data from a different aggregator so
    # that only the aggregation bits length rule can produce the verdict, then
    # modify its aggregation_bits to have wrong length.
    committee = spec.get_beacon_committee(state, attestation.data.slot, attestation.data.index)
    assert len(committee) > 1, "Need committee size > 1 for this test"
    other_aggregator_index = next(
        index for index in committee if index != signed_agg_1.message.aggregator_index
    )
    signed_agg_2 = create_signed_aggregate_and_proof(
        spec, state, attestation, aggregator_index=other_aggregator_index
    )
    wrong_size = len(committee) + 5
    wrong_bits = [False] * wrong_size
    wrong_bits[0] = True
    signed_agg_2.message.aggregate.aggregation_bits = spec.AggregationBits(data=wrong_bits)

    yield get_filename(signed_agg_2), signed_agg_2

    # Dedup must not trigger (or fail) on bitsets of different length; the
    # aggregate should reach the aggregation bits length rule and be rejected.
    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 100
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg_2,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "aggregation bits length does not match committee size"
    messages.append(
        {
            "current_time_ms": int(current_time_ms),
            "message": get_filename(signed_agg_2),
            "expected": "reject",
            "reason": reason,
        }
    )

    yield "messages", "meta", messages


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__reject_no_participants(spec, state):
    """
    Test that an aggregate with no participants is rejected.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    # Set all aggregation bits to False (no participants)
    committee = spec.get_beacon_committee(state, attestation.data.slot, attestation.data.index)
    empty_bits = [False] * len(committee)
    signed_agg.message.aggregate.aggregation_bits = spec.AggregationBits(data=empty_bits)

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "aggregate has no participants"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__ignore_already_seen_aggregator(spec, state):
    """
    Test that a second aggregate from the same aggregator in the same epoch is ignored.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    messages = []
    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation1 = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg1 = create_signed_aggregate_and_proof(spec, state, attestation1)

    yield get_filename(signed_agg1), signed_agg1

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation1.data.slot)

    # First validation should pass
    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg1,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "valid"
    messages.append(
        {
            "current_time_ms": int(current_time_ms),
            "message": get_filename(signed_agg1),
            "expected": "valid",
        }
    )

    # Create a second attestation with different data but the same aggregator.
    # A different committee index changes the attestation data without voting
    # for an unseen block, so the result is independent of check order.
    attestation2 = get_valid_attestation(
        spec, state, signed=True, index=1, beacon_block_root=anchor_root
    )
    aggregator_index = signed_agg1.message.aggregator_index
    signed_agg2 = create_signed_aggregate_and_proof(spec, state, attestation2, aggregator_index)

    yield get_filename(signed_agg2), signed_agg2

    # Second validation should be ignored (same aggregator, same epoch)
    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 100
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg2,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "ignore"
    assert reason == "already seen aggregate for this epoch and aggregator"
    messages.append(
        {
            "current_time_ms": int(current_time_ms),
            "message": get_filename(signed_agg2),
            "expected": "ignore",
            "reason": reason,
        }
    )

    yield "messages", "meta", messages


@with_all_phases
@with_presets([MAINNET], reason="minimal preset has committees < 16, so everyone is an aggregator")
@spec_test
@with_custom_state(
    balances_fn=large_validator_balances,
    threshold_fn=default_activation_threshold,
)
@single_phase
@always_bls
def test_gossip_beacon_aggregate_and_proof__reject_not_aggregator(spec, state):
    """
    Test that an aggregate from a validator not selected as aggregator is rejected.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    # Search for a non-aggregator at the current slot across all committees
    non_aggregator_index = None
    target_committee_index = None
    current_slot = state.slot

    committees_per_slot = spec.get_committee_count_per_slot(state, spec.get_current_epoch(state))
    for committee_index in range(committees_per_slot):
        committee = spec.get_beacon_committee(state, current_slot, committee_index)

        for index in committee:
            privkey = privkeys[index]
            selection_proof = spec.get_slot_signature(state, current_slot, privkey)
            if not spec.is_aggregator(state, current_slot, committee_index, selection_proof):
                non_aggregator_index = index
                target_committee_index = committee_index
                break

        if non_aggregator_index is not None:
            break

    assert non_aggregator_index is not None, "Could not find a non-aggregator in any committee"

    attestation = get_valid_attestation(
        spec, state, index=target_committee_index, signed=True, beacon_block_root=anchor_root
    )

    # Create aggregate with non-aggregator
    privkey = privkeys[non_aggregator_index]
    aggregate_and_proof = spec.get_aggregate_and_proof(
        state, non_aggregator_index, attestation, privkey
    )
    signature = spec.get_aggregate_and_proof_signature(state, aggregate_and_proof, privkey)
    signed_agg = spec.SignedAggregateAndProof(
        message=aggregate_and_proof,
        signature=signature,
    )

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "validator is not selected as aggregator"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__reject_aggregator_not_in_committee(spec, state):
    """
    Test that an aggregate from a validator not in the committee is rejected.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    # Find a validator NOT in the committee
    committee = spec.get_beacon_committee(state, attestation.data.slot, attestation.data.index)
    non_committee_index = None
    for i in range(len(state.validators)):
        if i not in committee:
            non_committee_index = i
            break

    # Change aggregator_index to someone not in committee
    signed_agg.message.aggregator_index = non_committee_index

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "aggregator is not a member of the committee"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__reject_aggregator_index_out_of_range(spec, state):
    """
    Test that an aggregate with out-of-range aggregator index is rejected.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    signed_agg.message.aggregator_index = len(state.validators) + 1

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "aggregator is not a member of the committee"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
@always_bls
def test_gossip_beacon_aggregate_and_proof__reject_invalid_selection_proof(spec, state):
    """
    Test that an aggregate with invalid selection proof signature is rejected.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    # Corrupt the selection proof
    signed_agg.message.selection_proof = b"\x00" * 96

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "invalid selection proof signature"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
@always_bls
def test_gossip_beacon_aggregate_and_proof__reject_invalid_aggregator_signature(spec, state):
    """
    Test that an aggregate with invalid aggregator signature is rejected.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    # Corrupt the aggregator signature
    signed_agg.signature = b"\x00" * 96

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "invalid aggregator signature"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
@always_bls
def test_gossip_beacon_aggregate_and_proof__reject_invalid_aggregate_signature(spec, state):
    """
    Test that an aggregate with invalid aggregate attestation signature is rejected.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    # Create an attestation with INVALID signature BEFORE creating the aggregate
    attestation = get_valid_attestation(spec, state, signed=False, beacon_block_root=anchor_root)
    attestation.signature = spec.BLSSignature(b"\x00" * 96)

    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "invalid aggregate signature"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__reject_block_failed_validation(spec, state):
    """
    Test that an aggregate for a block that failed validation is rejected.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)

    yield get_filename(signed_anchor), signed_anchor

    next_slot(spec, state)

    # Build and apply a block
    block = build_empty_block_for_next_slot(spec, state)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield get_filename(signed_block), signed_block

    # Add block to store.blocks but NOT to store.block_states (simulating failed validation)
    store.blocks[signed_block.message.hash_tree_root()] = signed_block.message

    yield (
        "blocks",
        "meta",
        [
            {"block": get_filename(signed_anchor)},
            {"block": get_filename(signed_block), "failed": True},
        ],
    )

    attestation = get_valid_attestation(spec, state, signed=True)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "block being voted for failed validation"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__reject_target_not_ancestor(spec, state):
    """
    Test that an aggregate whose target is not an ancestor of the LMD vote block is rejected.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    # Create an attestation with wrong target root BEFORE signing
    attestation = get_valid_attestation(spec, state, signed=False, beacon_block_root=anchor_root)
    attestation.data.target.root = spec.Root(b"\xcd" * 32)
    sign_attestation(spec, state, attestation)

    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    yield get_filename(signed_agg), signed_agg

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "target block is not an ancestor of LMD vote block"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases
@spec_state_test
def test_gossip_beacon_aggregate_and_proof__ignore_finalized_not_ancestor(spec, state):
    """
    Test that an aggregate for a block not descending from finalized checkpoint is ignored.
    """
    anchor_state = state.copy()
    yield "topic", "meta", "beacon_aggregate_and_proof"
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)
    anchor_root = anchor_block.hash_tree_root()

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    next_slot(spec, state)

    attestation = get_valid_attestation(spec, state, signed=True, beacon_block_root=anchor_root)
    signed_agg = create_signed_aggregate_and_proof(spec, state, attestation)

    yield get_filename(signed_agg), signed_agg

    # Set finalized checkpoint to something that is NOT an ancestor of the block
    store.finalized_checkpoint = spec.Checkpoint(
        epoch=spec.Epoch(0),
        root=spec.Root(b"\xef" * 32),
    )

    yield "finalized_checkpoint", "meta", {"epoch": 0, "root": "0x" + "ef" * 32}

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, attestation.data.slot)

    kwargs = {}
    if is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_aggregate_and_proof=signed_agg,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "ignore"
    assert reason == "finalized checkpoint is not an ancestor of block"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_agg),
                "expected": "ignore",
                "reason": reason,
            }
        ],
    )
