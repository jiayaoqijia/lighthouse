from eth_utils import encode_hex

from eth_consensus_specs.test.context import (
    spec_state_test,
    with_all_phases_from_to,
)
from eth_consensus_specs.test.helpers.attestations import (
    get_valid_attestations_at_slot,
)
from eth_consensus_specs.test.helpers.block import (
    build_empty_block_for_next_slot,
)
from eth_consensus_specs.test.helpers.constants import (
    ALTAIR,
    GLOAS,
)
from eth_consensus_specs.test.helpers.fork_choice import (
    apply_next_epoch_with_attestations,
    apply_next_slots_with_attestations,
    get_genesis_forkchoice_store_and_block,
    on_tick_and_append_step,
    output_store_checks,
    tick_and_add_block,
    tick_and_run_on_attestation,
)
from eth_consensus_specs.test.helpers.forks import is_post_fulu
from eth_consensus_specs.test.helpers.state import (
    next_epoch,
    next_slot,
    state_transition_and_sign_block,
)


@with_all_phases_from_to(ALTAIR, GLOAS)
@spec_state_test
def test_basic_is_head_root(spec, state):
    test_steps = []
    # Initialization
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    yield "anchor_state", state
    yield "anchor_block", anchor_block
    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, state.slot)
    on_tick_and_append_step(spec, store, current_time_ms, test_steps)
    assert store.time_ms == current_time_ms

    # On receiving a block of `GENESIS_SLOT + 1` slot
    block = build_empty_block_for_next_slot(spec, state)
    signed_block = state_transition_and_sign_block(spec, state, block)
    yield from tick_and_add_block(spec, store, signed_block, test_steps)
    head = spec.get_head(store)
    assert head.root == signed_block.message.hash_tree_root()

    # Proposing next slot
    next_slot(spec, state)
    slot = state.slot

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, slot)
    on_tick_and_append_step(spec, store, current_time_ms, test_steps)
    proposer_head = spec.get_proposer_head(store, head, slot)
    assert proposer_head.root == head.root

    output_store_checks(spec, store, test_steps)
    test_steps.append(
        {
            "checks": {
                "get_proposer_head": encode_hex(proposer_head.root),
            }
        }
    )

    yield "steps", test_steps


def _run_is_parent_root(spec, state, at_epoch_boundary):
    test_steps = []
    # Initialization
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    yield "anchor_state", state
    yield "anchor_block", anchor_block
    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, state.slot)
    on_tick_and_append_step(spec, store, current_time_ms, test_steps)
    assert store.time_ms == current_time_ms

    next_epoch(spec, state)
    on_tick_and_append_step(
        spec,
        store,
        spec.compute_time_at_slot_ms(store.genesis_time_ms, state.slot),
        test_steps,
    )

    # Fill epoch 1 to 3
    for _ in range(3):
        state, store, _ = yield from apply_next_epoch_with_attestations(
            spec, state, store, fill_cur_epoch=True, fill_prev_epoch=True, test_steps=test_steps
        )

    assert spec.compute_epoch_at_slot(spec.get_current_slot(store)) == 4
    assert state.current_justified_checkpoint.epoch == store.justified_checkpoint.epoch == 3
    assert state.finalized_checkpoint.epoch == store.finalized_checkpoint.epoch == 2

    if at_epoch_boundary:
        # Align the proposal slot with the next epoch boundary. Four slots are
        # consumed below: one initial block, the parent, the late head, and the proposal.
        state, store, _ = yield from apply_next_slots_with_attestations(
            spec,
            state,
            store,
            spec.SLOTS_PER_EPOCH - 4,
            fill_cur_epoch=True,
            fill_prev_epoch=True,
            test_steps=test_steps,
        )

    if at_epoch_boundary:
        # Include enough attestations before the parent to keep finalization healthy
        # without changing FFG information in the late head.
        state, store, _ = yield from apply_next_slots_with_attestations(
            spec,
            state,
            store,
            1,
            fill_cur_epoch=True,
            fill_prev_epoch=True,
            test_steps=test_steps,
        )
    else:
        # Make an empty block
        block = build_empty_block_for_next_slot(spec, state)
        signed_block = state_transition_and_sign_block(spec, state, block)
        yield from tick_and_add_block(spec, store, signed_block, test_steps)

    # Fill a slot (parent)
    state, store, signed_parent_block = yield from apply_next_slots_with_attestations(
        spec, state, store, 1, fill_cur_epoch=True, fill_prev_epoch=True, test_steps=test_steps
    )

    # Fill a slot with attestations to its parent
    block = build_empty_block_for_next_slot(spec, state)
    parent_block_slot = block.slot - 1
    block.body.attestations = spec.Attestations(
        data=get_valid_attestations_at_slot(
            state,
            spec,
            parent_block_slot,
        )
    )
    signed_block = state_transition_and_sign_block(spec, state, block)

    # Make the head block late
    # Round up to nearest second
    attestation_due_ms = spec.get_attestation_due_ms()
    attesting_cutoff = spec.milliseconds_to_seconds(attestation_due_ms - 1) + 1
    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, state.slot)
    current_time_ms += spec.seconds_to_milliseconds(attesting_cutoff)
    on_tick_and_append_step(spec, store, current_time_ms, test_steps)
    assert store.time_ms == current_time_ms

    yield from tick_and_add_block(spec, store, signed_block, test_steps)

    # Check conditions
    head = spec.get_head(store)
    head_block = store.blocks[head.root]
    parent_root = head_block.parent_root
    assert parent_root == signed_parent_block.message.hash_tree_root()
    parent_block = store.blocks[parent_root]

    # Proposing next slot
    next_slot(spec, state)
    slot = state.slot

    # Add attestations to the parent block
    attestations = get_valid_attestations_at_slot(
        state,
        spec,
        slot_to_attest=slot - 1,
        beacon_block_root=parent_root,
    )
    for attestation in attestations:
        yield from tick_and_run_on_attestation(spec, store, attestation, test_steps)

    # The conditions in `get_proposer_head`
    assert spec.is_head_late(store, head.root)
    if at_epoch_boundary:
        assert slot % spec.SLOTS_PER_EPOCH == 0
    else:
        assert slot % spec.SLOTS_PER_EPOCH != 0
    if is_post_fulu(spec):
        assert not hasattr(spec, "is_shuffling_stable")
    else:
        assert spec.is_shuffling_stable(slot) == (not at_epoch_boundary)
    assert spec.is_ffg_competitive(store, head.root, parent_root)
    assert spec.is_finalization_ok(store, slot)
    assert spec.is_proposing_on_time(store)

    parent_slot_ok = parent_block.slot + 1 == head_block.slot
    current_time_ok = head_block.slot + 1 == slot
    single_slot_reorg = parent_slot_ok and current_time_ok
    assert single_slot_reorg

    assert spec.is_head_weak(store, head.root)
    assert spec.is_parent_strong(store, head.root)

    proposer_head = spec.get_proposer_head(store, head, state.slot)
    expect_reorg = not at_epoch_boundary or is_post_fulu(spec)
    expected_root = parent_root if expect_reorg else head.root
    assert proposer_head.root == expected_root

    output_store_checks(spec, store, test_steps)
    test_steps.append(
        {
            "checks": {
                "get_proposer_head": encode_hex(proposer_head.root),
            }
        }
    )

    yield "steps", test_steps


@with_all_phases_from_to(ALTAIR, GLOAS)
@spec_state_test
def test_basic_is_parent_root(spec, state):
    yield from _run_is_parent_root(spec, state, at_epoch_boundary=False)


@with_all_phases_from_to(ALTAIR, GLOAS)
@spec_state_test
def test_epoch_boundary(spec, state):
    yield from _run_is_parent_root(spec, state, at_epoch_boundary=True)
