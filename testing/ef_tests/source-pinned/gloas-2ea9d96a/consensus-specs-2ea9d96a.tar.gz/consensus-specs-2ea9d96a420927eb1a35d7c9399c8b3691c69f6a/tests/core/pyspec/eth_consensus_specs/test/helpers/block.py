from eth_consensus_specs.test.helpers.eip8321.randao import (
    get_hash_chain_reveal,
)
from eth_consensus_specs.test.helpers.execution_payload import (
    build_empty_execution_payload,
    build_empty_signed_execution_payload_bid,
    compute_and_sign_execution_payload_bid,
)
from eth_consensus_specs.test.helpers.forks import (
    is_post_altair,
    is_post_bellatrix,
    is_post_eip8321,
    is_post_electra,
    is_post_gloas,
    is_post_heze,
)
from eth_consensus_specs.test.helpers.keys import privkeys
from eth_consensus_specs.utils import bls
from eth_consensus_specs.utils.bls import only_with_bls


def get_proposer_index_maybe(spec, state, slot, proposer_index=None):
    if proposer_index is None:
        assert state.slot <= slot
        if slot == state.slot:
            proposer_index = spec.get_beacon_proposer_index(state)
        else:
            # use stub state to get proposer index of future slot
            stub_state = state.copy()
            if stub_state.slot < slot:
                spec.process_slots(stub_state, slot)
            proposer_index = spec.get_beacon_proposer_index(stub_state)
    return proposer_index


def apply_randao_reveal(spec, state, block, proposer_index):
    assert state.slot <= block.slot

    if is_post_eip8321(spec) and state.randao_commitments[proposer_index] != spec.Bytes32():
        # The proposer walks its hash chain instead of signing; the legacy reveal must be empty.
        block.body.randao_reveal = spec.G2_POINT_AT_INFINITY
        block.body.hash_chain_reveal = get_hash_chain_reveal(spec, state, proposer_index)
    else:
        sign_randao_reveal(spec, state, block, proposer_index)


# Fully ignore the function if BLS is off, signing is slow.
@only_with_bls()
def sign_randao_reveal(spec, state, block, proposer_index):
    privkey = privkeys[proposer_index]

    domain = spec.get_domain(state, spec.DOMAIN_RANDAO, spec.compute_epoch_at_slot(block.slot))
    signing_root = spec.compute_signing_root(spec.compute_epoch_at_slot(block.slot), domain)
    block.body.randao_reveal = bls.Sign(privkey, signing_root)


# Fully ignore the function if BLS is off, beacon-proposer index calculation is slow.
@only_with_bls()
def apply_sig(spec, state, signed_block, proposer_index=None):
    block = signed_block.message

    proposer_index = get_proposer_index_maybe(spec, state, block.slot, proposer_index)
    privkey = privkeys[proposer_index]
    domain = spec.get_domain(
        state, spec.DOMAIN_BEACON_PROPOSER, spec.compute_epoch_at_slot(block.slot)
    )
    signing_root = spec.compute_signing_root(block, domain)

    signed_block.signature = bls.Sign(privkey, signing_root)


def sign_block(spec, state, block, proposer_index=None):
    signed_block = spec.SignedBeaconBlock(message=block)
    apply_sig(spec, state, signed_block, proposer_index)
    return signed_block


def transition_unsigned_block(spec, state, block):
    assert (
        state.slot < block.slot
    )  # Preserve assertion from state transition to avoid strange pre-states from testing
    if state.slot < block.slot:
        spec.process_slots(state, block.slot)
    assert (
        state.latest_block_header.slot < block.slot
    )  # There may not already be a block in this slot or past it.
    assert state.slot == block.slot  # The block must be for this slot
    spec.process_block(state, block)
    return block


def apply_empty_block(spec, state, slot=None):
    """
    Transition via an empty block (on current slot, assuming no block has been applied yet).
    """
    block = build_empty_block(spec, state, slot)
    return transition_unsigned_block(spec, state, block)


def build_empty_block(spec, state, slot=None, proposer_index=None):
    """
    Build empty block for ``slot``, built upon the latest block header seen by ``state``.
    Slot must be greater than or equal to the current slot in ``state``.
    """
    if slot is None:
        slot = state.slot
    if slot < state.slot:
        raise Exception("build_empty_block cannot build blocks for past slots")
    if state.slot < slot:
        # transition forward in copied state to grab relevant data from state
        state = state.copy()
        spec.process_slots(state, slot)

    state, parent_block_root = get_state_and_beacon_parent_root_at_slot(spec, state, slot)
    proposer_index = get_beacon_proposer_to_build(spec, state, proposer_index)
    empty_block = spec.BeaconBlock()
    empty_block.slot = slot
    empty_block.proposer_index = proposer_index
    if not is_post_heze(spec):
        empty_block.body.eth1_data.deposit_count = state.eth1_deposit_index
    empty_block.parent_root = parent_block_root

    apply_randao_reveal(spec, state, empty_block, proposer_index)

    if is_post_altair(spec):
        empty_block.body.sync_aggregate.sync_committee_signature = spec.G2_POINT_AT_INFINITY

    if is_post_gloas(spec):
        signed_bid = build_empty_signed_execution_payload_bid(spec, state)
        signed_bid.message.block_hash = spec.Hash32()
        signed_bid.message.parent_block_hash = spec.Hash32(state.latest_block_hash)
        empty_requests_root = spec.hash_tree_root(spec.ExecutionRequests())
        signed_bid.message.execution_requests_root = empty_requests_root
        empty_block.body.signed_execution_payload_bid = signed_bid
        return empty_block

    if is_post_bellatrix(spec):
        empty_block.body.execution_payload = build_empty_execution_payload(spec, state)

    if is_post_electra(spec):
        empty_block.body.execution_requests.deposits = spec.DepositRequests(data=[])
        empty_block.body.execution_requests.withdrawals = spec.WithdrawalRequests(data=[])
        empty_block.body.execution_requests.consolidations = spec.ConsolidationRequests()

    return empty_block


def build_block_and_payload(
    spec, state, slot=None, proposer_index=None, parent_payload=None, execution_requests=None
):
    """
    Build block and a payload for ``slot``, built upon the latest block header seen by ``state``.
    Slot must be greater than or equal to the current slot in ``state``.
    """
    if not is_post_electra(spec):
        assert execution_requests is None

    if slot is None:
        slot = state.slot
    if slot < state.slot:
        raise Exception("build_block_and_payload cannot build blocks for past slots")
    if state.slot < slot:
        # transition forward in copied state to grab relevant data from state
        state = state.copy()
        spec.process_slots(state, slot)

    state, parent_block_root = get_state_and_beacon_parent_root_at_slot(spec, state, slot)
    proposer_index = get_beacon_proposer_to_build(spec, state, proposer_index)
    block = spec.BeaconBlock()
    block.slot = slot
    block.proposer_index = proposer_index
    if not is_post_heze(spec):
        block.body.eth1_data.deposit_count = state.eth1_deposit_index
    block.parent_root = parent_block_root

    apply_randao_reveal(spec, state, block, proposer_index)

    if is_post_altair(spec):
        block.body.sync_aggregate.sync_committee_signature = spec.G2_POINT_AT_INFINITY

    if not is_post_bellatrix(spec):
        return block, None

    if is_post_electra(spec) and execution_requests is None:
        execution_requests = spec.ExecutionRequests()

    prev_randao = spec.get_randao_mix(state, spec.get_current_epoch(state))
    payload = build_empty_execution_payload(
        spec,
        state,
        randao_mix=prev_randao,
        parent_payload=parent_payload,
        execution_requests=execution_requests,
    )
    if is_post_gloas(spec):
        signed_bid = compute_and_sign_execution_payload_bid(
            spec, state, payload, execution_requests=execution_requests
        )
        block.body.signed_execution_payload_bid = signed_bid
    else:
        block.body.execution_payload = payload
        if is_post_electra(spec):
            block.body.execution_requests = execution_requests

    return block, payload


def get_beacon_proposer_to_build(spec, state, proposer_index=None):
    return spec.get_beacon_proposer_index(state)


def build_empty_block_for_next_slot(spec, state, proposer_index=None):
    return build_empty_block(spec, state, state.slot + 1, proposer_index)


def get_state_and_beacon_parent_root_at_slot(spec, state, slot):
    if slot < state.slot:
        raise Exception("Cannot build blocks for past slots")
    if slot > state.slot:
        # transition forward in copied state to grab relevant data from state
        state = state.copy()
        spec.process_slots(state, slot)

    previous_block_header = state.latest_block_header.copy()
    if previous_block_header.state_root == spec.Root():
        previous_block_header.state_root = spec.hash_tree_root(state)
    beacon_parent_root = spec.hash_tree_root(previous_block_header)
    return state, beacon_parent_root
