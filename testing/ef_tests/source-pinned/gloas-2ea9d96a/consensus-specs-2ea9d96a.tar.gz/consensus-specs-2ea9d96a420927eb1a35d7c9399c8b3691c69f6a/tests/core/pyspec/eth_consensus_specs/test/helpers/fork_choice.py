from collections.abc import Sequence
from typing import Any, NamedTuple

from eth_utils import encode_hex

from eth_consensus_specs.fulu.mainnet import DataColumnSidecar
from eth_consensus_specs.test.context import expect_assertion_error
from eth_consensus_specs.test.exceptions import BlockNotFoundException
from eth_consensus_specs.test.helpers.attestations import (
    next_epoch_with_attestations,
    next_slots_with_attestations,
    state_transition_with_full_block,
)
from eth_consensus_specs.test.helpers.block import build_empty_block_for_next_slot
from eth_consensus_specs.test.helpers.forks import is_post_fulu, is_post_gloas
from eth_consensus_specs.test.helpers.state import next_epoch, state_transition_and_sign_block


def check_head_against_root(spec, store, root):
    assert spec.get_head(store).root == root


class BlobData(NamedTuple):
    """
    The return values of blob/sidecar retrieval helpers.
    """

    blobs: Sequence[Any] | None = None
    proofs: Sequence[bytes] | None = None
    sidecars: Sequence[DataColumnSidecar] | None = None
    kzg_commitments: Sequence[Any] | None = None

    def is_post_fulu(self):
        return self.sidecars is not None and self.blobs is None and self.proofs is None

    def is_pre_fulu(self):
        return self.blobs is not None and self.proofs is not None and self.sidecars is None


def with_blob_data(spec, blob_data: BlobData, func):
    if is_post_gloas(spec):
        if blob_data.kzg_commitments is None:
            raise ValueError("blob_data.kzg_commitments must be provided post-Gloas")
        yield from with_blob_data_gloas(spec, blob_data, func)
    elif is_post_fulu(spec):
        if blob_data.sidecars is None:
            raise ValueError("blob_data.sidecars must be provided post-Fulu")
        yield from with_blob_data_fulu(spec, blob_data, func)
    else:
        if blob_data.proofs is None:
            raise ValueError("blob_data.proofs must be provided pre-Fulu")
        yield from with_blob_data_deneb(spec, blob_data, func)


def with_blob_data_deneb(spec, blob_data: BlobData, func):
    """
    This helper runs the given ``func`` with monkeypatched ``retrieve_blobs_and_proofs``
    that returns ``blob_data.blobs, blob_data.proofs``.
    """

    def retrieve_blobs_and_proofs(_):
        assert blob_data.proofs is not None, "blob_data.proofs must be provided"
        return blob_data.blobs, blob_data.proofs

    retrieve_blobs_and_proofs_backup = spec.retrieve_blobs_and_proofs
    spec.retrieve_blobs_and_proofs = retrieve_blobs_and_proofs

    class AtomicBoolean:
        value = False

    is_called = AtomicBoolean()

    def wrap(flag: AtomicBoolean):
        yield from func()
        flag.value = True

    try:
        yield from wrap(is_called)
    finally:
        spec.retrieve_blobs_and_proofs = retrieve_blobs_and_proofs_backup
    assert is_called.value


def with_blob_data_fulu(spec, blob_data: BlobData, func):
    """
    This helper runs the given ``func`` with monkeypatched ``retrieve_column_sidecars``
    that returns ``blob_data.sidecars``.
    """

    def retrieve_column_sidecars(_):
        assert blob_data.sidecars is not None, "blob_data.sidecars must be provided"
        if len(blob_data.sidecars) == 0:
            raise AssertionError("Simulation: not all required columns have been sampled")
        return blob_data.sidecars

    retrieve_column_sidecars_backup = spec.retrieve_column_sidecars
    spec.retrieve_column_sidecars = retrieve_column_sidecars

    class AtomicBoolean:
        value = False

    is_called = AtomicBoolean()

    def wrap(flag: AtomicBoolean):
        yield from func()
        flag.value = True

    try:
        yield from wrap(is_called)
    finally:
        spec.retrieve_column_sidecars = retrieve_column_sidecars_backup
    assert is_called.value


def with_blob_data_gloas(spec, blob_data: BlobData, func):
    """
    This helper runs the given ``func`` with monkeypatched
    ``retrieve_column_sidecars_and_kzg_commitments``.
    """

    def retrieve_column_sidecars_and_kzg_commitments(_):
        assert blob_data.sidecars is not None, "blob_data.sidecars must be provided"
        if len(blob_data.sidecars) == 0:
            raise AssertionError("Simulation: not all required columns have been sampled")
        assert blob_data.kzg_commitments is not None, (
            "blob_data.kzg_commitments must be provided for Gloas"
        )
        return blob_data.sidecars, blob_data.kzg_commitments

    retrieve_column_sidecars_and_kzg_commitments_backup = (
        spec.retrieve_column_sidecars_and_kzg_commitments
    )
    spec.retrieve_column_sidecars_and_kzg_commitments = retrieve_column_sidecars_and_kzg_commitments

    class AtomicBoolean:
        value = False

    is_called = AtomicBoolean()

    def wrap(flag: AtomicBoolean):
        yield from func()
        flag.value = True

    try:
        yield from wrap(is_called)
    finally:
        spec.retrieve_column_sidecars_and_kzg_commitments = (
            retrieve_column_sidecars_and_kzg_commitments_backup
        )
    assert is_called.value


def get_fork_choice_node(spec, root, payload_status=None):
    if is_post_gloas(spec):
        if payload_status is None:
            payload_status = spec.PAYLOAD_STATUS_PENDING
        return spec.ForkChoiceNode(root=root, payload_status=payload_status)
    else:
        return spec.ForkChoiceNode(root=root)


def get_anchor_root(spec, state):
    anchor_block_header = state.latest_block_header.copy()
    if anchor_block_header.state_root == spec.Bytes32():
        anchor_block_header.state_root = spec.hash_tree_root(state)
    return spec.hash_tree_root(anchor_block_header)


def tick_and_add_block(
    spec,
    store,
    signed_block,
    test_steps,
    valid=True,
    merge_block=False,
    block_not_found=False,
    is_optimistic=False,
    blob_data: BlobData | None = None,
):
    pre_state = store.block_states[signed_block.message.parent_root]
    if merge_block:
        assert spec.is_merge_transition_block(pre_state, signed_block.message.body)

    block_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, signed_block.message.slot)
    while store.time_ms < block_time_ms:
        next_slot = spec.get_current_slot(store) + 1
        next_slot_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, next_slot)
        on_tick_and_append_step(spec, store, next_slot_time_ms, test_steps)

    post_state = yield from add_block(
        spec,
        store,
        signed_block,
        test_steps,
        valid=valid,
        block_not_found=block_not_found,
        is_optimistic=is_optimistic,
        blob_data=blob_data,
    )

    return post_state


def tick_and_add_block_with_data(spec, store, signed_block, test_steps, blob_data, valid=True):
    def run_func():
        yield from tick_and_add_block(
            spec, store, signed_block, test_steps, blob_data=blob_data, valid=valid
        )

    yield from with_blob_data(spec, blob_data, run_func)


def add_attestation(spec, store, attestation, test_steps, is_from_block=False, valid=True):
    run_on_attestation(spec, store, attestation, is_from_block=is_from_block, valid=valid)
    yield get_attestation_file_name(attestation), attestation
    if valid:
        test_steps.append({"attestation": get_attestation_file_name(attestation)})
    else:
        test_steps.append({"attestation": get_attestation_file_name(attestation), "valid": False})


def add_attestations(spec, store, attestations, test_steps, is_from_block=False):
    for attestation in attestations:
        yield from add_attestation(
            spec, store, attestation, test_steps, is_from_block=is_from_block
        )


def tick_and_run_on_attestation(spec, store, attestation, test_steps, is_from_block=False):
    # Make get_current_slot(store) >= attestation.data.slot + 1
    min_time_to_include_ms = spec.compute_time_at_slot_ms(
        store.genesis_time_ms, attestation.data.slot + 1
    )
    if store.time_ms < min_time_to_include_ms:
        on_tick_and_append_step(spec, store, min_time_to_include_ms, test_steps)

    yield from add_attestation(spec, store, attestation, test_steps, is_from_block)


def run_on_attestation(spec, store, attestation, is_from_block=False, valid=True):
    if not valid:
        expect_assertion_error(
            lambda: spec.on_attestation(store, attestation, is_from_block=is_from_block)
        )
        return

    spec.on_attestation(store, attestation, is_from_block=is_from_block)


def get_genesis_forkchoice_store(spec, genesis_state):
    store, _ = get_genesis_forkchoice_store_and_block(spec, genesis_state)
    return store


def get_genesis_forkchoice_store_and_block(spec, genesis_state):
    assert genesis_state.slot == spec.GENESIS_SLOT
    genesis_block = spec.BeaconBlock(state_root=genesis_state.hash_tree_root())
    if is_post_gloas(spec):
        # Match the genesis block body bid to what ``genesis.py`` set on the
        # state's committed bid; this keeps ``genesis_block`` consistent with
        # ``genesis_state.latest_block_header`` (body_root).
        genesis_block.body.signed_execution_payload_bid.message = (
            genesis_state.latest_execution_payload_bid
        )
    store = spec.get_forkchoice_store(genesis_state, genesis_block)
    return store, genesis_block


def get_block_file_name(signed_block):
    return f"block_{encode_hex(signed_block.message.hash_tree_root())}"


def get_attestation_file_name(attestation):
    return f"attestation_{encode_hex(attestation.hash_tree_root())}"


def get_attester_slashing_file_name(attester_slashing):
    return f"attester_slashing_{encode_hex(attester_slashing.hash_tree_root())}"


def get_blobs_file_name(blobs=None, blobs_root=None):
    if blobs:
        return f"blobs_{encode_hex(blobs.hash_tree_root())}"
    else:
        return f"blobs_{encode_hex(blobs_root)}"


def get_sidecars_file_names(sidecars: Sequence[DataColumnSidecar]) -> Sequence[str]:
    """
    Returns the file names for sidecars.
    """
    return [get_sidecar_file_name(sidecar) for sidecar in sidecars]


def get_sidecar_file_name(sidecar: DataColumnSidecar) -> str:
    """
    Returns the file name for a single sidecar.
    """
    return f"column_{encode_hex(sidecar.hash_tree_root())}"


def get_payload_attestation_message_file_name(ptc_message):
    return f"payload_attestation_message_{encode_hex(ptc_message.hash_tree_root())}"


def on_tick_and_append_step(spec, store, time_ms, test_steps):
    assert time_ms >= store.time_ms
    spec.on_tick(store, time_ms)
    test_steps.append({"tick": int(spec.milliseconds_to_seconds(time_ms))})
    output_store_checks(spec, store, test_steps)


def run_on_block(spec, store, signed_block, valid=True):
    if not valid:
        expect_assertion_error(lambda: spec.on_block(store, signed_block))
        return

    spec.on_block(store, signed_block)
    root = signed_block.message.hash_tree_root()
    assert store.blocks[root] == signed_block.message


def add_block(
    spec,
    store,
    signed_block,
    test_steps,
    valid=True,
    block_not_found=False,
    is_optimistic=False,
    blob_data=None,
):
    """
    Run on_block and on_attestation
    """
    yield get_block_file_name(signed_block), signed_block

    # Check blob_data
    if blob_data is not None:
        assert blob_data.is_pre_fulu() or blob_data.is_post_fulu(), "Integrity fail blob_data"

        if blob_data.is_pre_fulu():
            blobs = spec.Blobs(data=blob_data.blobs)
            blobs_root = blobs.hash_tree_root()
            yield get_blobs_file_name(blobs_root=blobs_root), blobs

        if blob_data.is_post_fulu():
            for sidecar in blob_data.sidecars:
                yield get_sidecar_file_name(sidecar), sidecar

    def _append_step(valid=True):
        if blob_data is not None:
            if blob_data.is_post_fulu():
                step = {
                    "block": get_block_file_name(signed_block),
                    "columns": get_sidecars_file_names(blob_data.sidecars),
                    "valid": valid,
                }
            if blob_data.is_pre_fulu():
                step = {
                    "block": get_block_file_name(signed_block),
                    "blobs": get_blobs_file_name(blobs_root=blobs_root),
                    "proofs": [encode_hex(proof) for proof in blob_data.proofs],
                    "valid": valid,
                }

            test_steps.append(step)
        else:
            test_steps.append(
                {
                    "block": get_block_file_name(signed_block),
                    "valid": valid,
                }
            )

    if not valid:
        if is_optimistic:
            run_on_block(spec, store, signed_block, valid=True)
            _append_step(valid=False)
        else:
            try:
                run_on_block(spec, store, signed_block, valid=True)
            except (AssertionError, BlockNotFoundException) as e:
                if isinstance(e, BlockNotFoundException) and not block_not_found:
                    raise AssertionError from e
                _append_step(valid=False)
                return
            else:
                raise AssertionError
    else:
        run_on_block(spec, store, signed_block, valid=True)
        _append_step()

    # An on_block step implies receiving block's attestations
    for attestation in signed_block.message.body.attestations:
        run_on_attestation(spec, store, attestation, is_from_block=True, valid=True)

    # An on_block step implies receiving block's attester slashings
    for attester_slashing in signed_block.message.body.attester_slashings:
        run_on_attester_slashing(spec, store, attester_slashing, valid=True)

    if is_post_gloas(spec):
        # An on_block step implies receiving block's payload attestations (post GLOAS)
        state = store.block_states[signed_block.message.hash_tree_root()]
        for payload_attestation in signed_block.message.body.payload_attestations:
            slot = payload_attestation.data.slot
            ptc = spec.get_ptc(state, slot)
            bits = payload_attestation.aggregation_bits
            attesting_indices = [index for i, index in enumerate(ptc) if bits[i]]
            for validator_index in attesting_indices:
                ptc_message = spec.PayloadAttestationMessage(
                    validator_index=validator_index,
                    data=payload_attestation.data,
                    signature=spec.BLSSignature(),
                )
                run_on_payload_attestation_message(
                    spec, store, ptc_message, is_from_block=True, valid=True
                )

    block_root = signed_block.message.hash_tree_root()
    assert store.blocks[block_root] == signed_block.message
    assert store.block_states[block_root].hash_tree_root() == signed_block.message.state_root
    if not is_optimistic:
        output_store_checks(spec, store, test_steps)

    return store.block_states[signed_block.message.hash_tree_root()]


def run_on_execution_payload_envelope(spec, store, signed_envelope, valid=True):
    """Process execution payload envelope through the fork choice store."""
    if not valid:
        expect_assertion_error(lambda: spec.on_execution_payload_envelope(store, signed_envelope))
        return

    spec.on_execution_payload_envelope(store, signed_envelope)

    # Verify the envelope was processed, block should now have FULL state
    envelope_root = signed_envelope.message.beacon_block_root
    assert envelope_root in store.payloads


def get_execution_payload_envelope_file_name(signed_envelope):
    return f"execution_payload_envelope_{encode_hex(signed_envelope.hash_tree_root())}"


def add_execution_payload(spec, store, signed_envelope, test_steps, valid=True):
    file_name = get_execution_payload_envelope_file_name(signed_envelope)
    yield file_name, signed_envelope

    if not valid:
        run_on_execution_payload_envelope(spec, store, signed_envelope, valid=False)
        test_steps.append({"execution_payload": file_name, "valid": False})
        return

    run_on_execution_payload_envelope(spec, store, signed_envelope, valid=True)
    test_steps.append({"execution_payload": file_name, "valid": True})
    output_store_checks(spec, store, test_steps)


def run_on_attester_slashing(spec, store, attester_slashing, valid=True):
    if not valid:
        expect_assertion_error(lambda: spec.on_attester_slashing(store, attester_slashing))
        return

    spec.on_attester_slashing(store, attester_slashing)


def add_attester_slashing(spec, store, attester_slashing, test_steps, valid=True):
    slashing_file_name = get_attester_slashing_file_name(attester_slashing)
    yield get_attester_slashing_file_name(attester_slashing), attester_slashing

    if not valid:
        expect_assertion_error(lambda: run_on_attester_slashing(spec, store, attester_slashing))
        test_steps.append(
            {
                "attester_slashing": slashing_file_name,
                "valid": False,
            }
        )
        return

    run_on_attester_slashing(spec, store, attester_slashing)
    test_steps.append({"attester_slashing": slashing_file_name})


def run_on_payload_attestation_message(spec, store, ptc_message, is_from_block=False, valid=True):
    if not valid:
        expect_assertion_error(
            lambda: spec.on_payload_attestation_message(
                store, ptc_message, is_from_block=is_from_block
            )
        )
        return

    spec.on_payload_attestation_message(store, ptc_message, is_from_block=is_from_block)


def add_payload_attestation_message(spec, store, ptc_message, test_steps, valid=True):
    ptc_file_name = get_payload_attestation_message_file_name(ptc_message)
    yield ptc_file_name, ptc_message

    run_on_payload_attestation_message(spec, store, ptc_message, valid=valid)
    step = {"payload_attestation_message": ptc_file_name}

    if not valid:
        step["valid"] = False
    test_steps.append(step)


def add_payload_vote_checks(store, block_root, test_steps):
    timeliness = [None if v is None else bool(v) for v in store.payload_timeliness_vote[block_root]]
    availability = [
        None if v is None else bool(v) for v in store.payload_data_availability_vote[block_root]
    ]

    test_steps.append(
        {
            "checks": {
                "payload_timeliness_vote": {
                    "block_root": encode_hex(block_root),
                    "votes": timeliness,
                },
                "payload_data_availability_vote": {
                    "block_root": encode_hex(block_root),
                    "votes": availability,
                },
            }
        }
    )


def get_formatted_head_output(spec, store):
    head = spec.get_head(store)
    formatted_head = {
        "slot": int(store.blocks[head.root].slot),
        "root": encode_hex(head.root),
    }

    if is_post_gloas(spec):
        formatted_head["payload_status"] = int(head.payload_status)

    return formatted_head


def output_head_check(spec, store, test_steps):
    test_steps.append(
        {
            "checks": {
                "head": get_formatted_head_output(spec, store),
            }
        }
    )


def get_basic_store_checks(spec, store):
    return {
        "time": int(spec.milliseconds_to_seconds(store.time_ms)),
        "head": get_formatted_head_output(spec, store),
        "justified_checkpoint": {
            "epoch": int(store.justified_checkpoint.epoch),
            "root": encode_hex(store.justified_checkpoint.root),
        },
        "finalized_checkpoint": {
            "epoch": int(store.finalized_checkpoint.epoch),
            "root": encode_hex(store.finalized_checkpoint.root),
        },
        "proposer_boost_root": encode_hex(store.proposer_boost_root),
    }


def get_weighed_node_checks(spec, store, node):
    if is_post_gloas(spec):
        return {
            "root": encode_hex(node.root),
            "weight": int(spec.get_weight(store, node)),
            "payload_status": int(node.payload_status),
        }
    else:
        return {
            "root": encode_hex(node.root),
            "weight": int(spec.get_weight(store, node)),
        }


def get_viable_for_head_checks(spec, store):
    filtered_node_tree = spec.get_filtered_node_tree(store)
    root_node = get_fork_choice_node(spec, store.justified_checkpoint.root)
    pending_nodes = [root_node]
    leaves_viable_for_head = []

    while len(pending_nodes) > 0:
        node = pending_nodes.pop()
        children = [
            child for child in spec.get_node_children(store, node) if child in filtered_node_tree
        ]
        if len(children) == 0:
            leaves_viable_for_head.append(node)
        else:
            pending_nodes.extend(children)

    return [get_weighed_node_checks(spec, store, node) for node in leaves_viable_for_head]


def output_store_checks(spec, store, test_steps, with_viable_for_head_weights=False):
    checks = get_basic_store_checks(spec, store)

    if with_viable_for_head_weights:
        checks["viable_for_head_roots_and_weights"] = get_viable_for_head_checks(spec, store)

    test_steps.append({"checks": checks})


def apply_next_epoch_with_attestations(
    spec, state, store, fill_cur_epoch, fill_prev_epoch, participation_fn=None, test_steps=None
):
    if test_steps is None:
        test_steps = []

    _, new_signed_blocks, post_state = next_epoch_with_attestations(
        spec, state, fill_cur_epoch, fill_prev_epoch, participation_fn=participation_fn
    )
    for signed_block in new_signed_blocks:
        block = signed_block.message
        yield from tick_and_add_block(spec, store, signed_block, test_steps)
        block_root = block.hash_tree_root()
        assert store.blocks[block_root] == block
        last_signed_block = signed_block

    assert store.block_states[block_root].hash_tree_root() == post_state.hash_tree_root()

    return post_state, store, last_signed_block


def apply_next_slots_with_attestations(
    spec, state, store, slots, fill_cur_epoch, fill_prev_epoch, test_steps, participation_fn=None
):
    _, new_signed_blocks, post_state = next_slots_with_attestations(
        spec, state, slots, fill_cur_epoch, fill_prev_epoch, participation_fn=participation_fn
    )
    for signed_block in new_signed_blocks:
        block = signed_block.message
        yield from tick_and_add_block(spec, store, signed_block, test_steps)
        block_root = block.hash_tree_root()
        assert store.blocks[block_root] == block
        last_signed_block = signed_block

    assert store.block_states[block_root].hash_tree_root() == post_state.hash_tree_root()

    return post_state, store, last_signed_block


def is_ready_to_justify(spec, state):
    """
    Check if the given ``state`` will trigger justification updates at epoch boundary.
    """
    temp_state = state.copy()
    spec.process_justification_and_finalization(temp_state)
    return temp_state.current_justified_checkpoint.epoch > state.current_justified_checkpoint.epoch


def find_next_justifying_slot(spec, state, fill_cur_epoch, fill_prev_epoch, participation_fn=None):
    temp_state = state.copy()

    signed_blocks = []
    justifying_slot = None
    while justifying_slot is None:
        signed_block = state_transition_with_full_block(
            spec,
            temp_state,
            fill_cur_epoch,
            fill_prev_epoch,
            participation_fn,
        )
        signed_blocks.append(signed_block)

        if is_ready_to_justify(spec, temp_state):
            justifying_slot = temp_state.slot

    return signed_blocks, justifying_slot


def get_pow_block_file_name(pow_block):
    return f"pow_block_{encode_hex(pow_block.block_hash)}"


def add_pow_block(spec, store, pow_block, test_steps):
    yield get_pow_block_file_name(pow_block), pow_block
    test_steps.append({"pow_block": get_pow_block_file_name(pow_block)})


def is_ancestor(spec, store, root_or_node, maybe_ancestor_root_or_node) -> bool:
    if hasattr(root_or_node, "root"):
        node = root_or_node
    else:
        node = get_fork_choice_node(spec, root_or_node)

    if hasattr(maybe_ancestor_root_or_node, "root"):
        maybe_ancestor = maybe_ancestor_root_or_node
    else:
        maybe_ancestor = get_fork_choice_node(spec, maybe_ancestor_root_or_node)

    return spec.is_ancestor(store, node, maybe_ancestor)


def tick_store_to_slot(spec, store, slot, test_steps):
    """
    Tick the store forward to the start of ``slot``.
    """
    slot_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, slot)
    if store.time_ms < slot_time_ms:
        on_tick_and_append_step(spec, store, slot_time_ms, test_steps)


def add_signed_empty_block(spec, store, state, test_steps):
    """
    Build, sign, and submit an empty block at ``state.slot + 1``.
    """
    block = build_empty_block_for_next_slot(spec, state)
    signed_block = state_transition_and_sign_block(spec, state, block)
    yield from tick_and_add_block(spec, store, signed_block, test_steps)

    root = signed_block.message.hash_tree_root()
    return root, store.block_states[root], signed_block


def setup_one_block_store(spec, state):
    """
    Bootstrap a fork choice store with the genesis anchor plus an empty block at slot 1.
    """
    test_steps = []
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)

    yield "anchor_state", state
    yield "anchor_block", anchor_block

    tick_store_to_slot(spec, store, state.slot, test_steps)
    block_root, block_state, signed_block = yield from add_signed_empty_block(
        spec, store, state, test_steps
    )
    return store, block_root, block_state, signed_block, test_steps


def setup_finalized_store(spec, state):
    """
    Bootstrap a fork choice store and drive a justifying and finalizing chain by
    filling three epochs with attestations from the genesis anchor.
    """
    test_steps = []
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)

    yield "anchor_state", state
    yield "anchor_block", anchor_block

    tick_store_to_slot(spec, store, state.slot, test_steps)
    next_epoch(spec, state)
    tick_store_to_slot(spec, store, state.slot, test_steps)

    for _ in range(3):
        state, store, _ = yield from apply_next_epoch_with_attestations(
            spec,
            state,
            store,
            fill_cur_epoch=True,
            fill_prev_epoch=True,
            test_steps=test_steps,
        )
    return store, state, test_steps
