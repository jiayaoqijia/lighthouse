from eth_consensus_specs.test.context import (
    MINIMAL,
    never_bls,
    only_generator,
    spec_state_test,
    with_altair_and_later,
    with_presets,
)
from eth_consensus_specs.test.helpers.fast_confirmation import (
    Attesting,
    FCRTest,
    Slashing,
    SlotSequence,
)

"""
Test is_confirmed_chain_safe
"""


@only_generator("too slow")
@with_altair_and_later
@spec_state_test
@with_presets([MINIMAL], reason="too slow")
@never_bls
def test_reconfirmation_passes_with_empty_slots_prior_first_block(spec, state):
    """
    1. Build until last slot of epoch 2 with 100% participation
    2. Leave last slot of epoch 2 empty
    3. Leave first slot of epoch 3 empty
    4. Slash 25% of validators in these two slots
    5. Run until the start of epoch 3 with blocks and 100% participation.
       Confirm the first block in epoch 3.
    6. Check that reconfirmation did not fail
       In this case reconfirmation will involve committees and equivocated validators
       from current_epoch - 2.
    """
    fcr = FCRTest(spec, seed=1)
    store, fcr_store = fcr.initialize(state)

    S = spec.SLOTS_PER_EPOCH

    # Run until last slot of epoch 2
    fcr.run_slots_with_blocks_and_fast_confirmation(3 * S - 1, participation_rate=100)

    confirmed_at_last_slot_epoch_2 = fcr_store.confirmed_root

    # Leave last slot empty
    fcr.attest_and_next_slot_with_fast_confirmation(participation_rate=100)

    # Check that reconfirmation passed
    assert fcr_store.confirmed_root == confirmed_at_last_slot_epoch_2

    # Epoch 3, Slot 1, empty slot
    fcr.attest_and_next_slot_with_fast_confirmation(participation_rate=100)

    # Epoch 3, Slot 2, with block
    fcr.next_slot_with_block_and_fast_confirmation(participation_rate=100)

    # Check that confirmed block was not advanced
    assert fcr_store.confirmed_root == confirmed_at_last_slot_epoch_2

    # Epoch 3, Slot 3

    # Slash participants of (Epoch 2, last slot) and (Epoch 3, first slot)
    Slashing(percentage=25, committee_slot_or_offset=3 * S - 1).execute(fcr)
    Slashing(percentage=25, committee_slot_or_offset=3 * S).execute(fcr)

    # Advance with block and attest to add a bit more weight to overcome the committee shuffling dispersion
    fcr.next_slot_with_block_and_fast_confirmation(participation_rate=100)
    fcr.attest_and_next_slot_with_fast_confirmation(participation_rate=75)

    # Check the head is confirmed
    assert fcr_store.confirmed_root == fcr.head_root()

    # But if there were no slashings, first block in Epoch 3 couldn't be confirmed at this stage
    epoch_3_first_block = spec.get_ancestor(store, fcr.head(), 3 * S + 1)
    balance_source = spec.get_current_balance_source(fcr_store)
    support = spec.get_attestation_score(store, epoch_3_first_block, balance_source)
    safety_threshold = spec.compute_safety_threshold(
        store, epoch_3_first_block.root, balance_source
    )

    # Compute slashed balance
    # 25% of 2 slots * (len(validators) // SLOTS_PER_EPOCH * effective_balance)
    slashed_balance = 2 * (
        len(state.validators) // spec.Uint64(S) * state.validators[0].effective_balance // 4
    )

    # Add a half of slashed balance back to the safety threshold
    # and check the support would be lower than the threshold
    assert support < safety_threshold + slashed_balance // 2

    # Run till last slot of Epoch 3
    SlotSequence(end_slot=(4 * S - 1), attesting=Attesting(participation_rate=100)).execute(fcr)

    # Check the head was confirmed
    assert fcr_store.confirmed_root == fcr.head_root()

    # Run to the start of Epoch 4 with no block
    fcr.attest_and_next_slot_with_fast_confirmation(participation_rate=100)

    # Check reconfirmation passed
    assert fcr_store.confirmed_root == fcr.head_root()

    yield from fcr.get_test_artefacts()


@only_generator("too slow")
@with_altair_and_later
@spec_state_test
@with_presets([MINIMAL], reason="too slow")
@never_bls
def test_reconfirmation_fails_for_block_without_uj_checkpoint_in_chain(spec, state):
    fcr = FCRTest(spec, seed=1)
    store, fcr_store = fcr.initialize(state)

    S = spec.SLOTS_PER_EPOCH

    # Run until the last slot of epoch 2
    fcr.run_slots_with_blocks_and_fast_confirmation(3 * S - 1, participation_rate=100)

    # Pivot at the end of epoch 2
    pivot_root = fcr.next_slot_with_block_and_fast_confirmation(
        participation_rate=100, graffiti="pivot"
    )

    # Run till the penultimate slot of epoch 3
    fcr.run_slots_with_blocks_and_fast_confirmation(S - 2, participation_rate=100)

    # Create a conflicting block that justifies a checkpoint not in the chain of confirmed block
    # while the block of that checkpoint is in the chain of confirmed block
    pivot_attestations = []
    for s in range(3 * S, fcr.current_slot()):
        pivot_attestations.extend(
            fcr.attest(
                block_root=pivot_root, participation_rate=100, slot=s, pool_and_disseminate=False
            )
        )
    fcr.add_and_apply_block(
        parent_root=pivot_root,
        graffiti="conflicting",
        attestations=pivot_attestations,
        release_att_pool=False,
        include_atts=False,
    )

    # Fast confirm one block
    fcr.next_slot_with_block_and_fast_confirmation(participation_rate=100)

    # Create the last confirmed block in an epoch and move to the next slot
    confirmed_root = fcr.next_slot_with_block(participation_rate=100, graffiti="confirmed")

    # Check preconditions over confirmed_root
    # From fresh epoch
    assert spec.get_block_epoch(store, confirmed_root) + 1 >= fcr.current_epoch()
    # Belongs to canonical chain
    assert spec.is_ancestor(store, fcr.head(), spec.get_node_for_root(confirmed_root))
    # Ancestor of the previous_epoch_greatest_unrealized_checkpoint block
    assert spec.is_ancestor(
        store,
        spec.get_node_for_root(confirmed_root),
        spec.get_node_for_root(fcr_store.previous_epoch_greatest_unrealized_checkpoint.root),
    )
    # Does not have a previous_epoch_greatest_unrealized_checkpoint in its chain
    assert fcr_store.previous_epoch_greatest_unrealized_checkpoint != spec.get_checkpoint_for_block(
        store, confirmed_root, fcr_store.previous_epoch_greatest_unrealized_checkpoint.epoch
    )

    # Run fast confirmation and ensure fall back to finality
    fcr.run_fast_confirmation()
    assert fcr_store.confirmed_root == store.finalized_checkpoint.root

    yield from fcr.get_test_artefacts()


@only_generator("too slow")
@with_altair_and_later
@spec_state_test
@with_presets([MINIMAL], reason="too slow")
@never_bls
def test_reconfirmation_is_not_failing_till_epoch_start(spec, state):
    fcr = FCRTest(spec, seed=1)
    store, fcr_store = fcr.initialize(state)

    S = spec.SLOTS_PER_EPOCH
    fcr.next_slot_with_block_and_fast_confirmation(participation_rate=100)
    # Confirm a block
    confirmed_root = fcr.next_slot_with_block_and_fast_confirmation(participation_rate=100)

    # Proceed with zero participation till the last slot of an epoch
    while fcr.current_slot() < S - 1:
        fcr.next_slot_with_block_and_fast_confirmation(participation_rate=0)
        # Reconfirmation would fail
        assert not spec.is_confirmed_chain_safe(fcr_store, fcr_store.confirmed_root)
        # But no reversion of confirmed block happens
        assert fcr_store.confirmed_root == confirmed_root

    # Confirmed block reverted to finalized block at the start of an epoch
    fcr.next_slot_with_block_and_fast_confirmation(participation_rate=0)
    assert fcr_store.confirmed_root == store.finalized_checkpoint.root

    yield from fcr.get_test_artefacts()
