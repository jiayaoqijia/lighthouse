from eth_consensus_specs.test.context import (
    spec_state_test,
    with_all_phases_from_to,
    with_bellatrix_and_later,
    with_bellatrix_only,
)
from eth_consensus_specs.test.helpers.block import (
    build_empty_block_for_next_slot,
    sign_block,
)
from eth_consensus_specs.test.helpers.constants import BELLATRIX, GLOAS
from eth_consensus_specs.test.helpers.execution_payload import (
    build_empty_execution_payload,
    build_state_with_complete_transition,
    build_state_with_incomplete_transition,
)
from eth_consensus_specs.test.helpers.fork_choice import (
    get_genesis_forkchoice_store_and_block,
)
from eth_consensus_specs.test.helpers.forks import is_post_gloas
from eth_consensus_specs.test.helpers.gossip import (
    get_filename,
    get_seen,
    get_spec_block_payload_statuses,
    PAYLOAD_STATUS_INVALIDATED,
    PAYLOAD_STATUS_NOT_VALIDATED,
    PAYLOAD_STATUS_VALID,
    run_validate_gossip,
    wrap_genesis_block,
)
from eth_consensus_specs.test.helpers.state import (
    state_transition_and_sign_block,
)


@with_bellatrix_and_later
@spec_state_test
def test_gossip_beacon_block__valid_execution_enabled(spec, state):
    """
    Test that a valid block with execution enabled passes gossip validation.
    """
    yield "topic", "meta", "beacon_block"

    state = build_state_with_complete_transition(spec, state)
    anchor_state = state.copy()
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    block = build_empty_block_for_next_slot(spec, state)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield get_filename(signed_block), signed_block

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, signed_block.message.slot)

    kwargs = {}
    if not is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_beacon_block=signed_block,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "valid"
    assert reason is None

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_block),
                "expected": "valid",
            }
        ],
    )


@with_bellatrix_only
@spec_state_test
def test_gossip_beacon_block__valid_execution_disabled(spec, state):
    """
    Test that a valid block with execution disabled passes gossip validation.
    """
    yield "topic", "meta", "beacon_block"

    state = build_state_with_incomplete_transition(spec, state)
    anchor_state = state.copy()
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    block = build_empty_block_for_next_slot(spec, state)
    block.body.execution_payload = spec.ExecutionPayload()
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield get_filename(signed_block), signed_block

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, signed_block.message.slot)

    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_beacon_block=signed_block,
        current_time_ms=current_time_ms,
        block_payload_statuses={},
    )
    assert result == "valid"
    assert reason is None

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_block),
                "expected": "valid",
            }
        ],
    )


@with_all_phases_from_to(BELLATRIX, GLOAS)
@spec_state_test
def test_gossip_beacon_block__reject_incorrect_execution_payload_timestamp(spec, state):
    """
    Test that a block with incorrect execution payload timestamp is rejected.
    """
    yield "topic", "meta", "beacon_block"

    state = build_state_with_complete_transition(spec, state)
    anchor_state = state.copy()
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    block = build_empty_block_for_next_slot(spec, state)

    # Corrupt the execution payload timestamp
    block.body.execution_payload.timestamp = 0

    signed_block = sign_block(spec, state, block, proposer_index=block.proposer_index)

    yield get_filename(signed_block), signed_block

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, block.slot)

    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_beacon_block=signed_block,
        current_time_ms=current_time_ms,
        block_payload_statuses={},
    )
    assert result == "reject"
    assert reason == "incorrect execution payload timestamp"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_block),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases_from_to(BELLATRIX, GLOAS)
@spec_state_test
def test_gossip_beacon_block__reject_parent_consensus_failed_execution_not_verified(spec, state):
    """
    Test that when execution is enabled and parent's execution status is
    unknown, a block whose parent failed consensus validation is rejected.
    """
    yield "topic", "meta", "beacon_block"

    state = build_state_with_complete_transition(spec, state)
    anchor_state = state.copy()
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)

    yield get_filename(signed_anchor), signed_anchor

    block = build_empty_block_for_next_slot(spec, state)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield get_filename(signed_block), signed_block

    # Add to store.blocks but NOT store.block_states (simulating failed consensus validation)
    store.blocks[signed_block.message.hash_tree_root()] = signed_block.message
    # Parent payload status is NOT_VALIDATED, i.e. execution is not yet validated.

    yield (
        "blocks",
        "meta",
        [
            {"block": get_filename(signed_anchor)},
            {
                "block": get_filename(signed_block),
                "failed": True,
                "payload_status": PAYLOAD_STATUS_NOT_VALIDATED,
            },
        ],
    )

    # Build child block referencing the "failed" parent
    child_slot = signed_block.message.slot + 1
    temp_state = state.copy()
    spec.process_slots(temp_state, child_slot)
    proposer_index = spec.get_beacon_proposer_index(temp_state)

    child_block = spec.BeaconBlock(
        slot=child_slot,
        proposer_index=proposer_index,
        parent_root=signed_block.message.hash_tree_root(),
        state_root=temp_state.hash_tree_root(),
    )
    child_block.body.execution_payload = build_empty_execution_payload(spec, temp_state)
    signed_child = sign_block(spec, temp_state, child_block, proposer_index=proposer_index)

    yield get_filename(signed_child), signed_child

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, child_block.slot)

    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_beacon_block=signed_child,
        current_time_ms=current_time_ms,
        block_payload_statuses=get_spec_block_payload_statuses(
            spec,
            {signed_block.message.hash_tree_root(): PAYLOAD_STATUS_NOT_VALIDATED},
        ),
    )
    assert result == "reject"
    assert reason == "block's parent is invalid and its payload is optimistic"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_child),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )


@with_all_phases_from_to(BELLATRIX, GLOAS)
@spec_state_test
def test_gossip_beacon_block__ignore_parent_consensus_failed_execution_known(spec, state):
    """
    Test that when execution is enabled and parent's execution status is known,
    a block whose parent failed consensus validation is ignored.
    """
    yield "topic", "meta", "beacon_block"

    state = build_state_with_complete_transition(spec, state)
    anchor_state = state.copy()
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)

    yield get_filename(signed_anchor), signed_anchor

    block = build_empty_block_for_next_slot(spec, state)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield get_filename(signed_block), signed_block

    parent_root = signed_block.message.hash_tree_root()

    # Parent has a known execution status but failed consensus validation.
    store.blocks[parent_root] = signed_block.message
    block_payload_statuses = {parent_root: PAYLOAD_STATUS_VALID}

    yield (
        "blocks",
        "meta",
        [
            {"block": get_filename(signed_anchor)},
            {
                "block": get_filename(signed_block),
                "failed": True,
                "payload_status": PAYLOAD_STATUS_VALID,
            },
        ],
    )

    child_slot = signed_block.message.slot + 1
    temp_state = state.copy()
    spec.process_slots(temp_state, child_slot)
    proposer_index = spec.get_beacon_proposer_index(temp_state)

    child_block = spec.BeaconBlock(
        slot=child_slot,
        proposer_index=proposer_index,
        parent_root=parent_root,
        state_root=temp_state.hash_tree_root(),
    )
    child_block.body.execution_payload = build_empty_execution_payload(spec, temp_state)
    signed_child = sign_block(spec, temp_state, child_block, proposer_index=proposer_index)

    yield get_filename(signed_child), signed_child

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, child_block.slot)

    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_beacon_block=signed_child,
        current_time_ms=current_time_ms,
        block_payload_statuses=get_spec_block_payload_statuses(spec, block_payload_statuses),
    )
    assert result == "ignore"
    assert reason == "block's parent is invalid and its payload is processed"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_child),
                "expected": "ignore",
                "reason": reason,
            }
        ],
    )


@with_all_phases_from_to(BELLATRIX, GLOAS)
@spec_state_test
def test_gossip_beacon_block__ignore_parent_execution_verified_invalid(spec, state):
    """
    Test that when execution is enabled and parent's execution has been verified
    as invalid, the child block is ignored.
    """
    yield "topic", "meta", "beacon_block"

    state = build_state_with_complete_transition(spec, state)
    anchor_state = state.copy()
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)

    yield get_filename(signed_anchor), signed_anchor

    block = build_empty_block_for_next_slot(spec, state)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield get_filename(signed_block), signed_block

    parent_root = signed_block.message.hash_tree_root()

    # Parent is in store.blocks and store.block_states (consensus passed),
    # but execution was verified as INVALID
    store.blocks[parent_root] = signed_block.message
    store.block_states[parent_root] = state.copy()
    block_payload_statuses = {parent_root: PAYLOAD_STATUS_INVALIDATED}

    yield (
        "blocks",
        "meta",
        [
            {"block": get_filename(signed_anchor)},
            {
                "block": get_filename(signed_block),
                "payload_status": PAYLOAD_STATUS_INVALIDATED,
            },
        ],
    )

    # Build child block
    child_slot = signed_block.message.slot + 1
    temp_state = state.copy()
    spec.process_slots(temp_state, child_slot)
    proposer_index = spec.get_beacon_proposer_index(temp_state)

    child_block = spec.BeaconBlock(
        slot=child_slot,
        proposer_index=proposer_index,
        parent_root=parent_root,
        state_root=temp_state.hash_tree_root(),
    )
    child_block.body.execution_payload = build_empty_execution_payload(spec, temp_state)
    signed_child = sign_block(spec, temp_state, child_block, proposer_index=proposer_index)

    yield get_filename(signed_child), signed_child

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, child_block.slot)

    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_beacon_block=signed_child,
        current_time_ms=current_time_ms,
        block_payload_statuses=get_spec_block_payload_statuses(spec, block_payload_statuses),
    )
    assert result == "ignore"
    assert reason == "block's parent is valid and its payload is invalid"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_child),
                "expected": "ignore",
                "reason": reason,
            }
        ],
    )


@with_all_phases_from_to(BELLATRIX, GLOAS)
@spec_state_test
def test_gossip_beacon_block__valid_parent_execution_verified_valid(spec, state):
    """
    Test that when parent's execution has been verified as valid, the child
    block passes validation.
    """
    yield "topic", "meta", "beacon_block"

    state = build_state_with_complete_transition(spec, state)
    anchor_state = state.copy()
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)

    yield get_filename(signed_anchor), signed_anchor

    block = build_empty_block_for_next_slot(spec, state)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield get_filename(signed_block), signed_block

    parent_root = signed_block.message.hash_tree_root()

    # Parent fully validated: consensus and execution both passed
    store.blocks[parent_root] = signed_block.message
    store.block_states[parent_root] = state.copy()
    block_payload_statuses = {parent_root: PAYLOAD_STATUS_VALID}

    yield (
        "blocks",
        "meta",
        [
            {"block": get_filename(signed_anchor)},
            {
                "block": get_filename(signed_block),
                "payload_status": PAYLOAD_STATUS_VALID,
            },
        ],
    )

    # Build child block
    child_slot = signed_block.message.slot + 1
    temp_state = state.copy()
    spec.process_slots(temp_state, child_slot)
    proposer_index = spec.get_beacon_proposer_index(temp_state)

    child_block = spec.BeaconBlock(
        slot=child_slot,
        proposer_index=proposer_index,
        parent_root=parent_root,
        state_root=temp_state.hash_tree_root(),
    )
    child_block.body.execution_payload = build_empty_execution_payload(spec, temp_state)
    signed_child = sign_block(spec, temp_state, child_block, proposer_index=proposer_index)

    yield get_filename(signed_child), signed_child

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, child_block.slot)

    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_beacon_block=signed_child,
        current_time_ms=current_time_ms,
        block_payload_statuses=get_spec_block_payload_statuses(spec, block_payload_statuses),
    )
    assert result == "valid"
    assert reason is None

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_child),
                "expected": "valid",
            }
        ],
    )


@with_all_phases_from_to(BELLATRIX, GLOAS)
@spec_state_test
def test_gossip_beacon_block__valid_parent_optimistic(spec, state):
    """
    Test that when parent's execution verification is not yet complete
    (optimistic) but consensus validation passed, the child block passes.
    """
    yield "topic", "meta", "beacon_block"

    state = build_state_with_complete_transition(spec, state)
    anchor_state = state.copy()
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)

    yield get_filename(signed_anchor), signed_anchor

    block = build_empty_block_for_next_slot(spec, state)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield get_filename(signed_block), signed_block

    parent_root = signed_block.message.hash_tree_root()

    # Parent passed consensus validation but execution not yet verified
    store.blocks[parent_root] = signed_block.message
    store.block_states[parent_root] = state.copy()
    block_payload_statuses = {parent_root: PAYLOAD_STATUS_NOT_VALIDATED}

    yield (
        "blocks",
        "meta",
        [
            {"block": get_filename(signed_anchor)},
            {
                "block": get_filename(signed_block),
                "payload_status": PAYLOAD_STATUS_NOT_VALIDATED,
            },
        ],
    )

    # Build child block
    child_slot = signed_block.message.slot + 1
    temp_state = state.copy()
    spec.process_slots(temp_state, child_slot)
    proposer_index = spec.get_beacon_proposer_index(temp_state)

    child_block = spec.BeaconBlock(
        slot=child_slot,
        proposer_index=proposer_index,
        parent_root=parent_root,
        state_root=temp_state.hash_tree_root(),
    )
    child_block.body.execution_payload = build_empty_execution_payload(spec, temp_state)
    signed_child = sign_block(spec, temp_state, child_block, proposer_index=proposer_index)

    yield get_filename(signed_child), signed_child

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, child_block.slot)

    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_beacon_block=signed_child,
        current_time_ms=current_time_ms,
        block_payload_statuses=get_spec_block_payload_statuses(spec, block_payload_statuses),
    )
    assert result == "valid"
    assert reason is None

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_child),
                "expected": "valid",
            }
        ],
    )
