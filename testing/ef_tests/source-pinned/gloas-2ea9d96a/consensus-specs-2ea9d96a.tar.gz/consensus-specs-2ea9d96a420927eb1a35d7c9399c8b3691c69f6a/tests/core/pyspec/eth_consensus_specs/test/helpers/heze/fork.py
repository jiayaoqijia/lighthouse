from eth_consensus_specs.test.helpers.constants import (
    HEZE,
)

HEZE_FORK_TEST_META_TAGS = {
    "fork": HEZE,
}


def run_fork_test(post_spec, pre_state):
    yield "pre", pre_state

    # The upgrade keeps the collections it is handed rather than copying
    # them, so it is given a copy: the pre-state is the test's own, and is
    # still yielded above as what the fork started from.
    post_state = post_spec.upgrade_to_heze(pre_state.copy())

    # Stable fields
    stable_fields = [
        "genesis_time",
        "genesis_validators_root",
        "slot",
        "latest_block_header",
        "block_roots",
        "state_roots",
        "historical_roots",
        "validators",
        "balances",
        "randao_mixes",
        "slashings",
        "previous_epoch_participation",
        "current_epoch_participation",
        "justification_bits",
        "previous_justified_checkpoint",
        "current_justified_checkpoint",
        "finalized_checkpoint",
        "inactivity_scores",
        "current_sync_committee",
        "next_sync_committee",
        "latest_block_hash",
        "next_withdrawal_index",
        "next_withdrawal_validator_index",
        "historical_summaries",
        "deposit_balance_to_consume",
        "exit_balance_to_consume",
        "earliest_exit_epoch",
        "consolidation_balance_to_consume",
        "earliest_consolidation_epoch",
        "pending_deposits",
        "pending_partial_withdrawals",
        "pending_consolidations",
        "proposer_lookahead",
        "builders",
        "next_withdrawal_builder_index",
        "execution_payload_availability",
        "builder_pending_payments",
        "builder_pending_withdrawals",
        "payload_expected_withdrawals",
        "ptc_window",
    ]
    for field in stable_fields:
        assert getattr(pre_state, field) == getattr(post_state, field)

    # Modified fields
    modified_fields = [
        "fork",
        "latest_execution_payload_bid",
    ]
    for field in modified_fields:
        assert getattr(pre_state, field) != getattr(post_state, field)

    assert len(pre_state.validators) == len(post_state.validators)
    for pre_validator, post_validator in zip(
        pre_state.validators, post_state.validators, strict=False
    ):
        stable_validator_fields = [
            "pubkey",
            "withdrawal_credentials",
            "slashed",
            "activation_epoch",
            "exit_epoch",
            "withdrawable_epoch",
        ]
        for field in stable_validator_fields:
            assert getattr(pre_validator, field) == getattr(post_validator, field)

    assert pre_state.fork.current_version == post_state.fork.previous_version
    assert post_state.fork.current_version == post_spec.config.HEZE_FORK_VERSION
    assert post_state.fork.epoch == post_spec.get_current_epoch(post_state)

    yield "post", post_state

    return post_state
