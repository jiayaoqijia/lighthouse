import random

from eth_consensus_specs.test.context import (
    spec_state_test,
    with_deneb_and_later,
)
from eth_consensus_specs.test.helpers.blob import (
    build_block_with_blobs_for_next_slot,
    get_max_blob_count,
)
from eth_consensus_specs.test.helpers.block import sign_block
from eth_consensus_specs.test.helpers.execution_payload import (
    build_state_with_complete_transition,
)
from eth_consensus_specs.test.helpers.fork_choice import (
    get_genesis_forkchoice_store_and_block,
)
from eth_consensus_specs.test.helpers.forks import is_post_gloas
from eth_consensus_specs.test.helpers.gossip import (
    get_filename,
    get_seen,
    run_validate_gossip,
    wrap_genesis_block,
)


@with_deneb_and_later
@spec_state_test
def test_gossip_beacon_block__valid_with_blob_kzg_commitments(spec, state):
    """
    Test that a valid block carrying blob kzg commitments passes gossip validation.
    """
    yield "topic", "meta", "beacon_block"

    state = build_state_with_complete_transition(spec, state)
    anchor_state = state.copy()
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    rng = random.Random(1234)
    block, _, _, _ = build_block_with_blobs_for_next_slot(spec, state, rng=rng)
    signed_block = sign_block(spec, state, block, proposer_index=block.proposer_index)

    yield get_filename(signed_block), signed_block

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, signed_block.message.slot)

    kwargs = {}
    if not is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_beacon_block=signed_block,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "valid"
    assert reason is None

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_block),
                "expected": "valid",
            }
        ],
    )


@with_deneb_and_later
@spec_state_test
def test_gossip_beacon_block__reject_too_many_kzg_commitments(spec, state):
    """
    Test that a block with more blob kzg commitments than MAX_BLOBS_PER_BLOCK is rejected.
    """
    yield "topic", "meta", "beacon_block"

    state = build_state_with_complete_transition(spec, state)
    anchor_state = state.copy()
    yield "state", anchor_state

    seen = get_seen(spec)
    store, anchor_block = get_genesis_forkchoice_store_and_block(spec, state)
    signed_anchor = wrap_genesis_block(spec, anchor_block)

    yield get_filename(signed_anchor), signed_anchor
    yield "blocks", "meta", [{"block": get_filename(signed_anchor)}]

    rng = random.Random(1234)
    max_blobs = get_max_blob_count(spec, state.slot + 1)
    block, _, _, _ = build_block_with_blobs_for_next_slot(
        spec, state, rng=rng, blob_count=max_blobs + 1
    )
    signed_block = sign_block(spec, state, block, proposer_index=block.proposer_index)

    yield get_filename(signed_block), signed_block

    current_time_ms = spec.compute_time_at_slot_ms(store.genesis_time_ms, block.slot)

    kwargs = {}
    if not is_post_gloas(spec):
        kwargs["block_payload_statuses"] = {}
    current_time_ms += 500
    result, reason = run_validate_gossip(
        spec,
        seen=seen,
        store=store,
        signed_beacon_block=signed_block,
        current_time_ms=current_time_ms,
        **kwargs,
    )
    assert result == "reject"
    assert reason == "too many blob kzg commitments"

    yield (
        "messages",
        "meta",
        [
            {
                "current_time_ms": int(current_time_ms),
                "message": get_filename(signed_block),
                "expected": "reject",
                "reason": reason,
            }
        ],
    )
