from collections.abc import Callable
from dataclasses import dataclass, field, fields, replace
from random import Random

from eth_utils import encode_hex

from eth_consensus_specs.test.helpers.attestations import (
    get_valid_attestations_for_block_at_slot,
)
from eth_consensus_specs.test.helpers.attester_slashings import (
    get_valid_attester_slashing_by_indices,
)
from eth_consensus_specs.test.helpers.block import (
    build_block_and_payload,
)
from eth_consensus_specs.test.helpers.execution_payload import (
    compute_and_sign_execution_payload_envelope,
)
from eth_consensus_specs.test.helpers.fork_choice import (
    add_attester_slashing,
    add_block,
    add_execution_payload,
    get_attestation_file_name,
    get_basic_store_checks,
    get_genesis_forkchoice_store_and_block,
)
from eth_consensus_specs.test.helpers.forks import (
    is_post_bellatrix,
    is_post_electra,
    is_post_gloas,
)
from eth_consensus_specs.test.helpers.genesis import (
    GENESIS_ETH1_BLOCK_HASH,
    get_sample_genesis_execution_payload,
)
from eth_consensus_specs.test.helpers.state import (
    state_transition_and_sign_block,
    transition_to,
)

DEBUG = False


def debug_print(*args, **kwargs):
    if DEBUG:
        print(*args, **kwargs)


def output_fast_confirmation_checks(spec, fcr_store, test_steps):
    basic_checks = get_basic_store_checks(spec, fcr_store.store)
    fcr_checks = {
        "previous_epoch_observed_justified_checkpoint": {
            "epoch": int(fcr_store.previous_epoch_observed_justified_checkpoint.epoch),
            "root": encode_hex(fcr_store.previous_epoch_observed_justified_checkpoint.root),
        },
        "current_epoch_observed_justified_checkpoint": {
            "epoch": int(fcr_store.current_epoch_observed_justified_checkpoint.epoch),
            "root": encode_hex(fcr_store.current_epoch_observed_justified_checkpoint.root),
        },
        "previous_epoch_greatest_unrealized_checkpoint": {
            "epoch": int(fcr_store.previous_epoch_greatest_unrealized_checkpoint.epoch),
            "root": encode_hex(fcr_store.previous_epoch_greatest_unrealized_checkpoint.root),
        },
        "previous_slot_head": encode_hex(fcr_store.previous_slot_head),
        "current_slot_head": encode_hex(fcr_store.current_slot_head),
        "confirmed_root": encode_hex(fcr_store.confirmed_root),
    }

    if is_post_bellatrix(spec):
        fcr_checks["safe_execution_block_hash"] = encode_hex(
            spec.get_safe_execution_block_hash(fcr_store)
        )

    test_steps.append({"checks": basic_checks | fcr_checks})


def on_fast_confirmation_and_append_step(spec, fcr_store, test_steps):
    spec.on_fast_confirmation(fcr_store)
    output_fast_confirmation_checks(spec, fcr_store, test_steps)


def str_to_graffiti(graffiti: str) -> bytes:
    return bytes(graffiti, "ascii").ljust(32, b"\x00")


def graffiti_to_str(graffiti: bytes) -> str:
    return graffiti.rstrip(b"\x00").decode("ascii")


class FCRTest:
    def __init__(self, spec, seed):
        self.spec = spec
        self.seed = seed

    def initialize(self, anchor_state):
        # Initialization
        test_steps = []
        store, anchor_block = get_genesis_forkchoice_store_and_block(self.spec, anchor_state)
        fcr_store = self.spec.get_fast_confirmation_store(store)

        self.rng = Random(self.seed)
        self.store = store
        self.fcr_store = fcr_store
        self.test_steps = test_steps
        self.attestation_pool = []
        self.recent_attestations = []
        self.blockchain_artefacts = []

        # Tick
        self.tick(self.spec.GENESIS_SLOT)

        self.blockchain_artefacts.append(("anchor_state", anchor_state))
        self.blockchain_artefacts.append(("anchor_block", anchor_block))

        return store, fcr_store

    def get_test_artefacts(self):
        return self.blockchain_artefacts + [("steps", self.test_steps)]

    def current_slot(self):
        return self.spec.get_current_slot(self.store)

    def current_epoch(self):
        return self.spec.get_current_store_epoch(self.store)

    def head(self):
        return self.spec.get_head(self.store)

    def head_root(self):
        return self.head().root

    def get_parent(self, block_root):
        parent_root = self.store.blocks[block_root].parent_root
        return self.store.blocks[parent_root]

    def get_children(self, block_root):
        return [
            root for root in self.store.blocks if self.store.blocks[root].parent_root == block_root
        ]

    def find_block_root(self, predicate: Callable[[object], bool]) -> object:
        for root, block in self.store.blocks.items():
            if predicate(block):
                return root

        raise KeyError("Block not found")

    def resolve_slot_by_offset(self, offset_or_slot):
        if offset_or_slot > 0:
            return self.spec.Slot(offset_or_slot)
        else:
            return self.spec.Slot(int(self.current_slot()) + offset_or_slot)

    def get_block_root_or_head(self, block_root_id):
        if block_root_id is None:
            return self.head_root()

        if isinstance(block_root_id, int):
            # Slot or offset
            slot = self.resolve_slot_by_offset(block_root_id)
            return self.find_block_root(lambda b: b.slot == slot)
        elif isinstance(block_root_id, str):
            # Graffiti
            graffiti = str_to_graffiti(block_root_id)
            return self.find_block_root(lambda b: b.body.graffiti == graffiti)
        else:
            # Block root
            return block_root_id

    def get_supporters_of(self, block_root_id) -> list[object]:
        block_root = self.get_block_root_or_head(block_root_id)
        return [i for i, m in self.store.latest_messages.items() if m.root == block_root]

    def tick(self, slot):
        assert slot > self.current_slot() or slot == self.spec.GENESIS_SLOT
        new_time_ms = self.spec.compute_time_at_slot_ms(self.store.genesis_time_ms, slot)
        self.spec.on_tick(self.store, new_time_ms)
        self.test_steps.append({"tick": int(self.spec.milliseconds_to_seconds(new_time_ms))})

    def next_slot(self):
        self.tick(self.current_slot() + 1)

        # Discard outdated attestations from the pool
        if self.current_slot() % self.spec.SLOTS_PER_EPOCH == 0:
            self.attestation_pool = [
                a
                for a in self.attestation_pool
                if self.spec.compute_epoch_at_slot(a.data.slot) + 1 >= self.current_epoch()
            ]

        # Apply recent attestations
        self.apply_attestations(self.recent_attestations)
        self.recent_attestations = []

    def max_attestations(self):
        if is_post_electra(self.spec):
            return self.spec.MAX_ATTESTATIONS_ELECTRA
        else:
            return self.spec.MAX_ATTESTATIONS

    def get_parent_payload(self, parent_root):
        assert is_post_bellatrix(self.spec)

        root, block = parent_root, self.store.blocks[parent_root]
        while (
            is_post_gloas(self.spec)
            and not self.spec.is_payload_verified(self.store, root)
            and block.slot > self.spec.GENESIS_SLOT
        ):
            block = self.store.blocks[root]
            root = block.parent_root

        if block.slot == self.spec.GENESIS_SLOT:
            return get_sample_genesis_execution_payload(
                self.spec, eth1_block_hash=GENESIS_ETH1_BLOCK_HASH
            )

        if is_post_gloas(self.spec):
            return self.store.payloads[root].payload
        else:
            return block.body.execution_payload

    def add_and_apply_block(
        self,
        parent_root=None,
        release_att_pool=True,
        graffiti: str | None = None,
        include_atts=True,
        attestations=None,
        include_att_fn: Callable[[object, object], bool] | None = None,
        deposit_requests=None,
        exits=None,
        parent_full=True,
    ):
        # Only Gloas and later can build on an empty parent payload node.
        assert parent_full or is_post_gloas(self.spec)
        if parent_root is None:
            parent_root = self.head_root()
        else:
            assert parent_root in self.store.blocks

        current_slot = self.current_slot()

        # Return anchor_block root for GENESIS_SLOT
        if current_slot == self.spec.GENESIS_SLOT:
            return self.store.finalized_checkpoint.root

        parent_state = self.store.block_states[parent_root].copy()
        assert parent_state.slot < current_slot

        # Obtain parent payload or its header
        if is_post_bellatrix(self.spec) and parent_full:
            parent_payload = self.get_parent_payload(parent_root)
        else:
            parent_payload = None

        # Execution requests
        execution_requests = None
        if is_post_electra(self.spec):
            execution_requests = self.spec.ExecutionRequests()
            if deposit_requests is not None:
                if not is_post_gloas(self.spec):
                    assert len(deposit_requests) <= self.spec.MAX_DEPOSIT_REQUESTS_PER_PAYLOAD
                for d in deposit_requests:
                    execution_requests.deposits.append(d)

        # Build a block for current_slot with attestations from pool
        # build_block_and_payload will advance the state to current_slot if necessary
        block, payload = build_block_and_payload(
            self.spec,
            parent_state,
            current_slot,
            parent_payload=parent_payload,
            execution_requests=execution_requests,
        )

        # Graffiti
        if graffiti is not None:
            block.body.graffiti = str_to_graffiti(graffiti)

        # Attestations
        if attestations is not None:
            for att in attestations[: self.max_attestations()]:
                block.body.attestations.append(att)
        elif include_atts:
            for att in self.attestation_pool:
                if att.data.slot + self.spec.MIN_ATTESTATION_INCLUSION_DELAY > block.slot:
                    continue

                if is_post_electra(self.spec):
                    if self.spec.compute_epoch_at_slot(
                        att.data.slot
                    ) + 1 < self.spec.compute_epoch_at_slot(block.slot):
                        continue
                elif att.data.slot + self.spec.SLOTS_PER_EPOCH < block.slot:
                    continue

                if include_att_fn is None or include_att_fn(block, att):
                    block.body.attestations.append(att)

                if len(block.body.attestations) >= self.max_attestations():
                    break

            # Release included attestations from the pool
            if release_att_pool:
                included_atts = set(block.body.attestations)
                self.attestation_pool = [
                    att for att in self.attestation_pool if att not in included_atts
                ]

        # Beacon operations
        if exits is not None:
            assert len(exits) <= self.spec.MAX_VOLUNTARY_EXITS
            for e in exits:
                block.body.voluntary_exits.append(e)

        # Set parent execution requests post-Gloas
        if (
            is_post_gloas(self.spec)
            and parent_full
            and self.spec.is_payload_verified(self.store, parent_root)
        ):
            parent_envelope = self.store.payloads[parent_root]
            block.body.parent_execution_requests = parent_envelope.execution_requests

        # Sign block and add it to the Store
        signed_block = state_transition_and_sign_block(self.spec, parent_state, block)
        block_root = self.spec.hash_tree_root(block)
        for artefact in add_block(self.spec, self.store, signed_block, self.test_steps):
            self.blockchain_artefacts.append(artefact)

        # Build and reveal execution payload post-Gloas
        if is_post_gloas(self.spec):
            signed_envelope = compute_and_sign_execution_payload_envelope(
                self.spec, parent_state, block_root, signed_block, payload, execution_requests
            )
            for artefact in add_execution_payload(
                self.spec, self.store, signed_envelope, self.test_steps
            ):
                self.blockchain_artefacts.append(artefact)

        return block_root

    def attest(
        self,
        block_root=None,
        slot=None,
        participation_rate=100,
        pool_and_disseminate=True,
        attester_indices=None,
        payload_index=None,
    ):
        assert 0 <= participation_rate <= 100
        assert payload_index is None or is_post_gloas(self.spec)

        # Do not attest if participation is zero
        if participation_rate == 0:
            return []

        if block_root is None:
            block_root = self.head_root()
        else:
            assert block_root in self.store.blocks

        if slot is None:
            slot = self.current_slot()

        att_state = self.store.block_states[block_root].copy()

        # Advance state if needed
        transition_to(self.spec, att_state, slot)

        # Prevent attesting if slot is incorrect
        # or too old such that committee shuffling would be incorrect
        assert slot >= att_state.slot
        assert self.spec.get_current_epoch(att_state) == self.spec.compute_epoch_at_slot(slot)

        # Sample active validators
        if attester_indices is not None:
            active_set = set(attester_indices)
        elif participation_rate < 100:
            active_set = self.sample_fraction_of_participants(att_state, slot, participation_rate)
        else:
            active_set = None

        # Compute payload index post-Gloas
        if is_post_gloas(self.spec):
            block = self.store.blocks[block_root]
            if payload_index is None:
                if slot > block.slot and self.spec.is_payload_verified(self.store, block_root):
                    payload_index = 1
                else:
                    payload_index = 0
        else:
            payload_index = None

        # Attest and add attestations to the pool
        attestations = get_valid_attestations_for_block_at_slot(
            self.spec,
            att_state,
            slot,
            block_root,
            participation_fn=(
                lambda slot, index, committee: (
                    committee & active_set if active_set is not None else committee
                )
            ),
            payload_index=payload_index,
        )
        if pool_and_disseminate:
            self.attestation_pool.extend(attestations)
            self.recent_attestations.extend(attestations)

            # Yield test data
            for attestation in attestations:
                self.blockchain_artefacts.append(
                    (get_attestation_file_name(attestation), attestation)
                )

        return attestations

    def apply_attestations(self, attestations):
        # Apply attestations to the fork choice
        for attestation in attestations:
            self.spec.on_attestation(self.store, attestation, is_from_block=False)
            self.test_steps.append({"attestation": get_attestation_file_name(attestation)})

    def run_fast_confirmation(self):
        on_fast_confirmation_and_append_step(self.spec, self.fcr_store, self.test_steps)

    def next_slot_with_block(
        self,
        participation_rate=100,
        parent_root=None,
        graffiti=None,
        release_att_pool=True,
        include_atts=True,
    ):
        block_root = self.add_and_apply_block(
            parent_root=parent_root,
            graffiti=graffiti,
            release_att_pool=release_att_pool,
            include_atts=include_atts,
        )
        self.attest(
            block_root=self.head_root(),
            slot=self.current_slot(),
            participation_rate=participation_rate,
        )
        self.next_slot()
        return block_root

    def next_slot_with_block_and_fast_confirmation(
        self,
        participation_rate=100,
        parent_root=None,
        graffiti=None,
        release_att_pool=True,
        include_atts=True,
    ):
        block_root = self.next_slot_with_block(
            participation_rate, parent_root, graffiti, release_att_pool, include_atts
        )
        self.run_fast_confirmation()
        return block_root

    def attest_and_next_slot_with_fast_confirmation(
        self, block_root=None, slot=None, participation_rate=100
    ):
        self.attest(block_root, slot, participation_rate)
        self.next_slot()
        self.run_fast_confirmation()

    def run_slots_with_blocks_and_fast_confirmation(self, number_of_slots, participation_rate=100):
        for _ in range(number_of_slots):
            self.next_slot_with_block_and_fast_confirmation(participation_rate)

    def get_slot_committee(self, shuffling_source, slot):
        committees_count = self.spec.get_committee_count_per_slot(
            shuffling_source, self.spec.compute_epoch_at_slot(slot)
        )
        committee: list[self.spec.ValidatorIndex] = []
        for i in range(committees_count):
            committee.extend(
                self.spec.get_beacon_committee(
                    shuffling_source, self.spec.Slot(slot), self.spec.CommitteeIndex(i)
                )
            )
        return committee

    def sample_fraction_of_participants(self, shuffling_source, slot, fraction):
        slot_committee = self.get_slot_committee(shuffling_source, slot)
        participants_count = len(slot_committee) * fraction // 100
        self.rng.shuffle(slot_committee)
        return set(slot_committee[:participants_count])

    def apply_attester_slashing(
        self,
        slashing_percentage: int | None = None,
        slashing_indices: list[int] | None = None,
        slot=None,
    ) -> list[object]:
        if slot is None:
            slot = self.current_slot()
        state = self.store.block_states[self.head_root()].copy()
        if slashing_indices is None:
            assert slashing_percentage is not None
            slashing_count = len(state.validators) * slashing_percentage // 100
            unslashed_indices = [idx for idx, val in enumerate(state.validators) if not val.slashed]
            self.rng.shuffle(unslashed_indices)
            slashing_indices = unslashed_indices[:slashing_count]
        else:
            assert len(slashing_indices) > 0

        transition_to(self.spec, state, slot)

        attester_slashing = get_valid_attester_slashing_by_indices(
            self.spec, state, sorted(slashing_indices), slot=slot, signed_1=True, signed_2=True
        )

        for artefact in add_attester_slashing(
            self.spec, self.store, attester_slashing, self.test_steps
        ):
            self.blockchain_artefacts.append(artefact)

        return attester_slashing

    def compute_score_and_threshold(self, block_root) -> (int, int):
        balance_source = self.spec.get_current_balance_source(self.fcr_store)
        node = self.spec.get_node_for_root(block_root)
        score = self.spec.get_attestation_score(self.store, node, balance_source)
        safety_threshold = self.spec.compute_safety_threshold(
            self.store, block_root, balance_source
        )
        return int(score), int(safety_threshold)

    def print_root(self, block_root):
        return f"0x{block_root.hex()[:4]}"

    def get_slot_root_info(self, block_root):
        if block_root == self.spec.Root():
            slot = self.spec.GENESIS_SLOT
            graffiti = "genesis"
        else:
            block = self.store.blocks[block_root]
            slot = block.slot
            graffiti = graffiti_to_str(block.body.graffiti)

        if len(graffiti) > 0:
            return f"{slot}: {self.print_root(block_root)}, '{graffiti}'"
        else:
            return f"{slot}: {self.print_root(block_root)}"

    def get_checkpoint_info(self, checkpoint):
        return f"{checkpoint.epoch}: {self.print_root(checkpoint.root)}"

    def print_fast_confirmed_block_tree(self, start_root):
        if not DEBUG:
            return

        spec = self.spec
        store = self.store
        fcr_store = self.fcr_store

        balance_source = spec.get_current_balance_source(fcr_store)
        total_active_balance = spec.get_total_active_balance(balance_source)
        one_committee_weight = spec.Gwei(int(total_active_balance) // int(spec.SLOTS_PER_EPOCH))

        def get_relative_score_and_threshold(block_root):
            score, threshold = self.compute_score_and_threshold(block_root)
            return score * 100 / one_committee_weight, threshold * 100 / one_committee_weight

        def get_one_confirmed_info(block_root):
            # Genesis block
            if spec.get_block_slot(store, block_root) == spec.GENESIS_SLOT:
                genesis_info = self.get_slot_root_info(block_root)
                if block_root == fcr_store.confirmed_root:
                    return f"\033[94m({genesis_info})\033[0m"
                else:
                    return f"\033[92m({genesis_info})\033[0m"

            score, threshold = get_relative_score_and_threshold(block_root)
            output = f"({self.get_slot_root_info(block_root)}, uj={store.unrealized_justifications[block_root].epoch}, sc={score:.1f}%, th={threshold:.1f}%)"

            if block_root == fcr_store.confirmed_root:
                # Confirmed block in Blue if can be re-confirmed, Magenta otherwise
                if score > threshold:
                    return f"\033[94m{output}\033[0m"
                else:
                    return f"\033[95m{output}\033[0m"

            # Other blocks in either green or red depending on whether they can be one_confirmed
            if score > threshold:
                return f"\033[92m{output}\033[0m"
            else:
                return f"\033[91m{output}\033[0m"

        block_infos = []
        block_root = start_root
        while True:
            block_infos.append(get_one_confirmed_info(block_root))
            children = self.get_children(block_root)

            # Continue accumulating if we are on a single branch with more blocks on it
            if len(children) == 1:
                block_root = children[0]
                continue

            # Print accumulated output if not
            debug_print(
                f"parent({self.get_slot_root_info(store.blocks[start_root].parent_root)}): {', '.join(block_infos)}"
            )

            # Print subtrees if there are any
            for root in children:
                self.print_fast_confirmed_block_tree(root)

            # Exit
            break

    def print_fast_confirmation_state(self):
        if not DEBUG:
            return

        spec = self.spec
        store = self.store
        fcr_store = self.fcr_store

        # Print epoch and slot
        debug_print(
            f"\nEpoch {self.current_epoch()}, Slot {self.current_slot() % self.spec.SLOTS_PER_EPOCH}:"
        )

        # Print block tree starting from the beginning of previous epoch
        if self.current_epoch() == spec.GENESIS_EPOCH:
            start_slot = spec.GENESIS_SLOT
        else:
            start_slot = spec.compute_start_slot_at_epoch(self.current_epoch() - 1)
        start_root = spec.get_ancestor(store, self.head(), start_slot).root
        self.print_fast_confirmed_block_tree(start_root)

        # Print head variables
        def get_head_info(head_root):
            vs = spec.get_voting_source(store, head_root)
            uj = store.unrealized_justifications[head_root]
            return f"{self.get_slot_root_info(head_root)}, vs=({self.get_checkpoint_info(vs)}), uj=({self.get_checkpoint_info(uj)})"

        debug_print(f"\nprev_head [{get_head_info(fcr_store.previous_slot_head)}]")
        debug_print(f"curr_head [{get_head_info(fcr_store.current_slot_head)}]")
        debug_print(f"head      [{get_head_info(self.head_root())}]")

        # Print prev epoch GU and current target
        curr_target = spec.get_current_target(store)
        balance_source = spec.get_pulled_up_head_state(store)
        total_active_balance = spec.get_total_active_balance(balance_source)
        ffg_support = spec.compute_honest_ffg_support_for_current_target(store)
        relative_support = int(ffg_support) * 100 / int(total_active_balance)

        debug_print(
            f"\ncurr_target [{self.get_checkpoint_info(curr_target)}, ffg_support={relative_support:.1f}%]"
        )
        debug_print(
            f"prev_epoch_gu [{self.get_checkpoint_info(fcr_store.previous_epoch_greatest_unrealized_checkpoint)}]"
        )
        debug_print(
            f"justified_checkpoint [{self.get_checkpoint_info(store.justified_checkpoint)}]"
        )
        debug_print(
            f"finalized_checkpoint [{self.get_checkpoint_info(store.finalized_checkpoint)}]"
        )


@dataclass
class SystemRun:
    def execute(self, fcr: FCRTest) -> object:
        pass

    def __str__(self):
        output = []
        for f in fields(self):
            value = getattr(self, f.name)
            if value is not None:
                output.append(f"{f.name}={value}")
        return f"{self.__class__.__name__}({', '.join(output)})"

    def copy(self, **changes):
        return replace(self, **changes)


@dataclass
class PhaseRun(SystemRun):
    pass


@dataclass
class Proposal(PhaseRun):
    enabled: bool = True
    parent_id: object = None
    release_att_pool: bool = True
    atts_in_block: bool = True
    graffiti: str = None
    include_att_fn: Callable[[object, object], bool] = None

    def execute(self, fcr: FCRTest) -> object:
        if self.enabled:
            parent_root = fcr.get_block_root_or_head(self.parent_id)
            return fcr.add_and_apply_block(
                parent_root=parent_root,
                release_att_pool=self.release_att_pool,
                include_atts=self.atts_in_block,
                graffiti=self.graffiti,
                include_att_fn=self.include_att_fn,
            )
        else:
            return None


@dataclass
class Attesting(PhaseRun):
    block_id: object = None
    participation_rate: int = 100
    committee_slot_or_offset: object = 0

    def has_non_default_block(self) -> bool:
        return self.block_id is not None

    def all_committee_slot_or_offsets(self):
        if isinstance(self.committee_slot_or_offset, list):
            yield from self.committee_slot_or_offset
        else:
            yield self.committee_slot_or_offset

    def execute(self, fcr: FCRTest) -> object:
        if self.participation_rate == 0:
            return []

        block_root = fcr.get_block_root_or_head(self.block_id)
        attestations = []
        for committee_slot_or_offset in self.all_committee_slot_or_offsets():
            attestations.extend(
                fcr.attest(
                    block_root=block_root,
                    slot=fcr.resolve_slot_by_offset(committee_slot_or_offset),
                    participation_rate=self.participation_rate,
                    pool_and_disseminate=True,
                )
            )

        # Instantly apply past slot attestations
        past_slot_attestations = [att for att in attestations if att.data.slot < fcr.current_slot()]
        fcr.apply_attestations(past_slot_attestations)
        fcr.recent_attestations = [
            att for att in fcr.recent_attestations if att not in past_slot_attestations
        ]

        return attestations


@dataclass
class Slashing(PhaseRun):
    percentage: int = None
    committee_slot_or_offset: int = None
    supporters_of_block: object = None

    def execute(self, fcr: FCRTest) -> object:
        if self.percentage is None or self.percentage == 0:
            return None

        if self.committee_slot_or_offset is None and self.supporters_of_block is None:
            return fcr.apply_attester_slashing(slashing_percentage=self.percentage)

        if self.committee_slot_or_offset is not None:
            slot = fcr.resolve_slot_by_offset(self.committee_slot_or_offset)
            shuffling_source = fcr.store.block_states[fcr.head_root()]
            participants = fcr.sample_fraction_of_participants(
                shuffling_source, slot, self.percentage
            )
        else:
            supporters = fcr.get_supporters_of(self.supporters_of_block)
            count = len(supporters) * self.percentage // 100
            participants = supporters[:count]

        # Handle the case when there are no validators satisfying the above conditions
        if len(participants) > 0:
            return fcr.apply_attester_slashing(slashing_indices=participants)
        else:
            return None


@dataclass
class AdvanceSlot(PhaseRun):
    next_slot: bool = True
    with_fast_confirmation: bool = True

    def execute(self, fcr: FCRTest) -> object:
        # Next slot
        if self.next_slot:
            fcr.next_slot()

            # Run fast confirmation
            if self.with_fast_confirmation:
                fcr.run_fast_confirmation()

        return fcr.current_slot()


@dataclass
class MultiPhaseRun(SystemRun):
    proposal: Proposal = field(default_factory=Proposal)
    attesting: Attesting = field(default_factory=Attesting)
    slashing: Slashing = field(default_factory=Slashing)
    advance_slot: AdvanceSlot = field(default_factory=AdvanceSlot)


@dataclass
class SlotRun(MultiPhaseRun):
    def all_attestings(self) -> list[Attesting]:
        if isinstance(self.attesting, list):
            yield from self.attesting
        else:
            yield self.attesting

    def execute(self, fcr: FCRTest) -> object:
        # Propose
        tip_root = self.proposal.execute(fcr)

        # Attest
        for attesting in self.all_attestings():
            if attesting.has_non_default_block():
                attesting.execute(fcr)
            else:
                attesting.copy(block_id=tip_root).execute(fcr)

        # Slash
        self.slashing.execute(fcr)

        # Next slot
        self.advance_slot.execute(fcr)

        return tip_root


@dataclass
class EmptySlotRun(SlotRun):
    proposal: Proposal = field(default_factory=lambda: Proposal(enabled=False))


@dataclass
class SlotSequence(MultiPhaseRun):
    number_of_slots: int = None
    end_slot: int = None
    branch_root_id: object = None

    def get_number_of_slots(self, current_slot):
        assert self.number_of_slots is not None or self.end_slot is not None
        if self.number_of_slots is not None:
            return self.number_of_slots
        else:
            assert self.end_slot > current_slot
            return self.end_slot - current_slot

    def execute(self, fcr: FCRTest) -> object:
        tip_root = fcr.get_block_root_or_head(self.branch_root_id)
        built_chain = []
        for _ in range(self.get_number_of_slots(fcr.current_slot())):
            tip_root = SlotRun(
                proposal=self.proposal.copy(parent_id=tip_root),
                attesting=self.attesting,
                slashing=self.slashing,
                advance_slot=self.advance_slot,
            ).execute(fcr)
            built_chain.append(tip_root)

        return built_chain
