from random import Random

from eth_consensus_specs.test.context import (
    always_bls,
    GLOAS,
    HEZE,
    spec_state_test,
    spec_state_test_with_matching_config,
    with_all_phases_from_to,
    with_gloas_and_later,
    with_phases,
)
from eth_consensus_specs.test.gloas.block_processing.test_process_payload_attestation import (
    prepare_signed_payload_attestation,
)
from eth_consensus_specs.test.helpers.attestations import (
    get_max_attestations,
    get_valid_attestation,
    sign_attestation,
)
from eth_consensus_specs.test.helpers.attester_slashings import (
    get_max_attester_slashings,
    get_valid_attester_slashing_by_indices,
)
from eth_consensus_specs.test.helpers.block import (
    build_empty_block,
    build_empty_block_for_next_slot,
)
from eth_consensus_specs.test.helpers.bls_to_execution_changes import get_signed_address_change
from eth_consensus_specs.test.helpers.execution_requests import (
    get_non_empty_execution_requests,
)
from eth_consensus_specs.test.helpers.keys import builder_privkeys, privkeys
from eth_consensus_specs.test.helpers.multi_operations import (
    get_random_attestations,
)
from eth_consensus_specs.test.helpers.payload_attestation import get_random_payload_attestations
from eth_consensus_specs.test.helpers.proposer_slashings import (
    get_valid_proposer_slashings,
)
from eth_consensus_specs.test.helpers.state import (
    next_epoch,
    next_epoch_with_full_participation,
    next_slots,
    state_transition_and_sign_block,
    transition_to_slot_via_block,
)
from eth_consensus_specs.test.helpers.voluntary_exits import prepare_signed_exits
from eth_consensus_specs.test.helpers.withdrawals import (
    get_expected_withdrawals,
    prepare_withdrawal_request,
    set_parent_block_full,
    set_validator_fully_withdrawable,
)


def _setup_missed_payload_with_withdrawals(spec, state, num_withdrawal_validators=1):
    """
    Common setup: set validators as fully withdrawable, make parent block full,
    process Block 1 (which computes withdrawals), and skip payload delivery.

    When num_withdrawal_validators > MAX_WITHDRAWALS_PER_PAYLOAD, Block 1 processes
    exactly MAX_WITHDRAWALS_PER_PAYLOAD validators and the remainder stay withdrawable
    for Block 2's hypothetical sweep.

    After this:
    - Block 1's withdrawals (W_1) are stored in state.payload_expected_withdrawals
    - is_parent_block_full returns False (payload for Block 1 was not delivered)

    Returns:
        (pre_state, signed_block_1, block_1_withdrawals)
    """
    # Make parent block full so Block 1's process_withdrawals runs
    set_parent_block_full(spec, state)

    # Set up validators as fully withdrawable
    for i in range(num_withdrawal_validators):
        set_validator_fully_withdrawable(spec, state, i)

    # Verify there are expected withdrawals before processing Block 1
    assert len(get_expected_withdrawals(spec, state)) > 0

    # Save pre-state before any blocks
    pre_state = state.copy()

    # Process Block 1 — process_withdrawals runs (parent is full),
    # computes withdrawals W_1, applies balance changes, stores in payload_expected_withdrawals.
    # process_execution_payload_bid commits the bid.
    # Payload is NOT delivered.
    block_1 = build_empty_block_for_next_slot(spec, state)
    signed_block_1 = state_transition_and_sign_block(spec, state, block_1)

    # Block 1 should have computed non-empty withdrawals
    block_1_withdrawals = list(state.payload_expected_withdrawals)
    assert len(block_1_withdrawals) > 0

    # Payload for Block 1 was not delivered, so parent is empty for Block 2
    is_parent_block_full = state.latest_block_hash == state.latest_execution_payload_bid.block_hash
    assert not is_parent_block_full

    return pre_state, signed_block_1, block_1_withdrawals


def _attempt_payload_with_withdrawals(spec, state, withdrawals):
    """
    Attempt to verify a payload for the current slot with the given withdrawals.
    Operates on a copy to avoid mutating the test state.
    BLS is disabled in tests by default, so signature verification passes.

    Returns True if accepted, False if rejected.
    """
    test_state = state.copy()
    committed_bid = test_state.latest_execution_payload_bid

    # Build payload matching the committed bid in every field
    payload = spec.ExecutionPayload(
        parent_hash=test_state.latest_block_hash,
        prev_randao=committed_bid.prev_randao,
        gas_limit=committed_bid.gas_limit,
        block_hash=committed_bid.block_hash,
        timestamp=spec.compute_time_at_slot(test_state.genesis_time, test_state.slot),
        withdrawals=spec.Withdrawals(data=withdrawals),
        slot_number=test_state.slot,
    )

    # Cache state root for beacon_block_root computation
    header = test_state.latest_block_header.copy()
    header.state_root = test_state.hash_tree_root()

    envelope = spec.ExecutionPayloadEnvelope(
        payload=payload,
        execution_requests=spec.ExecutionRequests(),
        builder_index=committed_bid.builder_index,
        beacon_block_root=header.hash_tree_root(),
        parent_beacon_block_root=test_state.latest_block_header.parent_root,
    )

    if envelope.builder_index == spec.BUILDER_INDEX_SELF_BUILD:
        privkey = privkeys[test_state.latest_block_header.proposer_index]
    else:
        privkey = builder_privkeys[envelope.builder_index]
    signature = spec.get_execution_payload_envelope_signature(test_state, envelope, privkey)

    signed_envelope = spec.SignedExecutionPayloadEnvelope(
        message=envelope,
        signature=signature,
    )

    engine = spec.NoopExecutionEngine()

    try:
        spec.verify_execution_payload_envelope(test_state, signed_envelope, engine)
        return True
    except AssertionError:
        return False


@with_gloas_and_later
@spec_state_test
def test_missed_payload_next_block_with_withdrawals_satisfying_payload(spec, state):
    """
    Block 1: has withdrawal-eligible validators (more than MAX_WITHDRAWALS_PER_PAYLOAD).
    Payload for Block 1 does not arrive.
    Block 2: remaining validators are still withdrawal-eligible.
    Payload for Block 2: includes Block 1's stale withdrawals (W_1) → accepted.
    """
    # Set up MAX + 1 validators. Block 1 processes exactly MAX, leaving 1 remaining.
    pre_state, signed_block_1, block_1_withdrawals = _setup_missed_payload_with_withdrawals(
        spec, state, num_withdrawal_validators=spec.MAX_WITHDRAWALS_PER_PAYLOAD + 1
    )

    # Process Block 2 (parent empty → process_withdrawals returns early)
    block_2 = build_empty_block_for_next_slot(spec, state)
    signed_block_2 = state_transition_and_sign_block(spec, state, block_2)

    yield "pre", pre_state
    yield "blocks", [signed_block_1, signed_block_2]
    yield "post", state

    # Remaining validator is still withdrawable, but process_withdrawals skipped it
    current_expected = get_expected_withdrawals(spec, state)
    assert len(current_expected) > 0
    assert list(current_expected) != list(block_1_withdrawals)

    # A payload with Block 1's stale withdrawals (W_1) is accepted
    satisfying = spec.Withdrawals(data=block_1_withdrawals)
    assert _attempt_payload_with_withdrawals(spec, state, satisfying)


@with_gloas_and_later
@spec_state_test
def test_missed_payload_recovery_resumes_with_remaining_withdrawals(spec, state):
    """
    Block 1: has withdrawal-eligible validators (more than MAX_WITHDRAWALS_PER_PAYLOAD).
    Payload for Block 1 does not arrive.
    Block 2: remaining validators are still withdrawal-eligible and must still accept
    Block 1's stale withdrawals (W_1).
    Block 3: declares Block 2 as a FULL parent, causing Block 2's payload to be
    applied during normal block processing. Withdrawals then resume normally and
    compute a fresh set for the remaining validators.
    """
    # Set up MAX + 2 validators. Block 1 processes exactly MAX, leaving 2 remaining.
    pre_state, signed_block_1, block_1_withdrawals = _setup_missed_payload_with_withdrawals(
        spec, state, num_withdrawal_validators=spec.MAX_WITHDRAWALS_PER_PAYLOAD + 2
    )

    # Process Block 2 (parent empty -> process_withdrawals returns early)
    block_2 = build_empty_block_for_next_slot(spec, state)
    signed_block_2 = state_transition_and_sign_block(spec, state, block_2)

    # Block 2 must still accept Block 1's stale withdrawals.
    satisfying = spec.Withdrawals(data=block_1_withdrawals)
    assert _attempt_payload_with_withdrawals(spec, state, satisfying)

    # Build Block 3 so block processing treats Block 2 as a FULL parent.
    # This triggers process_parent_execution_payload for Block 2 before
    # process_withdrawals computes Block 3's fresh expected withdrawals.
    block_3 = build_empty_block_for_next_slot(spec, state)
    block_3.body.signed_execution_payload_bid.message.parent_block_hash = (
        state.latest_execution_payload_bid.block_hash
    )
    block_3.body.signed_execution_payload_bid.message.block_hash = spec.Hash32(b"\x42" * 32)
    signed_block_3 = state_transition_and_sign_block(spec, state, block_3)

    yield "pre", pre_state
    yield "blocks", [signed_block_1, signed_block_2, signed_block_3]
    yield "post", state

    # Block 3 applied Block 2's payload, so the parent is now marked FULL.
    block_2_hash = signed_block_2.message.body.signed_execution_payload_bid.message.block_hash
    assert state.latest_block_hash == block_2_hash

    resumed_withdrawals = list(state.payload_expected_withdrawals)
    assert len(resumed_withdrawals) > 0
    assert resumed_withdrawals != block_1_withdrawals

    # Exactly two validators remained after Block 1's full payload-sized sweep.
    assert len(resumed_withdrawals) == 2

    resumed = spec.Withdrawals(data=resumed_withdrawals)
    assert _attempt_payload_with_withdrawals(spec, state, resumed)

    # Once recovery resumes, Block 1's stale withdrawals must be rejected.
    assert not _attempt_payload_with_withdrawals(spec, state, satisfying)


@with_gloas_and_later
@spec_state_test
def test_missed_payload_recovery_resumes_without_remaining_withdrawals(spec, state):
    """
    Block 1: has withdrawal-eligible validators.
    Payload for Block 1 does not arrive.
    Block 2: no new withdrawal-eligible validators and must still accept
    Block 1's stale withdrawals (W_1).
    Block 3: declares Block 2 as a FULL parent, causing Block 2's payload to be
    applied during normal block processing. Withdrawals then resume normally and
    compute an empty set.
    """
    # Set up MAX validators. Block 1 processes exactly MAX, leaving 0 remaining.
    pre_state, signed_block_1, block_1_withdrawals = _setup_missed_payload_with_withdrawals(
        spec, state, num_withdrawal_validators=spec.MAX_WITHDRAWALS_PER_PAYLOAD
    )

    # Process Block 2 (parent empty -> process_withdrawals returns early)
    block_2 = build_empty_block_for_next_slot(spec, state)
    signed_block_2 = state_transition_and_sign_block(spec, state, block_2)

    # Block 2 must still accept Block 1's stale withdrawals.
    satisfying = spec.Withdrawals(data=block_1_withdrawals)
    assert _attempt_payload_with_withdrawals(spec, state, satisfying)

    # Build Block 3 so block processing treats Block 2 as a FULL parent.
    # This triggers process_parent_execution_payload for Block 2 before
    # process_withdrawals computes Block 3's fresh expected withdrawals.
    block_3 = build_empty_block_for_next_slot(spec, state)
    block_3.body.signed_execution_payload_bid.message.parent_block_hash = (
        state.latest_execution_payload_bid.block_hash
    )
    block_3.body.signed_execution_payload_bid.message.block_hash = spec.Hash32(b"\x42" * 32)
    signed_block_3 = state_transition_and_sign_block(spec, state, block_3)

    yield "pre", pre_state
    yield "blocks", [signed_block_1, signed_block_2, signed_block_3]
    yield "post", state

    # Block 3 applied Block 2's payload, so the parent is now marked FULL.
    block_2_hash = signed_block_2.message.body.signed_execution_payload_bid.message.block_hash
    assert state.latest_block_hash == block_2_hash

    resumed_withdrawals = list(state.payload_expected_withdrawals)
    assert resumed_withdrawals == []

    empty_withdrawals = spec.Withdrawals()
    assert _attempt_payload_with_withdrawals(spec, state, empty_withdrawals)

    # Once recovery is complete, the stale Block 1 withdrawals must no longer be accepted.
    assert not _attempt_payload_with_withdrawals(spec, state, satisfying)


@with_gloas_and_later
@spec_state_test
def test_missed_payload_next_block_with_withdrawals_unsatisfying_payload(spec, state):
    """
    Block 1: has withdrawal-eligible validators (more than MAX_WITHDRAWALS_PER_PAYLOAD).
    Payload for Block 1 does not arrive.
    Block 2: remaining validators are still withdrawal-eligible.
    Payload for Block 2: includes fresh expected withdrawals instead of W_1 → rejected.
    """
    # Set up MAX + 1 validators. Block 1 processes exactly MAX, leaving 1 remaining.
    pre_state, signed_block_1, block_1_withdrawals = _setup_missed_payload_with_withdrawals(
        spec, state, num_withdrawal_validators=spec.MAX_WITHDRAWALS_PER_PAYLOAD + 1
    )

    # Process Block 2 (parent empty → process_withdrawals returns early)
    block_2 = build_empty_block_for_next_slot(spec, state)
    signed_block_2 = state_transition_and_sign_block(spec, state, block_2)

    yield "pre", pre_state
    yield "blocks", [signed_block_1, signed_block_2]
    yield "post", state

    # Fresh expected withdrawals differ from W_1
    current_expected = get_expected_withdrawals(spec, state)
    assert len(current_expected) > 0
    assert list(current_expected) != list(block_1_withdrawals)

    # A payload with fresh withdrawals (not W_1) is rejected
    unsatisfying = spec.Withdrawals(data=current_expected)
    assert not _attempt_payload_with_withdrawals(spec, state, unsatisfying)


@with_gloas_and_later
@spec_state_test
def test_missed_payload_next_block_without_withdrawals_satisfying_payload(spec, state):
    """
    Block 1: has withdrawal-eligible validators. Payload does not arrive.
    Block 2: no new withdrawal-eligible validators.
    Payload for Block 2: includes Block 1's stale withdrawals (W_1) → accepted.
    """
    pre_state, signed_block_1, block_1_withdrawals = _setup_missed_payload_with_withdrawals(
        spec, state
    )

    # Process Block 2 (parent empty → process_withdrawals returns early)
    block_2 = build_empty_block_for_next_slot(spec, state)
    signed_block_2 = state_transition_and_sign_block(spec, state, block_2)

    yield "pre", pre_state
    yield "blocks", [signed_block_1, signed_block_2]
    yield "post", state

    # No withdrawable validators remain
    current_expected = get_expected_withdrawals(spec, state)
    assert len(current_expected) == 0

    # Despite no current withdrawals, payload must include W_1 — and it's accepted
    satisfying = spec.Withdrawals(data=block_1_withdrawals)
    assert _attempt_payload_with_withdrawals(spec, state, satisfying)


@with_gloas_and_later
@spec_state_test
def test_missed_payload_next_block_without_withdrawals_unsatisfying_payload(spec, state):
    """
    Block 1: has withdrawal-eligible validators. Payload does not arrive.
    Block 2: no new withdrawal-eligible validators.
    Payload for Block 2: includes empty withdrawals (not W_1) → rejected.
    """
    pre_state, signed_block_1, _ = _setup_missed_payload_with_withdrawals(spec, state)

    # Process Block 2 (parent empty → process_withdrawals returns early)
    block_2 = build_empty_block_for_next_slot(spec, state)
    signed_block_2 = state_transition_and_sign_block(spec, state, block_2)

    yield "pre", pre_state
    yield "blocks", [signed_block_1, signed_block_2]
    yield "post", state

    # No withdrawable validators remain
    current_expected = get_expected_withdrawals(spec, state)
    assert len(current_expected) == 0

    # An empty payload is rejected — it must include W_1
    empty_withdrawals = spec.Withdrawals()
    assert not _attempt_payload_with_withdrawals(spec, state, empty_withdrawals)


@with_gloas_and_later
@spec_state_test_with_matching_config
def test_invalid_payload_attestation_wrong_beacon_block_root(spec, state):
    """
    Test that payload attestation with wrong beacon_block_root fails.
    """
    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)

    parent_slot = state.latest_block_header.slot
    ptc = spec.get_ptc(state, parent_slot)

    wrong_root = spec.Root(b"\x42" * 32)
    payload_attestation = prepare_signed_payload_attestation(
        spec,
        state,
        slot=parent_slot,
        beacon_block_root=wrong_root,
        payload_present=True,
        attesting_indices=spec.PayloadTimelinessCommitteeIndices(data=ptc),
    )
    block.body.payload_attestations = spec.PayloadAttestations.of(payload_attestation)

    signed_block = state_transition_and_sign_block(spec, state, block, expect_fail=True)

    yield "blocks", [signed_block]
    yield "post", None


@with_gloas_and_later
@spec_state_test
def test_process_parent_execution_payload__wrong_execution_requests_root(spec, state):
    """
    Test that process_parent_execution_payload rejects a block whose
    parent_execution_requests do not match parent_bid.execution_requests_root
    when the parent block was full.
    """
    set_parent_block_full(spec, state)

    # Build a valid block, then tamper with parent_execution_requests
    block = build_empty_block_for_next_slot(spec, state)

    # Inject a non-empty deposit so the hash diverges from the committed root
    block.body.parent_execution_requests = get_non_empty_execution_requests(spec)

    yield "pre", state
    signed_block = state_transition_and_sign_block(spec, state, block, expect_fail=True)

    yield "blocks", [signed_block]
    yield "post", None


@with_gloas_and_later
@spec_state_test
def test_max_proposer_slashings(spec, state):
    num_slashings = spec.MAX_PROPOSER_SLASHINGS
    proposer_slashings = get_valid_proposer_slashings(spec, state, num_slashings)

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.proposer_slashings = spec.ProposerSlashings(data=proposer_slashings)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield "blocks", [signed_block]
    yield "post", state


@with_gloas_and_later
@spec_state_test
def test_invalid_too_many_proposer_slashings(spec, state):
    num_slashings = spec.MAX_PROPOSER_SLASHINGS + 1
    proposer_slashings = get_valid_proposer_slashings(spec, state, num_slashings)

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.proposer_slashings = spec.ProposerSlashings(data=proposer_slashings)
    signed_block = state_transition_and_sign_block(spec, state, block, expect_fail=True)

    yield "blocks", [signed_block]
    yield "post", None


@with_gloas_and_later
@spec_state_test_with_matching_config
def test_invalid_payload_attestation_too_old_slot(spec, state):
    """
    Test that payload attestation for slot too far in past fails.
    """
    yield "pre", state

    # Advance state to slot 3
    spec.process_slots(state, state.slot + 3)

    block = build_empty_block_for_next_slot(spec, state)

    ptc = spec.get_ptc(state, state.slot - 2)

    parent_header = state.latest_block_header.copy()
    if parent_header.state_root == spec.Root():
        parent_header.state_root = spec.hash_tree_root(state)
    beacon_block_root = spec.hash_tree_root(parent_header)

    payload_attestation = prepare_signed_payload_attestation(
        spec,
        state,
        slot=state.slot - 2,  # Too old - should fail
        beacon_block_root=beacon_block_root,
        payload_present=True,
        attesting_indices=spec.PayloadTimelinessCommitteeIndices(data=ptc),
    )
    block.body.payload_attestations = spec.PayloadAttestations.of(payload_attestation)

    signed_block = state_transition_and_sign_block(spec, state, block, expect_fail=True)

    yield "blocks", [signed_block]
    yield "post", None


@with_gloas_and_later
@spec_state_test
def test_max_attester_slashings(spec, state):
    num_slashings = get_max_attester_slashings(spec)
    full_indices = spec.get_active_validator_indices(state, spec.get_current_epoch(state))[:8]
    per_slashing_length = len(full_indices) // num_slashings
    attester_slashings = [
        get_valid_attester_slashing_by_indices(
            spec,
            state,
            full_indices[i * per_slashing_length : (i + 1) * per_slashing_length],
            signed_1=True,
            signed_2=True,
        )
        for i in range(num_slashings)
    ]

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.attester_slashings = spec.AttesterSlashings(data=attester_slashings)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield "blocks", [signed_block]
    yield "post", state


@with_gloas_and_later
@spec_state_test
def test_invalid_too_many_attester_slashings(spec, state):
    num_slashings = get_max_attester_slashings(spec) + 1
    full_indices = spec.get_active_validator_indices(state, spec.get_current_epoch(state))[:8]
    per_slashing_length = len(full_indices) // num_slashings
    attester_slashings = [
        get_valid_attester_slashing_by_indices(
            spec,
            state,
            full_indices[i * per_slashing_length : (i + 1) * per_slashing_length],
            signed_1=True,
            signed_2=True,
        )
        for i in range(num_slashings)
    ]

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.attester_slashings = spec.AttesterSlashings(data=attester_slashings)
    signed_block = state_transition_and_sign_block(spec, state, block, expect_fail=True)

    yield "blocks", [signed_block]
    yield "post", None


@with_gloas_and_later
@spec_state_test
def test_builder_payment_removed_when_proposer_slashes_itself(spec, state):
    """
    Test that a proposer cannot keep its builder payment by slashing itself in
    the block that carries the bid.
    """
    # Advance to get finalization
    for _ in range(4):
        next_epoch_with_full_participation(spec, state)
    assert state.finalized_checkpoint.epoch == 2

    block = build_empty_block_for_next_slot(spec, state)
    builder_index = 0
    value = spec.Gwei(1000000)  # 0.001 ETH

    bid = block.body.signed_execution_payload_bid.message
    bid.builder_index = builder_index
    bid.value = value
    signature = spec.get_execution_payload_bid_signature(
        state, bid, builder_privkeys[builder_index]
    )
    block.body.signed_execution_payload_bid = spec.SignedExecutionPayloadBid(
        message=bid,
        signature=signature,
    )
    state.builders[builder_index].balance = spec.MIN_DEPOSIT_AMOUNT + value

    attester_slashing = get_valid_attester_slashing_by_indices(
        spec, state, [block.proposer_index], signed_1=True, signed_2=True
    )
    block.body.attester_slashings = spec.AttesterSlashings(data=[attester_slashing])

    yield "pre", state

    signed_block = state_transition_and_sign_block(spec, state, block)

    yield "blocks", [signed_block]
    yield "post", state

    assert state.validators[block.proposer_index].slashed
    payment_index = spec.SLOTS_PER_EPOCH + block.slot % spec.SLOTS_PER_EPOCH
    assert state.builder_pending_payments[payment_index] == spec.BuilderPendingPayment()


@with_gloas_and_later
@spec_state_test
def test_max_attestations(spec, state):
    rng = Random(2000)

    next_epoch(spec, state)
    num_attestations = get_max_attestations(spec)
    attestations = get_random_attestations(spec, state, rng, num_attestations)

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.attestations = spec.Attestations(data=attestations)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield "blocks", [signed_block]
    yield "post", state


@with_gloas_and_later
@spec_state_test
def test_invalid_too_many_attestations(spec, state):
    rng = Random(2000)

    next_epoch(spec, state)
    num_attestations = get_max_attestations(spec) + 1
    attestations = get_random_attestations(spec, state, rng, num_attestations)

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.attestations = spec.Attestations(data=attestations)
    signed_block = state_transition_and_sign_block(spec, state, block, expect_fail=True)

    yield "blocks", [signed_block]
    yield "post", None


@with_all_phases_from_to(GLOAS, HEZE)
@spec_state_test
def test_max_deposits(spec, state):
    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.deposits = spec.Deposits(data=[])
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield "blocks", [signed_block]
    yield "post", state


@with_all_phases_from_to(GLOAS, HEZE)
@spec_state_test
def test_invalid_too_many_deposits(spec, state):
    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.deposits = spec.Deposits(data=[spec.Deposit()])
    signed_block = state_transition_and_sign_block(spec, state, block, expect_fail=True)

    yield "blocks", [signed_block]
    yield "post", None


@with_gloas_and_later
@spec_state_test
def test_max_voluntary_exits(spec, state):
    next_slots(spec, state, spec.Uint64(spec.config.SHARD_COMMITTEE_PERIOD) * spec.SLOTS_PER_EPOCH)
    num_exits = spec.MAX_VOLUNTARY_EXITS
    full_indices = spec.get_active_validator_indices(state, spec.get_current_epoch(state))[
        :num_exits
    ]
    signed_exits = prepare_signed_exits(spec, state, full_indices)

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.voluntary_exits = spec.VoluntaryExits(data=signed_exits)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield "blocks", [signed_block]
    yield "post", state


@with_gloas_and_later
@spec_state_test
def test_invalid_too_many_voluntary_exits(spec, state):
    next_slots(spec, state, spec.Uint64(spec.config.SHARD_COMMITTEE_PERIOD) * spec.SLOTS_PER_EPOCH)
    num_exits = spec.MAX_VOLUNTARY_EXITS + 1
    full_indices = spec.get_active_validator_indices(state, spec.get_current_epoch(state))[
        :num_exits
    ]
    signed_exits = prepare_signed_exits(spec, state, full_indices)

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.voluntary_exits = spec.VoluntaryExits(data=signed_exits)
    signed_block = state_transition_and_sign_block(spec, state, block, expect_fail=True)

    yield "blocks", [signed_block]
    yield "post", None


@with_gloas_and_later
@spec_state_test
def test_max_bls_to_execution_changes(spec, state):
    num_address_changes = spec.MAX_BLS_TO_EXECUTION_CHANGES
    signed_address_changes = [
        get_signed_address_change(spec, state, validator_index=i)
        for i in range(num_address_changes)
    ]

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.bls_to_execution_changes = spec.BLSToExecutionChanges(data=signed_address_changes)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield "blocks", [signed_block]
    yield "post", state


@with_gloas_and_later
@spec_state_test
def test_invalid_too_many_bls_to_execution_changes(spec, state):
    num_address_changes = spec.MAX_BLS_TO_EXECUTION_CHANGES + 1
    signed_address_changes = [
        get_signed_address_change(spec, state, validator_index=i)
        for i in range(num_address_changes)
    ]

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.bls_to_execution_changes = spec.BLSToExecutionChanges(data=signed_address_changes)
    signed_block = state_transition_and_sign_block(spec, state, block, expect_fail=True)

    yield "blocks", [signed_block]
    yield "post", None


@with_gloas_and_later
@spec_state_test_with_matching_config
def test_max_payload_attestations(spec, state):
    rng = Random(3000)

    state_transition_and_sign_block(spec, state, build_empty_block_for_next_slot(spec, state))

    payload_attestations = []
    for _ in range(spec.MAX_PAYLOAD_ATTESTATIONS):
        payload_attestations.extend(get_random_payload_attestations(spec, state, rng))
    assert len(payload_attestations) == spec.MAX_PAYLOAD_ATTESTATIONS

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.payload_attestations = spec.PayloadAttestations(data=payload_attestations)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield "blocks", [signed_block]
    yield "post", state


@with_gloas_and_later
@spec_state_test_with_matching_config
def test_invalid_too_many_payload_attestations(spec, state):
    rng = Random(3000)

    state_transition_and_sign_block(spec, state, build_empty_block_for_next_slot(spec, state))

    payload_attestations = []
    for _ in range(spec.MAX_PAYLOAD_ATTESTATIONS + 1):
        payload_attestations.extend(get_random_payload_attestations(spec, state, rng))
    assert len(payload_attestations) > spec.MAX_PAYLOAD_ATTESTATIONS

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.payload_attestations = spec.PayloadAttestations(data=payload_attestations)
    signed_block = state_transition_and_sign_block(spec, state, block, expect_fail=True)

    yield "blocks", [signed_block]
    yield "post", None


@with_gloas_and_later
@spec_state_test_with_matching_config
@always_bls
def test_invalid_payload_attestation_invalid_signature(spec, state):
    """
    Test that payload attestation with invalid signature fails.
    """
    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)

    parent_slot = state.latest_block_header.slot
    ptc = spec.get_ptc(state, parent_slot)

    parent_header = state.latest_block_header.copy()
    if parent_header.state_root == spec.Root():
        parent_header.state_root = spec.hash_tree_root(state)
    beacon_block_root = spec.hash_tree_root(parent_header)

    payload_attestation = prepare_signed_payload_attestation(
        spec,
        state,
        slot=parent_slot,
        beacon_block_root=beacon_block_root,
        payload_present=True,
        attesting_indices=spec.PayloadTimelinessCommitteeIndices(data=ptc),
        valid_signature=False,
    )
    block.body.payload_attestations = spec.PayloadAttestations.of(payload_attestation)

    signed_block = state_transition_and_sign_block(spec, state, block, expect_fail=True)

    yield "blocks", [signed_block]
    yield "post", None


@with_gloas_and_later
@spec_state_test
def test_builder_payment_after_missed_epochs(spec, state):
    """
    Test that a builder is correctly charged when their canonical payload
    is processed after 2+ epochs of missed blocks.
    """
    # Advance to get finalization
    for _ in range(4):
        next_epoch_with_full_participation(spec, state)
    assert state.finalized_checkpoint.epoch == 2

    # Build Block 1 with a non-zero value bid from a builder
    block_1 = build_empty_block_for_next_slot(spec, state)
    builder_index = 0
    value = spec.Gwei(1000000)  # 0.001 ETH
    fee_recipient = b"\xab" * 20
    block_hash = spec.Hash32(b"\x42" * 32)

    bid = block_1.body.signed_execution_payload_bid.message
    bid.block_hash = block_hash
    bid.builder_index = builder_index
    bid.value = value
    bid.fee_recipient = fee_recipient
    bid.execution_requests_root = spec.hash_tree_root(spec.ExecutionRequests())

    # Sign the bid with the builder's private key
    signature = spec.get_execution_payload_bid_signature(
        state, bid, builder_privkeys[builder_index]
    )
    block_1.body.signed_execution_payload_bid = spec.SignedExecutionPayloadBid(
        message=bid,
        signature=signature,
    )

    # Ensure builder can cover the bid
    state.builders[builder_index].balance = spec.MIN_DEPOSIT_AMOUNT + value

    yield "pre", state

    # Process Block 1 — creates a pending payment for the builder
    signed_block_1 = state_transition_and_sign_block(spec, state, block_1)

    # Verify pending payment was created
    payment_idx = spec.SLOTS_PER_EPOCH + block_1.slot % spec.SLOTS_PER_EPOCH
    payment = state.builder_pending_payments[payment_idx]
    assert payment.withdrawal.amount == value
    assert payment.withdrawal.builder_index == builder_index
    assert payment.weight == 0

    pre_builder_balance = state.builders[builder_index].balance

    # Build Block 2 with 2+ epochs of missed slots. During the slot advancement,
    # process_builder_pending_payments runs at each epoch boundary:
    #   1st boundary: shifts payment from second half to first half
    #   2nd boundary: checks quorum on first half — weight 0 < quorum → evicted
    # When Block 2 is processed, parent is FULL so apply_parent_execution_payload
    # runs. Since parent_epoch is older than previous_epoch, payment_index is None.
    # The fix creates the withdrawal directly from the bid in this case.
    block_1_epoch = spec.compute_epoch_at_slot(block_1.slot)
    block_2_slot = spec.compute_start_slot_at_epoch(block_1_epoch + 2) + 1
    block_2 = build_empty_block(spec, state, slot=block_2_slot)
    block_2.body.signed_execution_payload_bid.message.parent_block_hash = block_hash
    signed_block_2 = state_transition_and_sign_block(spec, state, block_2)

    yield "blocks", [signed_block_1, signed_block_2]
    yield "post", state

    # Verify apply_parent_execution_payload actually ran (parent was FULL)
    parent_slot_index = bid.slot % spec.SLOTS_PER_HISTORICAL_ROOT
    assert state.execution_payload_availability[parent_slot_index]

    # Verify the builder was charged — balance decreased by the bid value
    assert state.builders[builder_index].balance == pre_builder_balance - value


@with_gloas_and_later
@spec_state_test
def test_attestations_after_missed_slot_use_applied_parent_payload_availability(spec, state):
    """
    Test that attestations from a missed slot use the availability of their
    parent block's payload after that payload is applied by the including block.
    """
    set_parent_block_full(spec, state)

    block_1 = build_empty_block_for_next_slot(spec, state)
    parent_slot = block_1.slot
    parent_block_hash = spec.Hash32(b"\x42" * 32)
    block_1.body.signed_execution_payload_bid.message.block_hash = parent_block_hash

    yield "pre", state

    signed_block_1 = state_transition_and_sign_block(spec, state, block_1)

    parent_slot_index = parent_slot % spec.SLOTS_PER_HISTORICAL_ROOT
    assert not state.execution_payload_availability[parent_slot_index]

    # Slot after Block 1 is missed. Build an attestation at that slot for the
    # inherited Block 1 root and for the available payload.
    attestation_slot = parent_slot + 1
    attestation_state = state.copy()
    next_slots(spec, attestation_state, 1)
    assert attestation_state.slot == attestation_slot

    committee = spec.get_beacon_committee(attestation_state, attestation_slot, 0)
    matching_attesters = set(committee[::2])
    mismatching_attesters = set(committee[1::2])
    assert matching_attesters
    assert mismatching_attesters

    matching_attestation = get_valid_attestation(
        spec,
        attestation_state,
        slot=attestation_slot,
        payload_index=1,
        filter_participant_set=lambda participants: participants & matching_attesters,
        signed=True,
    )
    mismatching_attestation = get_valid_attestation(
        spec,
        attestation_state,
        slot=attestation_slot,
        payload_index=0,
        filter_participant_set=lambda participants: participants & mismatching_attesters,
        signed=True,
    )

    matching_indices = spec.get_attesting_indices(attestation_state, matching_attestation)
    mismatching_indices = spec.get_attesting_indices(attestation_state, mismatching_attestation)
    assert matching_indices.isdisjoint(mismatching_indices)
    for validator_index in matching_indices | mismatching_indices:
        assert not spec.has_flag(
            state.current_epoch_participation[validator_index],
            spec.TIMELY_HEAD_FLAG_INDEX,
        )

    # Block 2 confirms Block 1's payload before processing the attestation.
    child_slot = attestation_slot + spec.MIN_ATTESTATION_INCLUSION_DELAY
    block_2 = build_empty_block(spec, state, slot=child_slot)
    block_2.body.signed_execution_payload_bid.message.parent_block_hash = parent_block_hash
    block_2.body.attestations = spec.Attestations.of(matching_attestation, mismatching_attestation)
    signed_block_2 = state_transition_and_sign_block(spec, state, block_2)

    yield "blocks", [signed_block_1, signed_block_2]
    yield "post", state

    attestation_slot_index = attestation_slot % spec.SLOTS_PER_HISTORICAL_ROOT
    assert not spec.is_attestation_same_slot(state, matching_attestation.data)
    assert not spec.is_attestation_same_slot(state, mismatching_attestation.data)
    assert state.execution_payload_availability[parent_slot_index]
    assert not state.execution_payload_availability[attestation_slot_index]

    for validator_index in matching_indices:
        assert spec.has_flag(
            state.current_epoch_participation[validator_index],
            spec.TIMELY_HEAD_FLAG_INDEX,
        )
    for validator_index in mismatching_indices:
        assert not spec.has_flag(
            state.current_epoch_participation[validator_index],
            spec.TIMELY_HEAD_FLAG_INDEX,
        )


@with_gloas_and_later
@spec_state_test
def test_voluntary_exit_fails_after_parent_payload_withdrawal_request(spec, state):
    """
    Test that a voluntary exit is rejected when the parent payload's deferred
    execution requests have already initiated the validator's exit.
    """
    validator_index = spec.get_active_validator_indices(state, spec.get_current_epoch(state))[-1]

    # Move state forward SHARD_COMMITTEE_PERIOD epochs so the validator can exit
    state.slot += spec.Uint64(spec.config.SHARD_COMMITTEE_PERIOD) * spec.SLOTS_PER_EPOCH

    # Set up the parent block as FULL with a bid that commits to a full-exit
    # withdrawal request for the validator.
    set_parent_block_full(spec, state)
    withdrawal_request = prepare_withdrawal_request(spec, state, validator_index)
    requests = spec.ExecutionRequests(
        withdrawals=spec.WithdrawalRequests.of(withdrawal_request),
    )
    state.latest_execution_payload_bid.execution_requests_root = spec.hash_tree_root(requests)

    # Build a block that delivers the parent's deferred execution requests
    # (initiating the validator's exit) and also tries to voluntarily exit the
    # same validator. The voluntary exit fails the FAR_FUTURE_EPOCH check.
    signed_exits = prepare_signed_exits(spec, state, [validator_index])
    block = build_empty_block_for_next_slot(spec, state)
    block.body.parent_execution_requests = requests
    block.body.voluntary_exits = spec.VoluntaryExits(data=signed_exits)

    yield "pre", state
    signed_block = state_transition_and_sign_block(spec, state, block, expect_fail=True)
    yield "blocks", [signed_block]
    yield "post", None


@with_phases([GLOAS])
@spec_state_test
def test_proposer_lookahead_excludes_slashed_validators(spec, state):
    """
    Test that slashed validators are excluded from the proposer lookahead.
    """
    for _ in range(2):
        next_epoch(spec, state)

    current_epoch = spec.get_current_epoch(state)
    new_half_epoch = current_epoch + spec.MIN_SEED_LOOKAHEAD + 1

    # Slash some validators
    for validator_index in range(len(state.validators) // 2):
        state.validators[validator_index].slashed = True

    # Fulu includes slashed validators
    proposers_in_fulu = spec.fulu.get_beacon_proposer_indices(state, new_half_epoch)
    assert any(state.validators[v].slashed for v in proposers_in_fulu)

    # Gloas excludes slashed validators
    proposers_in_gloas = spec.get_beacon_proposer_indices(state, new_half_epoch)
    assert not any(state.validators[v].slashed for v in proposers_in_gloas)

    # Cross into the next epoch with a block, picking a slot whose proposer is
    # not one of the validators we slashed so the block is valid
    epoch_n1_proposers = list(state.proposer_lookahead[spec.SLOTS_PER_EPOCH :])
    offset = next(i for i, p in enumerate(epoch_n1_proposers) if not state.validators[p].slashed)
    block_slot = spec.compute_start_slot_at_epoch(current_epoch + 1) + offset

    yield "pre", state

    block = build_empty_block(spec, state, slot=block_slot)
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield "blocks", [signed_block]
    yield "post", state

    # The newly appended lookahead epoch matches the Gloas selection
    last_epoch_start = len(state.proposer_lookahead) - spec.SLOTS_PER_EPOCH
    assert list(state.proposer_lookahead[last_epoch_start:]) == list(proposers_in_gloas)


@with_gloas_and_later
@spec_state_test
def test_builder_payment_weight_no_double_counting_target_equivocation(spec, state):
    """
    A validator that equivocates on the attestation target (same source, different
    target roots) is credited to the builder payment weight at most once, even when
    both attestations land in the same block.
    """
    # Block at slot 1, then advance so slot 1's block root is retrievable from state.
    transition_to_slot_via_block(spec, state, 1)
    next_slots(spec, state, 1)

    attestation_slot = spec.Slot(1)
    committee = spec.get_beacon_committee(state, attestation_slot, 0)
    attester = committee[0]
    # A block was proposed at the attestation slot, so these are same-slot attestations.
    head_root = spec.get_block_root_at_slot(state, attestation_slot)

    def build(wrong_target):
        attestation = get_valid_attestation(
            spec,
            state,
            slot=attestation_slot,
            index=0,
            payload_index=0,
            beacon_block_root=head_root,
            filter_participant_set=lambda _: {attester},
        )
        if wrong_target:
            attestation.data.target.root = spec.Root(b"\x11" * 32)
        sign_attestation(spec, state, attestation)
        assert spec.is_attestation_same_slot(state, attestation.data)
        return attestation

    attestation_wrong_target = build(wrong_target=True)
    attestation_right_target = build(wrong_target=False)
    assert attestation_wrong_target.data.target.root != attestation_right_target.data.target.root

    # Give slot 1 a builder payment to accrue weight against.
    payment_index = spec.SLOTS_PER_EPOCH + attestation_slot % spec.SLOTS_PER_EPOCH
    state.builder_pending_payments[payment_index] = spec.BuilderPendingPayment(
        weight=spec.Gwei(0),
        withdrawal=spec.BuilderPendingWithdrawal(
            fee_recipient=spec.ExecutionAddress(),
            amount=spec.Gwei(1000000000),
            builder_index=0,
        ),
    )

    yield "pre", state

    block = build_empty_block_for_next_slot(spec, state)
    block.body.attestations = spec.Attestations(
        data=[attestation_wrong_target, attestation_right_target]
    )
    signed_block = state_transition_and_sign_block(spec, state, block)

    yield "blocks", [signed_block]
    yield "post", state

    # Credited once, not once per flag set.
    assert (
        state.builder_pending_payments[payment_index].weight
        == state.validators[attester].effective_balance
    )
