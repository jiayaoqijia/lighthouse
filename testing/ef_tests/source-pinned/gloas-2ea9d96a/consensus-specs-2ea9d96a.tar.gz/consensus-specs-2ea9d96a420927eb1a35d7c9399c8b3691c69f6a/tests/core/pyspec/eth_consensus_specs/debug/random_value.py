from enum import Enum
from random import Random

from ssz.bitfields import BitList, BitVector, ProgressiveBitList
from ssz.boolean import Boolean
from ssz.byte_arrays import ByteList, ByteVector
from ssz.collections import List, ProgressiveList, Vector
from ssz.container import Container, ProgressiveContainer
from ssz.ssz_base import SSZType
from ssz.uint import BaseUint as Uint, Uint8
from ssz.union import CompatibleUnion

# in bytes
UINT_BYTE_SIZES = (1, 2, 4, 8, 16, 32)

random_mode_names = ("random", "zero", "max", "nil", "one", "lengthy")


class RandomizationMode(Enum):
    # random content / length
    mode_random = 0
    # Zero-value
    mode_zero = 1
    # Maximum value, limited to count 1 however
    mode_max = 2
    # Return 0 values, i.e. empty
    mode_nil_count = 3
    # Return 1 value, random content
    mode_one_count = 4
    # Return max amount of values, random content
    mode_max_count = 5

    def to_name(self):
        return random_mode_names[self.value]

    def is_changing(self):
        return self.value in [0, 4, 5]


def get_random_ssz_object(
    rng: Random,
    typ: type[SSZType],
    max_bytes_length: int,
    max_list_length: int,
    mode: RandomizationMode,
    chaos: bool,
    list_length_limits: dict[type[SSZType], int] | None = None,
) -> SSZType:
    """
    Create an object for a given type, filled with random data.
    :param rng: The random number generator to use.
    :param typ: The type to instantiate
    :param max_bytes_length: the max. length for a random bytes array
    :param max_list_length: the max. length for a random list
    :param mode: how to randomize
    :param chaos: if true, the randomization-mode will be randomly changed
    :param list_length_limits: optional map of ProgressiveList type to max
        length. Used to keep generated objects within consensus/gossip count
        limits that SSZ no longer enforces.
    :return: the random object instance, of the given type.
    """
    if chaos:
        mode = rng.choice(list(RandomizationMode))
    if issubclass(typ, ByteList):
        # ByteList array
        if mode == RandomizationMode.mode_nil_count:
            return typ()
        elif mode == RandomizationMode.mode_max_count:
            return typ(data=list(get_random_bytes_list(rng, min(max_bytes_length, typ.LIMIT))))
        elif mode == RandomizationMode.mode_one_count:
            return typ(data=list(get_random_bytes_list(rng, min(1, typ.LIMIT))))
        elif mode == RandomizationMode.mode_zero:
            return typ(data=[0] * min(1, typ.LIMIT))
        elif mode == RandomizationMode.mode_max:
            return typ(data=[0xFF] * min(1, typ.LIMIT))
        else:
            return typ(
                data=list(
                    get_random_bytes_list(rng, rng.randint(0, min(max_bytes_length, typ.LIMIT)))
                )
            )
    if issubclass(typ, ByteVector):
        # Random byte vectors can be bigger than max bytes size, e.g. custody chunk data.
        # No max-bytes-length limitation here.
        if mode == RandomizationMode.mode_zero:
            return typ(b"\x00" * typ.get_byte_length())
        elif mode == RandomizationMode.mode_max:
            return typ(b"\xff" * typ.get_byte_length())
        else:
            return typ(get_random_bytes_list(rng, typ.get_byte_length()))
    elif issubclass(typ, Boolean | Uint):
        # Basic types
        if mode == RandomizationMode.mode_zero:
            return get_min_basic_value(typ)
        elif mode == RandomizationMode.mode_max:
            return get_max_basic_value(typ)
        else:
            return get_random_basic_value(rng, typ)
    elif issubclass(typ, Vector | BitVector):
        elem_type = typ.ELEMENT_TYPE if issubclass(typ, Vector) else Boolean
        return typ(
            data=[
                get_random_ssz_object(
                    rng,
                    elem_type,
                    max_bytes_length,
                    max_list_length,
                    mode,
                    chaos,
                    list_length_limits,
                )
                for _ in range(typ.LENGTH)
            ]
        )
    elif issubclass(typ, List | ProgressiveList | BitList | ProgressiveBitList):
        limit = max_list_length
        # SSZ imposes a hard limit on lists, we can't put in more than that
        if not issubclass(typ, ProgressiveList | ProgressiveBitList) and limit > typ.LIMIT:
            limit = typ.LIMIT
        # ProgressiveList has no SSZ bound. Apply optional per-type caps so
        # generated objects stay within consensus/gossip count limits.
        if (
            issubclass(typ, ProgressiveList | ProgressiveBitList)
            and list_length_limits is not None
            and typ in list_length_limits
        ):
            limit = min(limit, list_length_limits[typ])

        length = rng.randint(0, limit)
        if mode == RandomizationMode.mode_one_count:
            length = min(1, limit)
        elif mode == RandomizationMode.mode_max_count:
            length = limit
        elif mode == RandomizationMode.mode_nil_count:
            length = 0

        elem_type = Boolean if issubclass(typ, BitList | ProgressiveBitList) else typ.ELEMENT_TYPE
        max_list_length = 1 << (max_list_length.bit_length() >> 1)
        return typ(
            data=[
                get_random_ssz_object(
                    rng,
                    elem_type,
                    max_bytes_length,
                    max_list_length,
                    mode,
                    chaos,
                    list_length_limits,
                )
                for _ in range(length)
            ]
        )
    elif issubclass(typ, Container | ProgressiveContainer):
        fields = {name: field.annotation for name, field in typ.model_fields.items()}
        # Container
        return typ(
            **{
                field_name: get_random_ssz_object(
                    rng,
                    field_type,
                    max_bytes_length,
                    max_list_length,
                    mode,
                    chaos,
                    list_length_limits,
                )
                for field_name, field_type in fields.items()
            }
        )
    elif issubclass(typ, CompatibleUnion):
        options = typ.OPTIONS
        selector_value: int
        if mode == RandomizationMode.mode_zero:
            selector_value = min(options.keys())
        elif mode == RandomizationMode.mode_max:
            selector_value = max(options.keys())
        else:
            selector_value = rng.choice(list(options.keys()))
        selector = Uint8(selector_value)
        elem_type = options[selector_value]
        return typ(
            selector=selector,
            data=get_random_ssz_object(
                rng,
                elem_type,
                max_bytes_length,
                max_list_length,
                mode,
                chaos,
                list_length_limits,
            ),
        )
    else:
        raise Exception(f"Type not recognized: typ={typ}")


def get_random_bytes_list(rng: Random, length: int) -> bytes:
    return bytes(rng.getrandbits(8) for _ in range(length))


def get_random_basic_value(rng: Random, typ) -> SSZType:
    if issubclass(typ, Boolean):
        return typ(rng.choice((True, False)))
    elif issubclass(typ, Uint):
        assert typ.get_byte_length() in UINT_BYTE_SIZES
        return typ(rng.randint(0, 256 ** typ.get_byte_length() - 1))
    else:
        raise ValueError(f"Not a basic type: typ={typ}")


def get_min_basic_value(typ) -> SSZType:
    if issubclass(typ, Boolean):
        return typ(False)  # noqa: FBT003
    elif issubclass(typ, Uint):
        assert typ.get_byte_length() in UINT_BYTE_SIZES
        return typ(0)
    else:
        raise ValueError(f"Not a basic type: typ={typ}")


def get_max_basic_value(typ) -> SSZType:
    if issubclass(typ, Boolean):
        return typ(True)  # noqa: FBT003
    elif issubclass(typ, Uint):
        assert typ.get_byte_length() in UINT_BYTE_SIZES
        return typ(256 ** typ.get_byte_length() - 1)
    else:
        raise ValueError(f"Not a basic type: typ={typ}")
