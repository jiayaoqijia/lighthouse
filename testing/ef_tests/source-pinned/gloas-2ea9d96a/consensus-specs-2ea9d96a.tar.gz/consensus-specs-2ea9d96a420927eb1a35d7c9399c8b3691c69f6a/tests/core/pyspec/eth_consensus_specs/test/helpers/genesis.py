from hashlib import sha256

from eth_consensus_specs.test.helpers.constants import (
    PHASE0,
)
from eth_consensus_specs.test.helpers.execution_payload import (
    compute_el_block_hash_with_new_fields,
    get_execution_payload_header,
)
from eth_consensus_specs.test.helpers.forks import (
    get_fork_version,
    get_previous_fork_version,
    is_post_altair,
    is_post_bellatrix,
    is_post_deneb,
    is_post_eip8148,
    is_post_eip8321,
    is_post_electra,
    is_post_fulu,
    is_post_gloas,
    is_post_heze,
)
from eth_consensus_specs.test.helpers.fulu.state import (
    initialize_proposer_lookahead,
)
from eth_consensus_specs.test.helpers.gloas.state import (
    initialize_ptc_window,
)
from eth_consensus_specs.test.helpers.keys import builder_pubkeys, pubkeys

GENESIS_ETH1_BLOCK_HASH = b"\xda" * 32


def build_mock_builder(spec, i: int, balance: int):
    return spec.Builder(
        pubkey=builder_pubkeys[i],
        execution_address=spec.ExecutionAddress(spec.sha256(builder_pubkeys[i])[12:]),
        balance=balance,
        deposit_epoch=0,
        withdrawable_epoch=spec.FAR_FUTURE_EPOCH,
    )


def build_mock_validator(spec, i: int, balance: int):
    active_pubkey = pubkeys[i]
    withdrawal_pubkey = pubkeys[((32 * 256) - 1 - i) % len(pubkeys)]
    if is_post_electra(spec):
        if balance > spec.MIN_ACTIVATION_BALANCE:
            # use compounding withdrawal credentials if the balance is higher than MIN_ACTIVATION_BALANCE
            withdrawal_credentials = (
                spec.COMPOUNDING_WITHDRAWAL_PREFIX
                + b"\x00" * 11
                + spec.sha256(withdrawal_pubkey)[12:]
            )
        else:
            # insecurely use pubkey as withdrawal key as well
            withdrawal_credentials = spec.BLS_WITHDRAWAL_PREFIX + spec.sha256(withdrawal_pubkey)[1:]
        max_effective_balance = spec.MAX_EFFECTIVE_BALANCE_ELECTRA
    else:
        # insecurely use pubkey as withdrawal key as well
        withdrawal_credentials = spec.BLS_WITHDRAWAL_PREFIX + spec.sha256(withdrawal_pubkey)[1:]
        max_effective_balance = spec.MAX_EFFECTIVE_BALANCE

    validator = spec.Validator(
        pubkey=active_pubkey,
        withdrawal_credentials=withdrawal_credentials,
        activation_eligibility_epoch=spec.FAR_FUTURE_EPOCH,
        activation_epoch=spec.FAR_FUTURE_EPOCH,
        exit_epoch=spec.FAR_FUTURE_EPOCH,
        withdrawable_epoch=spec.FAR_FUTURE_EPOCH,
        effective_balance=min(
            balance - balance % spec.EFFECTIVE_BALANCE_INCREMENT, max_effective_balance
        ),
    )

    return validator


def get_sample_genesis_execution_payload(spec, eth1_block_hash=None):
    if eth1_block_hash is None:
        eth1_block_hash = b"\x55" * 32

    payload = spec.ExecutionPayload(
        parent_hash=b"\x30" * 32,
        fee_recipient=b"\x42" * 20,
        state_root=b"\x20" * 32,
        receipts_root=b"\x20" * 32,
        logs_bloom=b"\x35" * spec.BYTES_PER_LOGS_BLOOM,
        prev_randao=eth1_block_hash,
        block_number=0,
        gas_limit=30000000,
        base_fee_per_gas=1000000000,
    )

    parent_beacon_block_root = None
    requests_hash = None

    if is_post_deneb(spec):
        parent_beacon_block_root = bytes.fromhex(
            "0000000000000000000000000000000000000000000000000000000000000000"
        )
    if is_post_electra(spec):
        requests_hash = sha256(b"").digest()

    payload.block_hash = compute_el_block_hash_with_new_fields(
        spec,
        payload,
        parent_beacon_block_root,
        requests_hash,
    )
    return payload


def create_genesis_state(spec, validator_balances, activation_threshold, builder_count=8):
    deposit_root = b"\x42" * 32

    eth1_block_hash = GENESIS_ETH1_BLOCK_HASH
    previous_version = spec.config.GENESIS_FORK_VERSION
    current_version = spec.config.GENESIS_FORK_VERSION

    if spec.fork != PHASE0:
        previous_version = get_previous_fork_version(spec, spec.fork)
        current_version = get_fork_version(spec, spec.fork)

    state = spec.BeaconState(
        genesis_time=0,
        fork=spec.Fork(
            previous_version=previous_version,
            current_version=current_version,
            epoch=spec.GENESIS_EPOCH,
        ),
        latest_block_header=spec.BeaconBlockHeader(
            body_root=spec.hash_tree_root(spec.BeaconBlockBody())
        ),
        randao_mixes=spec.RandaoMixes(data=[eth1_block_hash] * spec.EPOCHS_PER_HISTORICAL_VECTOR),
    )

    if not is_post_heze(spec):
        state.eth1_deposit_index = len(validator_balances)
        state.eth1_data = spec.Eth1Data(
            deposit_root=deposit_root,
            deposit_count=len(validator_balances),
            block_hash=eth1_block_hash,
        )

    # We "hack" in the initial validators,
    #  as it is much faster than creating and processing genesis deposits for every single test case.
    state.balances = spec.Balances(data=validator_balances)

    state.validators = spec.Validators(
        data=[
            build_mock_validator(spec, i, state.balances[i]) for i in range(len(validator_balances))
        ]
    )

    # Process genesis activations
    for validator in state.validators:
        if validator.effective_balance >= activation_threshold:
            validator.activation_eligibility_epoch = spec.GENESIS_EPOCH
            validator.activation_epoch = spec.GENESIS_EPOCH
        if is_post_altair(spec):
            state.previous_epoch_participation.append(spec.ParticipationFlags(0b0000_0000))
            state.current_epoch_participation.append(spec.ParticipationFlags(0b0000_0000))
            state.inactivity_scores.append(spec.Uint64(0))

    # Set genesis validators root for domain separation and chain versioning
    state.genesis_validators_root = spec.hash_tree_root(state.validators)

    if is_post_altair(spec):
        # Fill in sync committees
        # Note: A duplicate committee is assigned for the current and next committee at genesis
        state.current_sync_committee = spec.get_next_sync_committee(state)
        state.next_sync_committee = spec.get_next_sync_committee(state)

    if is_post_bellatrix(spec):
        # Initialize the execution payload (with block number and genesis time set to 0)
        genesis_payload = get_sample_genesis_execution_payload(
            spec,
            eth1_block_hash=eth1_block_hash,
        )
    else:
        genesis_payload = None

    if is_post_gloas(spec):
        state.latest_block_hash = genesis_payload.block_hash
        state.latest_execution_payload_bid = spec.ExecutionPayloadBid(
            # The genesis bid's block hash is the empty hash
            block_hash=spec.Hash32(),
            parent_block_hash=genesis_payload.block_hash,
            execution_requests_root=spec.hash_tree_root(spec.ExecutionRequests()),
        )
        # Use realistic body root in the latest block header
        genesis_block_body = spec.BeaconBlockBody()
        genesis_block_body.signed_execution_payload_bid.message = state.latest_execution_payload_bid
        state.latest_block_header = spec.BeaconBlockHeader(
            body_root=spec.hash_tree_root(genesis_block_body)
        )
    elif is_post_bellatrix(spec):
        state.latest_execution_payload_header = get_execution_payload_header(spec, genesis_payload)

    if not is_post_heze(spec):
        if is_post_fulu(spec):
            state.deposit_requests_start_index = state.eth1_data.deposit_count
        elif is_post_electra(spec):
            state.deposit_requests_start_index = spec.UNSET_DEPOSIT_REQUESTS_START_INDEX

    if is_post_electra(spec):
        state.deposit_balance_to_consume = 0
        state.exit_balance_to_consume = 0
        state.earliest_exit_epoch = spec.GENESIS_EPOCH
        state.consolidation_balance_to_consume = 0
        state.earliest_consolidation_epoch = 0
        state.pending_deposits = spec.PendingDeposits()
        state.pending_partial_withdrawals = spec.PendingPartialWithdrawals()
        state.pending_consolidations = spec.PendingConsolidations()

    if is_post_gloas(spec):
        builder_balance = 2 * spec.MIN_DEPOSIT_AMOUNT
        state.builders = spec.Builders(
            data=[build_mock_builder(spec, i, builder_balance) for i in range(builder_count)]
        )
        state.execution_payload_availability = spec.ExecutionPayloadAvailability(
            data=[0b1 for _ in range(spec.SLOTS_PER_HISTORICAL_ROOT)]
        )
        state.payload_expected_withdrawals = spec.Withdrawals()
        state.builder_pending_payments = spec.BuilderPendingPayments(
            data=[spec.BuilderPendingPayment() for _ in range(2 * spec.SLOTS_PER_EPOCH)]
        )
        state.builder_pending_withdrawals = spec.BuilderPendingWithdrawals()
        state.ptc_window = initialize_ptc_window(spec, state)

    if is_post_eip8148(spec):
        state.validator_sweep_thresholds = spec.SweepThresholds(
            data=[spec.Gwei(0)] * len(validator_balances)
        )

    if is_post_eip8321(spec):
        state.randao_commitments = spec.RandaoCommitments(
            data=[spec.Bytes32()] * len(validator_balances)
        )

    if is_post_fulu(spec):
        # Initialize proposer lookahead list
        state.proposer_lookahead = initialize_proposer_lookahead(spec, state)

    return state


def create_signed_genesis_block(spec, state):
    genesis_block_body = spec.BeaconBlockBody()
    if is_post_gloas(spec):
        genesis_block_body.signed_execution_payload_bid.message = state.latest_execution_payload_bid
    return spec.SignedBeaconBlock(
        message=spec.BeaconBlock(
            state_root=spec.hash_tree_root(state),
            body=genesis_block_body,
        )
    )
