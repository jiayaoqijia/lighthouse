from eth_consensus_specs.test.helpers.constants import (
    GLOAS,
)

GLOAS_FORK_TEST_META_TAGS = {
    "fork": GLOAS,
}


def run_fork_test(post_spec, pre_state):
    yield "pre", pre_state

    # The upgrade keeps the collections it is handed rather than copying
    # them, so it is given a copy: the pre-state is the test's own, and is
    # still yielded above as what the fork started from.
    post_state = post_spec.upgrade_to_gloas(pre_state.copy())

    # Stable fields
    stable_fields = [
        "genesis_time",
        "genesis_validators_root",
        "slot",
        "latest_block_header",
        "block_roots",
        "state_roots",
        "historical_roots",
        "eth1_data",
        "eth1_data_votes",
        "eth1_deposit_index",
        "randao_mixes",
        "slashings",
        "justification_bits",
        "previous_justified_checkpoint",
        "current_justified_checkpoint",
        "finalized_checkpoint",
        "current_sync_committee",
        "next_sync_committee",
        "next_withdrawal_index",
        "next_withdrawal_validator_index",
        "historical_summaries",
        "deposit_requests_start_index",
        "deposit_balance_to_consume",
        "exit_balance_to_consume",
        "earliest_exit_epoch",
        "consolidation_balance_to_consume",
        "earliest_consolidation_epoch",
        "proposer_lookahead",
    ]
    for field in stable_fields:
        assert getattr(pre_state, field) == getattr(post_state, field)

    # Modified fields
    modified_fields = [
        "fork",
        "validators",
        "balances",
        "previous_epoch_participation",
        "current_epoch_participation",
        "inactivity_scores",
        "pending_deposits",
        "pending_partial_withdrawals",
        "pending_consolidations",
    ]
    for field in modified_fields:
        assert getattr(pre_state, field) != getattr(post_state, field)

    # Deleted fields
    deleted_fields = ["latest_execution_payload_header"]
    for field in deleted_fields:
        assert not hasattr(post_state, field)

    assert len(pre_state.validators) == len(post_state.validators)
    for pre_validator, post_validator in zip(
        pre_state.validators, post_state.validators, strict=False
    ):
        stable_validator_fields = [
            "pubkey",
            "withdrawal_credentials",
            "slashed",
            "activation_epoch",
            "exit_epoch",
            "withdrawable_epoch",
        ]
        for field in stable_validator_fields:
            assert getattr(pre_validator, field) == getattr(post_validator, field)

    assert pre_state.fork.current_version == post_state.fork.previous_version
    assert post_state.fork.current_version == post_spec.config.GLOAS_FORK_VERSION
    assert post_state.fork.epoch == post_spec.get_current_epoch(post_state)

    # `process_execution_payload_bid` returns this slot as the `parent_slot` of
    # the first Gloas block, which is where `process_attestation` looks up the
    # availability of the attested payload.
    assert post_state.latest_execution_payload_bid.slot == pre_state.latest_block_header.slot

    # Pre-fork payloads count as available, but the payload of the fork slot
    # is not available until it is revealed.
    fork_slot_index = post_state.slot % post_spec.SLOTS_PER_HISTORICAL_ROOT
    for slot_index, available in enumerate(post_state.execution_payload_availability):
        assert bool(available) == (slot_index != fork_slot_index)

    yield "post", post_state

    return post_state
