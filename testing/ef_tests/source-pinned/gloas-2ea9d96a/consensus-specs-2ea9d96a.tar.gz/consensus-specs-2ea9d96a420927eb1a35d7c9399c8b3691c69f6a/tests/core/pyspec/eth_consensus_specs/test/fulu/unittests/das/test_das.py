import random

from deepdiff import DeepDiff

from eth_consensus_specs.test.context import (
    single_phase,
    spec_state_test,
    spec_test,
    with_fulu_and_later,
)
from eth_consensus_specs.test.helpers.blob import (
    build_block_with_blobs,
    get_data_column_sidecars,
    get_sample_blob,
)
from eth_consensus_specs.test.helpers.block import sign_block
from eth_consensus_specs.test.helpers.fork_choice import BlobData, with_blob_data
from eth_consensus_specs.test.helpers.forks import (
    is_post_gloas,
)
from eth_consensus_specs.utils import kzg


def chunks(lst, n):
    """Helper that splits a list into N sized chunks."""
    return [lst[i : i + n] for i in range(0, len(lst), n)]


@with_fulu_and_later
@spec_test
@single_phase
def test_compute_matrix(spec):
    rng = random.Random(5566)

    blob_count = 2
    input_blobs = [get_sample_blob(spec, rng=rng) for _ in range(blob_count)]
    matrix = spec.compute_matrix(input_blobs)
    assert len(matrix) == spec.CELLS_PER_EXT_BLOB * blob_count

    rows = chunks(matrix, spec.CELLS_PER_EXT_BLOB)
    assert len(rows) == blob_count
    for row in rows:
        assert len(row) == spec.CELLS_PER_EXT_BLOB

    for blob_index, row in enumerate(rows):
        # The first half of a row's cells holds the original (un-extended) blob data
        extended_blob = b"".join(bytes(entry.cell) for entry in row)
        blob = extended_blob[: len(extended_blob) // 2]
        assert blob == bytes(input_blobs[blob_index])


@with_fulu_and_later
@spec_test
@single_phase
def test_recover_matrix(spec):
    rng = random.Random(5566)

    # Number of samples we will be recovering from
    N_SAMPLES = spec.CELLS_PER_EXT_BLOB // 2

    # Compute an extended matrix with two blobs
    blob_count = 2
    blobs = [get_sample_blob(spec, rng=rng) for _ in range(blob_count)]
    matrix = spec.compute_matrix(blobs)

    # Construct a matrix with some entries missing
    partial_matrix = []
    for blob_entries in chunks(matrix, spec.CELLS_PER_EXT_BLOB):
        indices = sorted(rng.sample(range(len(blob_entries)), N_SAMPLES))
        partial_matrix.extend([blob_entries[i] for i in indices])

    # Given the partial matrix, recover the missing entries
    recovered_matrix = spec.recover_matrix(partial_matrix, blob_count)

    # Ensure that the recovered matrix matches the original matrix
    assert recovered_matrix == matrix


def run_is_data_available_peerdas_test(spec, signed_block, blob_data):
    def callback():
        yield spec.is_data_available(spec.hash_tree_root(signed_block.message))

    return next(with_blob_data(spec, blob_data, callback))


@with_fulu_and_later
@spec_state_test
def test_is_data_available_peerdas(spec, state):
    rng = random.Random(1234)
    block, blobs, kzg_commitments, blob_kzg_proofs = build_block_with_blobs(
        spec, state, rng=rng, blob_count=2
    )
    signed_block = sign_block(spec, state, block)
    sidecars = get_data_column_sidecars(spec, signed_block, blobs)
    blob_data = BlobData(blobs, blob_kzg_proofs, sidecars, kzg_commitments)

    result = run_is_data_available_peerdas_test(spec, signed_block, blob_data)

    assert result is True, "Data should be available for the block with blob data"


@with_fulu_and_later
@spec_state_test
def test_get_data_column_sidecars(spec, state):
    rng = random.Random(1234)
    block, blobs, _, _ = build_block_with_blobs(spec, state, rng=rng, blob_count=2)
    signed_block = sign_block(spec, state, block)
    sidecars = get_data_column_sidecars(spec, signed_block, blobs)

    if is_post_gloas(spec):
        sidecars_result = spec.get_data_column_sidecars_from_block(
            signed_block,
            [kzg.compute_cells_and_kzg_proofs(blob) for blob in blobs],
        )
    else:
        sidecars_result = spec.get_data_column_sidecars(
            signed_block_header=spec.compute_signed_block_header(signed_block),
            kzg_commitments=sidecars[0].kzg_commitments,
            kzg_commitments_inclusion_proof=sidecars[0].kzg_commitments_inclusion_proof,
            cells_and_kzg_proofs=[kzg.compute_cells_and_kzg_proofs(blob) for blob in blobs],
        )

    assert len(sidecars_result) == len(sidecars), (
        "Should return the same number of sidecars as input"
    )
    assert DeepDiff(sidecars, sidecars_result) == {}, "Sidecars should match the expected sidecars"


@with_fulu_and_later
@spec_state_test
def test_get_data_column_sidecars_no_blobs(spec, state):
    rng = random.Random(1234)
    block, blobs, _, _ = build_block_with_blobs(spec, state, rng=rng, blob_count=0)
    signed_block = sign_block(spec, state, block)
    sidecars = get_data_column_sidecars(spec, signed_block, blobs)

    assert len(sidecars) == 0, "Should return no sidecars for a block without blobs"


@with_fulu_and_later
@spec_state_test
def test_get_data_column_sidecars_from_column_sidecar(spec, state):
    rng = random.Random(1234)
    block, blobs, _, _ = build_block_with_blobs(spec, state, rng=rng, blob_count=2)
    signed_block = sign_block(spec, state, block)
    sidecars = get_data_column_sidecars(spec, signed_block, blobs)

    sidecars_result = spec.get_data_column_sidecars_from_column_sidecar(
        sidecar=sidecars[0],
        cells_and_kzg_proofs=[kzg.compute_cells_and_kzg_proofs(blob) for blob in blobs],
    )

    assert len(sidecars_result) == len(sidecars), (
        "Should return the same number of sidecars as input"
    )
    assert DeepDiff(sidecars, sidecars_result) == {}, "Sidecars should match the expected sidecars"
