# Gloas -- Networking

*Note*: This document is a work-in-progress for researchers and implementers.

<!-- mdformat-toc start --slug=github --no-anchors --maxlevel=6 --minlevel=2 -->

- [Introduction](#introduction)
- [Presets](#presets)
  - [Type-specific SSZ bounds](#type-specific-ssz-bounds)
- [Configs](#configs)
- [Types](#types)
  - [Modified `DataColumn`](#modified-datacolumn)
  - [Modified `KZGProofs`](#modified-kzgproofs)
  - [New `ExecutionPayloadEnvelopeRoots`](#new-executionpayloadenveloperoots)
  - [New `SignedExecutionPayloadEnvelopes`](#new-signedexecutionpayloadenvelopes)
- [Containers](#containers)
  - [Modified `DataColumnSidecar`](#modified-datacolumnsidecar)
  - [New `ProposerPreferences`](#new-proposerpreferences)
  - [New `SignedProposerPreferences`](#new-signedproposerpreferences)
- [Helpers](#helpers)
  - [Modified `Seen`](#modified-seen)
  - [Modified `compute_fork_version`](#modified-compute_fork_version)
  - [Modified `compute_min_epochs_for_block_requests`](#modified-compute_min_epochs_for_block_requests)
  - [Modified `verify_data_column_sidecar_kzg_proofs`](#modified-verify_data_column_sidecar_kzg_proofs)
  - [Modified `verify_data_column_sidecar`](#modified-verify_data_column_sidecar)
  - [New `compute_max_data_column_sidecar_size`](#new-compute_max_data_column_sidecar_size)
  - [New `get_builder_bid_limit`](#new-get_builder_bid_limit)
  - [New `is_current_or_next_slot`](#new-is_current_or_next_slot)
  - [New `is_past_slot`](#new-is_past_slot)
  - [New `is_gas_limit_target_compatible`](#new-is_gas_limit_target_compatible)
  - [New `is_bid_compatible_with_head`](#new-is_bid_compatible_with_head)
  - [New `verify_attestation_payload_status`](#new-verify_attestation_payload_status)
  - [New `verify_block_body_operation_limits`](#new-verify_block_body_operation_limits)
  - [New `verify_execution_requests_limits`](#new-verify_execution_requests_limits)
- [The gossip domain: gossipsub](#the-gossip-domain-gossipsub)
  - [Topics and messages](#topics-and-messages)
    - [Global topics](#global-topics)
      - [Modified `beacon_block`](#modified-beacon_block)
      - [Modified `beacon_aggregate_and_proof`](#modified-beacon_aggregate_and_proof)
      - [New `execution_payload`](#new-execution_payload)
      - [New `payload_attestation_message`](#new-payload_attestation_message)
      - [New `execution_payload_bid`](#new-execution_payload_bid)
      - [New `proposer_preferences`](#new-proposer_preferences)
    - [Attestation subnets](#attestation-subnets)
      - [Modified `beacon_attestation_{subnet_id}`](#modified-beacon_attestation_subnet_id)
    - [Blob subnets](#blob-subnets)
      - [Modified `data_column_sidecar_{subnet_id}`](#modified-data_column_sidecar_subnet_id)
- [The Req/Resp domain](#the-reqresp-domain)
  - [Messages](#messages)
    - [BeaconBlocksByRange v2](#beaconblocksbyrange-v2)
    - [BeaconBlocksByRoot v2](#beaconblocksbyroot-v2)
    - [ExecutionPayloadEnvelopesByRange v1](#executionpayloadenvelopesbyrange-v1)
    - [ExecutionPayloadEnvelopesByRoot v1](#executionpayloadenvelopesbyroot-v1)

<!-- mdformat-toc end -->

## Introduction

This document contains the consensus-layer networking specifications for Gloas.

The specification of these changes continues in the same format as the network
specifications of previous upgrades, and assumes them as pre-requisite.

## Presets

### Type-specific SSZ bounds

*[New in Gloas:EIP7688]*

These constants supersede
[type-specific SSZ bounds](../phase0/p2p-interface.md#what-are-ssz-type-size-bounds)
for the corresponding variable-size libp2p messages. The bound for
`DataColumnSidecar` is given by `compute_max_data_column_sidecar_size()`.

| Name                                    | Value                         |
| --------------------------------------- | ----------------------------- |
| `MAX_SIGNED_AGGREGATE_AND_PROOF_SIZE`   | `Uint64(16829)` (= ~16 KiB)   |
| `MAX_ATTESTER_SLASHING_SIZE`            | `Uint64(2097616)` (= ~2 MiB)  |
| `MAX_SIGNED_EXECUTION_PAYLOAD_BID_SIZE` | `Uint64(196932)` (= ~192 KiB) |

## Configs

| Name                   | Value                  |
| ---------------------- | ---------------------- |
| `MAX_REQUEST_PAYLOADS` | `Uint64(2**7)` (= 128) |

## Types

### Modified `DataColumn`

```python
# [Modified in Gloas:EIP7688]
class DataColumn(ProgressiveList[Cell]):
    """
    A column of the extended blob data matrix, with at most one cell per blob.
    """
```

### Modified `KZGProofs`

```python
# [Modified in Gloas:EIP7688]
class KZGProofs(ProgressiveList[KZGProof]):
    """
    The KZG cell proofs of the cells held by a data column.
    """
```

### New `ExecutionPayloadEnvelopeRoots`

```python
class ExecutionPayloadEnvelopeRoots(List[Root]):
    """
    The beacon block roots of the payload envelopes requested in an
    ``ExecutionPayloadEnvelopesByRoot`` request.
    """

    LIMIT = MAX_REQUEST_PAYLOADS
```

### New `SignedExecutionPayloadEnvelopes`

```python
class SignedExecutionPayloadEnvelopes(List[SignedExecutionPayloadEnvelope]):
    """
    Signed execution payload envelopes returned in an
    ``ExecutionPayloadEnvelopesByRange`` or
    ``ExecutionPayloadEnvelopesByRoot`` response.
    """

    LIMIT = MAX_REQUEST_PAYLOADS
```

## Containers

### Modified `DataColumnSidecar`

*Note*: The `signed_block_header`, `kzg_commitments`, and
`kzg_commitments_inclusion_proof` fields have been removed from
`DataColumnSidecar` in Gloas as header and inclusion proof verifications are no
longer required in Gloas. The KZG commitments are now located at
`block.body.signed_execution_payload_bid.message.blob_kzg_commitments` where
`block` is the `BeaconBlock` associated with `beacon_block_root`.

```python
class DataColumnSidecar(Container):
    index: ColumnIndex
    # [Modified in Gloas:EIP7688]
    column: DataColumn
    # [Modified in Gloas:EIP7732]
    # Removed `kzg_commitments`
    # [Modified in Gloas:EIP7688]
    kzg_proofs: KZGProofs
    # [Modified in Gloas:EIP7732]
    # Removed `signed_block_header`
    # [Modified in Gloas:EIP7732]
    # Removed `kzg_commitments_inclusion_proof`
    # [New in Gloas:EIP7732]
    slot: Slot
    # [New in Gloas:EIP7732]
    beacon_block_root: Root
```

### New `ProposerPreferences`

*[New in Gloas:EIP7732]*

```python
class ProposerPreferences(Container):
    dependent_root: Root
    proposal_slot: Slot
    validator_index: ValidatorIndex
    fee_recipient: ExecutionAddress
    target_gas_limit: Uint64
```

### New `SignedProposerPreferences`

*[New in Gloas:EIP7732]*

```python
class SignedProposerPreferences(Container):
    message: ProposerPreferences
    signature: BLSSignature
```

## Helpers

### Modified `Seen`

```python
@dataclass
class Seen:
    proposer_slots: set[tuple[Slot, ValidatorIndex]]
    aggregator_epochs: set[tuple[Epoch, ValidatorIndex]]
    aggregate_data_roots: dict[tuple[Root, CommitteeIndex], set[tuple[bool, ...]]]
    voluntary_exit_indices: set[ValidatorIndex]
    proposer_slashing_indices: set[ValidatorIndex]
    attester_slashing_indices: set[ValidatorIndex]
    attestation_validator_epochs: set[tuple[Epoch, ValidatorIndex]]
    sync_contribution_aggregator_slots: set[tuple[Slot, ValidatorIndex, Uint64]]
    sync_contribution_data: dict[tuple[Slot, Root, Uint64], set[tuple[bool, ...]]]
    sync_message_validator_slots: set[tuple[Slot, ValidatorIndex, Uint64]]
    bls_to_execution_change_indices: set[ValidatorIndex]
    # [Modified in Gloas:EIP7732]
    data_column_sidecar_tuples: set[tuple[Root, ColumnIndex]]
    # [Modified in Gloas:EIP7732]
    # Removed `partial_data_column_headers`
    # [New in Gloas:EIP7732]
    execution_payloads: dict[Hash32, ExecutionPayload]
    # [New in Gloas:EIP7732]
    execution_payload_envelopes: set[tuple[Root, BuilderIndex]]
    # [New in Gloas:EIP7732]
    payload_attestation_validators: set[tuple[Slot, ValidatorIndex]]
    # [New in Gloas:EIP7732]
    execution_payload_bid_counts: Counter[tuple[Slot, Hash32, Root, BuilderIndex]]
    # [New in Gloas:EIP7732]
    best_execution_payload_bid: dict[tuple[Slot, Hash32, Root], Gwei]
    # [New in Gloas:EIP7732]
    proposer_preferences: dict[tuple[Slot, Root], ProposerPreferences]
```

### Modified `compute_fork_version`

```python
def compute_fork_version(epoch: Epoch) -> Version:
    """
    Return the fork version at the given ``epoch``.
    """
    if epoch >= GLOAS_FORK_EPOCH:
        return GLOAS_FORK_VERSION
    if epoch >= FULU_FORK_EPOCH:
        return FULU_FORK_VERSION
    if epoch >= ELECTRA_FORK_EPOCH:
        return ELECTRA_FORK_VERSION
    if epoch >= DENEB_FORK_EPOCH:
        return DENEB_FORK_VERSION
    if epoch >= CAPELLA_FORK_EPOCH:
        return CAPELLA_FORK_VERSION
    if epoch >= BELLATRIX_FORK_EPOCH:
        return BELLATRIX_FORK_VERSION
    if epoch >= ALTAIR_FORK_EPOCH:
        return ALTAIR_FORK_VERSION
    return GENESIS_FORK_VERSION
```

### Modified `compute_min_epochs_for_block_requests`

*Note*: `compute_min_epochs_for_block_requests` is modified to use the
arithmetic from `compute_weak_subjectivity_period` found in the
[weak subjectivity guide](./weak-subjectivity.md). In the worst case of a very
large validator set, the capped activation churn is negligible, which leaves the
exit churn (weighted 2/3) and the consolidation churn (weighted 1).

```python
def compute_min_epochs_for_block_requests() -> Epoch:
    """
    Return the minimum epoch range over which a node must serve blocks.
    """
    # [Modified in Gloas:EIP8061]
    numerator = 3 * CHURN_LIMIT_QUOTIENT_GLOAS * CONSOLIDATION_CHURN_LIMIT_QUOTIENT
    denominator = 2 * CONSOLIDATION_CHURN_LIMIT_QUOTIENT + 3 * CHURN_LIMIT_QUOTIENT_GLOAS
    return MIN_VALIDATOR_WITHDRAWABILITY_DELAY + (numerator // denominator) // 2
```

### Modified `verify_data_column_sidecar_kzg_proofs`

```python
def verify_data_column_sidecar_kzg_proofs(
    sidecar: DataColumnSidecar,
    # [New in Gloas:EIP7732]
    kzg_commitments: BlobKZGCommitments,
) -> bool:
    """
    Verify if the KZG proofs are correct.
    """
    # The column index also represents the cell index
    cell_indices = [CellIndex(sidecar.index)] * len(sidecar.column)

    # Batch verify that the cells match the corresponding commitments and proofs
    return kzg.verify_cell_kzg_proof_batch(
        # [Modified in Gloas:EIP7732]
        commitments_bytes=kzg_commitments,
        cell_indices=cell_indices,
        cells=sidecar.column,
        proofs_bytes=sidecar.kzg_proofs,
    )
```

### Modified `verify_data_column_sidecar`

```python
def verify_data_column_sidecar(
    sidecar: DataColumnSidecar,
    # [New in Gloas:EIP7732]
    kzg_commitments: BlobKZGCommitments,
) -> bool:
    """
    Verify if the data column sidecar is valid.
    """
    # The sidecar index must be within the valid range
    if sidecar.index >= NUMBER_OF_COLUMNS:
        return False

    # [Modified in Gloas:EIP7732]
    # A sidecar for zero blobs is invalid
    if len(sidecar.column) == 0:
        return False

    # [Modified in Gloas:EIP7732]
    # The column length must be equal to the number of commitments
    if len(sidecar.column) != len(kzg_commitments):
        return False

    # The column length must be equal to the number of proofs
    if len(sidecar.column) != len(sidecar.kzg_proofs):
        return False

    return True
```

### New `compute_max_data_column_sidecar_size`

```python
def compute_max_data_column_sidecar_size() -> Uint64:
    """
    Return the maximum size of a serialized ``DataColumnSidecar`` computed
    using the largest ``max_blobs_per_block`` value from the blob schedule,
    regardless of whether or not that is the current ``max_blobs_per_block``.
    """
    max_blobs = MAX_BLOBS_PER_BLOCK_ELECTRA
    for entry in BLOB_SCHEDULE:
        max_blobs = max(max_blobs, entry["MAX_BLOBS_PER_BLOCK"])

    sidecar = DataColumnSidecar(
        index=ColumnIndex(),
        column=DataColumn(data=[Cell()] * max_blobs),
        kzg_proofs=KZGProofs(data=[KZGProof()] * max_blobs),
        slot=Slot(),
        beacon_block_root=Root(),
    )
    return Uint64(len(ssz_serialize(sidecar)))
```

### New `get_builder_bid_limit`

```python
def get_builder_bid_limit(state: BeaconState, builder_index: BuilderIndex) -> Uint64:
    """
    Return the number of bids the builder may submit for each slot and parent.
    """
    balance = state.builders[builder_index].balance
    pending_withdrawals_amount = get_pending_balance_to_withdraw_for_builder(state, builder_index)
    return Uint64(saturating_sub(balance, pending_withdrawals_amount) // ETH_TO_GWEI)
```

### New `is_current_or_next_slot`

```python
def is_current_or_next_slot(
    store: Store,
    slot: Slot,
    current_time_ms: Uint64,
) -> bool:
    """
    Check if the given slot is the current slot or the next slot
    (with MAXIMUM_GOSSIP_CLOCK_DISPARITY allowance).
    """
    is_current = is_current_slot(store, slot, current_time_ms)
    is_next = is_current_slot(store, slot - 1, current_time_ms)
    return is_current or is_next
```

### New `is_past_slot`

```python
def is_past_slot(
    store: Store,
    slot: Slot,
    current_time_ms: Uint64,
) -> bool:
    """
    Check if the given slot is in the past
    (with MAXIMUM_GOSSIP_CLOCK_DISPARITY allowance).
    """
    slot_time_ms = compute_time_at_slot_ms(store.genesis_time_ms, slot)
    return current_time_ms > slot_time_ms + MAXIMUM_GOSSIP_CLOCK_DISPARITY
```

### New `is_gas_limit_target_compatible`

```python
def is_gas_limit_target_compatible(
    parent_gas_limit: Uint64, gas_limit: Uint64, target_gas_limit: Uint64
) -> bool:
    """
    Check if ``gas_limit`` is compatible with ``target_gas_limit`` under the
    EIP-1559 transition rule from ``parent_gas_limit``.
    """
    max_gas_limit_difference = saturating_sub(parent_gas_limit // 1024, 1)
    min_gas_limit = parent_gas_limit - max_gas_limit_difference
    max_gas_limit = parent_gas_limit + max_gas_limit_difference

    if target_gas_limit < min_gas_limit:
        return gas_limit == min_gas_limit
    if target_gas_limit > max_gas_limit:
        return gas_limit == max_gas_limit
    return gas_limit == target_gas_limit
```

### New `is_bid_compatible_with_head`

```python
def is_bid_compatible_with_head(store: Store, bid: ExecutionPayloadBid) -> bool:
    """
    Check if ``bid`` is compatible with the head branch.
    """
    head_node = get_head(store)
    head_block = store.blocks[head_node.root]
    head_bid = head_block.body.signed_execution_payload_bid.message

    builds_on_parent_block = bid.parent_block_root == head_block.parent_root
    builds_on_parent_payload = bid.parent_block_hash == head_bid.parent_block_hash

    if builds_on_parent_block and builds_on_parent_payload:
        return True

    if bid.parent_block_root != head_node.root:
        return False

    builds_on_head_payload = bid.parent_block_hash == head_bid.block_hash

    if should_build_on_full(store, head_node, bid.slot):
        return builds_on_head_payload

    return builds_on_parent_payload
```

### New `verify_attestation_payload_status`

```python
def verify_attestation_payload_status(
    store: Store,
    data: AttestationData,
    block_payload_statuses: dict[Root, PayloadValidationStatus],
) -> None:
    """
    Verify that the attested payload status is consistent with the block's payload.
    Raises GossipIgnore or GossipReject on validation failure.
    """
    block_root = data.beacon_block_root
    block = store.blocks[block_root]

    # [REJECT] For same-slot attestations, the payload cannot yet be present
    if block.slot == data.slot and data.index != 0:
        raise GossipReject("same-slot attestation must attest with index 0")

    if data.index != 1:
        return

    # [IGNORE] The corresponding execution payload envelope has been seen and verified
    # (MAY queue attestations for processing once the payload is retrieved and
    # SHOULD request the payload envelope via ExecutionPayloadEnvelopesByRoot
    # using data.beacon_block_root)
    if not is_payload_verified(store, block_root):
        raise GossipIgnore("execution payload envelope has not been seen")

    # [IGNORE] The attested execution payload is optimistic
    payload_status = block_payload_statuses.get(block_root, PAYLOAD_STATUS_NOT_VALIDATED)
    if payload_status == PAYLOAD_STATUS_NOT_VALIDATED:
        raise GossipIgnore("attested payload is optimistic")

    # [REJECT] The attested execution payload is processed and invalid
    if payload_status == PAYLOAD_STATUS_INVALIDATED:
        raise GossipReject("attested payload is invalid")
```

### New `verify_block_body_operation_limits`

*Note*: These checks MAY be performed when deserializing `BeaconBlockBody`.

```python
def verify_block_body_operation_limits(body: BeaconBlockBody) -> None:
    """
    Verify that each block body operation count is within its limit.
    Raises GossipReject on validation failure.
    """
    # [REJECT] The proposer slashing count is within the limit
    if len(body.proposer_slashings) > MAX_PROPOSER_SLASHINGS:
        raise GossipReject("too many proposer slashings")

    # [REJECT] The attester slashing count is within the limit
    if len(body.attester_slashings) > MAX_ATTESTER_SLASHINGS_ELECTRA:
        raise GossipReject("too many attester slashings")

    # [REJECT] The attestation count is within the limit
    if len(body.attestations) > MAX_ATTESTATIONS_ELECTRA:
        raise GossipReject("too many attestations")

    # [REJECT] The block contains no deposits
    if len(body.deposits) != 0:
        raise GossipReject("block must not contain deposits")

    # [REJECT] The voluntary exit count is within the limit
    if len(body.voluntary_exits) > MAX_VOLUNTARY_EXITS:
        raise GossipReject("too many voluntary exits")

    # [REJECT] The BLS to execution change count is within the limit
    if len(body.bls_to_execution_changes) > MAX_BLS_TO_EXECUTION_CHANGES:
        raise GossipReject("too many bls to execution changes")

    # [REJECT] The payload attestation count is within the limit
    if len(body.payload_attestations) > MAX_PAYLOAD_ATTESTATIONS:
        raise GossipReject("too many payload attestations")
```

### New `verify_execution_requests_limits`

*Note*: These checks MAY be performed when deserializing `ExecutionRequests`.

```python
def verify_execution_requests_limits(execution_requests: ExecutionRequests) -> None:
    """
    Verify that each execution request count is within its limit.
    Raises GossipReject on validation failure.
    """
    # [REJECT] The withdrawal request count is within the limit
    if len(execution_requests.withdrawals) > MAX_WITHDRAWAL_REQUESTS_PER_PAYLOAD:
        raise GossipReject("too many withdrawal requests")

    # [REJECT] The consolidation request count is within the limit
    if len(execution_requests.consolidations) > MAX_CONSOLIDATION_REQUESTS_PER_PAYLOAD:
        raise GossipReject("too many consolidation requests")

    # [REJECT] The builder deposit request count is within the limit
    if len(execution_requests.builder_deposits) > MAX_BUILDER_DEPOSIT_REQUESTS_PER_PAYLOAD:
        raise GossipReject("too many builder deposit requests")

    # [REJECT] The builder exit request count is within the limit
    if len(execution_requests.builder_exits) > MAX_BUILDER_EXIT_REQUESTS_PER_PAYLOAD:
        raise GossipReject("too many builder exit requests")
```

## The gossip domain: gossipsub

Some gossip meshes are upgraded in Gloas to support upgraded types.

### Topics and messages

Topics follow the same specification as in prior upgrades.

The `beacon_block` topic is updated to support the modified type

| Name           | Message Type        |
| -------------- | ------------------- |
| `beacon_block` | `SignedBeaconBlock` |

The new topics along with the type of the `data` field of a gossipsub message
are given in this table:

| Name                          | Message Type                     |
| ----------------------------- | -------------------------------- |
| `execution_payload_bid`       | `SignedExecutionPayloadBid`      |
| `execution_payload`           | `SignedExecutionPayloadEnvelope` |
| `payload_attestation_message` | `PayloadAttestationMessage`      |
| `proposer_preferences`        | `SignedProposerPreferences`      |

#### Global topics

##### Modified `beacon_block`

*Note*: This function is modified per EIP-7732. The execution payload is no
longer carried inside `BeaconBlock`. As a result, all validations referring to
`block.body.execution_payload` are removed and replaced with validations of the
bid carried at `block.body.signed_execution_payload_bid.message`.

```python
def validate_beacon_block_gossip(
    seen: Seen,
    store: Store,
    signed_beacon_block: SignedBeaconBlock,
    current_time_ms: Uint64,
    # [Modified in Gloas:EIP7732]
    # Removed `block_payload_statuses`
) -> None:
    """
    Validate a SignedBeaconBlock for gossip propagation.
    Raises GossipIgnore or GossipReject on validation failure.
    """
    block = signed_beacon_block.message
    bid = block.body.signed_execution_payload_bid.message

    # [IGNORE] The block is the first block with valid signature received for the slot and proposer
    proposer_slot_key = (block.slot, block.proposer_index)
    if proposer_slot_key in seen.proposer_slots:
        raise GossipIgnore("block is not the first valid block for this slot and proposer")

    # [IGNORE] The block is not from a future slot
    # (MAY be queued for processing at the appropriate slot)
    if is_future_slot(store, block.slot, current_time_ms):
        raise GossipIgnore("block is from a future slot")

    # [IGNORE] The block is from a slot greater than the latest finalized slot
    # (MAY choose to validate and store such blocks for additional purposes
    # -- e.g. slashing detection, archive nodes, etc)
    finalized_slot = compute_start_slot_at_epoch(store.finalized_checkpoint.epoch)
    if block.slot <= finalized_slot:
        raise GossipIgnore("block is not from a slot greater than the latest finalized slot")

    # [New in Gloas:EIP7688]
    # [REJECT] The block body operation counts are within their limits
    verify_block_body_operation_limits(block.body)

    # [New in Gloas:EIP7688]
    # [REJECT] The parent execution request counts are within their limits
    verify_execution_requests_limits(block.body.parent_execution_requests)

    # [IGNORE] The block's parent has been seen (via gossip or non-gossip sources)
    # (MAY be queued until parent is retrieved)
    if block.parent_root not in store.blocks:
        raise GossipIgnore("block's parent has not been seen")

    # [REJECT] The block's parent passes validation
    if block.parent_root not in store.block_states:
        raise GossipReject("block's parent is invalid")

    state = store.block_states[get_head(store).root]

    # [REJECT] The proposer index is a valid validator index
    if block.proposer_index >= len(state.validators):
        raise GossipReject("proposer index out of range")

    # [REJECT] The proposer signature is valid
    proposer = state.validators[block.proposer_index]
    domain = get_domain(state, DOMAIN_BEACON_PROPOSER, compute_epoch_at_slot(block.slot))
    signing_root = compute_signing_root(block, domain)
    if not bls.Verify(proposer.pubkey, signing_root, signed_beacon_block.signature):
        raise GossipReject("invalid proposer signature")

    # [New in Gloas:EIP7732]
    # [IGNORE] If the parent block is full, the parent payload is valid
    # (MAY be queued until the parent payload is verified)
    if is_parent_node_full(store, block):
        if not is_payload_verified(store, block.parent_root):
            raise GossipIgnore("parent payload is not verified")

    # [REJECT] The block is from a higher slot than its parent
    if block.slot <= store.blocks[block.parent_root].slot:
        raise GossipReject("block is not from a higher slot than its parent")

    # [REJECT] The current finalized checkpoint is an ancestor of the block
    finalized_epoch = store.finalized_checkpoint.epoch
    finalized_checkpoint_block = get_checkpoint_block(store, block.parent_root, finalized_epoch)
    if finalized_checkpoint_block != store.finalized_checkpoint.root:
        raise GossipReject("finalized checkpoint is not an ancestor of block")

    # [Modified in Gloas:EIP7732]
    # [REJECT] The bid's blob KZG commitment count is within the per-epoch limit
    max_blobs = get_blob_parameters(compute_epoch_at_slot(block.slot)).max_blobs_per_block
    if len(bid.blob_kzg_commitments) > max_blobs:
        raise GossipReject("too many blob kzg commitments")

    # [Modified in Gloas:EIP7732]
    # [REJECT] The bid's parent equals the block's parent
    if bid.parent_block_root != block.parent_root:
        raise GossipReject("bid's parent does not equal block's parent")

    # [REJECT] The block is proposed by the expected proposer for the slot
    parent_state = store.block_states[block.parent_root].copy()
    process_slots(parent_state, block.slot)
    expected_proposer = get_beacon_proposer_index(parent_state)
    if block.proposer_index != expected_proposer:
        raise GossipReject("block proposer_index does not match expected proposer")

    # [New in Gloas:EIP7732]
    # [REJECT] If the parent is not full, the bid builds on the parent's execution head
    if not is_parent_node_full(store, block):
        if bid.parent_block_hash != parent_state.latest_block_hash:
            raise GossipReject("bid does not build on the parent's execution head")

    # Mark this block as seen
    seen.proposer_slots.add(proposer_slot_key)
```

##### Modified `beacon_aggregate_and_proof`

*Note*: This function is modified per EIP-7732. `aggregate.data.index` is now
restricted to `{0, 1}`, encoding whether the execution payload was present at
the slot. Same-slot aggregates MUST attest with `index == 0`. Aggregates with
`index == 1` require that the corresponding execution payload envelope has been
seen and passes execution-layer validation.

```python
def validate_beacon_aggregate_and_proof_gossip(
    seen: Seen,
    store: Store,
    signed_aggregate_and_proof: SignedAggregateAndProof,
    current_time_ms: Uint64,
    # [New in Gloas:EIP7732]
    block_payload_statuses: dict[Root, PayloadValidationStatus],
) -> None:
    """
    Validate a SignedAggregateAndProof for gossip propagation.
    Raises GossipIgnore or GossipReject on validation failure.
    """
    aggregate_and_proof = signed_aggregate_and_proof.message
    aggregate = aggregate_and_proof.aggregate
    aggregation_bits = aggregate.aggregation_bits

    # [New in Gloas:EIP7732]
    # [REJECT] The aggregate attestation's data index is 0 or 1
    if aggregate.data.index > 1:
        raise GossipReject("aggregate data index must be 0 or 1")

    # [REJECT] Exactly one committee is specified by the committee bits
    committee_indices = get_committee_indices(aggregate.committee_bits)
    if len(committee_indices) != 1:
        raise GossipReject("aggregate committee bits must specify exactly one committee")
    index = committee_indices[0]

    # [IGNORE] A valid aggregate with a superset of aggregation bits has not already been seen
    aggregate_data_root = hash_tree_root(aggregate.data)
    aggregate_cache_key = (aggregate_data_root, index)
    aggregate_bits = tuple(bool(bit) for bit in aggregation_bits)
    seen_bits = seen.aggregate_data_roots.get(aggregate_cache_key, set())
    if is_non_strict_superset(seen_bits, aggregate_bits):
        raise GossipIgnore("already seen aggregate for this data")

    # [IGNORE] This is the first valid aggregate for this epoch and aggregator
    aggregator_index = aggregate_and_proof.aggregator_index
    target_epoch = aggregate.data.target.epoch
    aggregator_epoch_key = (target_epoch, aggregator_index)
    if aggregator_epoch_key in seen.aggregator_epochs:
        raise GossipIgnore("already seen aggregate for this epoch and aggregator")

    # [IGNORE] The block being voted for has been seen (via gossip or non-gossip sources)
    # (MAY be queued until block is retrieved)
    block_root = aggregate.data.beacon_block_root
    if block_root not in store.blocks:
        raise GossipIgnore("block being voted for has not been seen")

    # [REJECT] The block being voted for passes validation
    if block_root not in store.block_states:
        raise GossipReject("block being voted for failed validation")

    state = store.block_states[get_head(store).root]

    # [REJECT] The committee index is within the expected range
    committee_count = get_committee_count_per_slot(state, aggregate.data.target.epoch)
    if index >= committee_count:
        raise GossipReject("committee index out of range")

    # [IGNORE] The aggregate attestation's slot is not from a future slot
    # (MAY be queued for processing at the appropriate slot)
    if is_future_slot(store, aggregate.data.slot, current_time_ms):
        raise GossipIgnore("aggregate slot is from a future slot")

    # [IGNORE] The aggregate attestation's epoch is either the current or previous epoch
    attestation_epoch = compute_epoch_at_slot(aggregate.data.slot)
    if not is_current_or_previous_epoch(store, attestation_epoch, current_time_ms):
        raise GossipIgnore("aggregate epoch is not current or previous epoch")

    # [REJECT] The aggregate attestation's epoch matches its target
    if aggregate.data.target.epoch != compute_epoch_at_slot(aggregate.data.slot):
        raise GossipReject("attestation epoch does not match target epoch")

    # [REJECT] The number of aggregation bits matches the committee size
    committee = get_beacon_committee(state, aggregate.data.slot, index)
    if len(aggregation_bits) != len(committee):
        raise GossipReject("aggregation bits length does not match committee size")

    # [REJECT] The aggregate attestation has participants
    attesting_indices = get_attesting_indices(state, aggregate)
    if len(attesting_indices) < 1:
        raise GossipReject("aggregate has no participants")

    # [REJECT] The selection proof selects the validator as an aggregator
    if not is_aggregator(state, aggregate.data.slot, index, aggregate_and_proof.selection_proof):
        raise GossipReject("validator is not selected as aggregator")

    # [REJECT] The aggregator is a member of the committee
    if aggregator_index not in committee:
        raise GossipReject("aggregator is not a member of the committee")

    # [REJECT] The selection proof signature is valid
    aggregator = state.validators[aggregator_index]
    domain = get_domain(state, DOMAIN_SELECTION_PROOF, target_epoch)
    signing_root = compute_signing_root(aggregate.data.slot, domain)
    if not bls.Verify(aggregator.pubkey, signing_root, aggregate_and_proof.selection_proof):
        raise GossipReject("invalid selection proof signature")

    # [REJECT] The aggregator signature is valid
    domain = get_domain(state, DOMAIN_AGGREGATE_AND_PROOF, target_epoch)
    signing_root = compute_signing_root(aggregate_and_proof, domain)
    if not bls.Verify(aggregator.pubkey, signing_root, signed_aggregate_and_proof.signature):
        raise GossipReject("invalid aggregator signature")

    # [REJECT] The aggregate signature is valid
    if not is_valid_indexed_attestation(state, get_indexed_attestation(state, aggregate)):
        raise GossipReject("invalid aggregate signature")

    # [REJECT] The target block is an ancestor of the LMD vote block
    checkpoint_block = get_checkpoint_block(store, block_root, aggregate.data.target.epoch)
    if checkpoint_block != aggregate.data.target.root:
        raise GossipReject("target block is not an ancestor of LMD vote block")

    # [IGNORE] The finalized checkpoint is an ancestor of the block
    finalized_epoch = store.finalized_checkpoint.epoch
    finalized_checkpoint_block = get_checkpoint_block(store, block_root, finalized_epoch)
    if finalized_checkpoint_block != store.finalized_checkpoint.root:
        raise GossipIgnore("finalized checkpoint is not an ancestor of block")

    # [New in Gloas:EIP7732]
    # The attested payload status is consistent with the block's execution payload
    verify_attestation_payload_status(store, aggregate.data, block_payload_statuses)

    # Mark this aggregate as seen
    seen.aggregator_epochs.add(aggregator_epoch_key)
    if aggregate_cache_key not in seen.aggregate_data_roots:
        seen.aggregate_data_roots[aggregate_cache_key] = set()
    seen.aggregate_data_roots[aggregate_cache_key].add(aggregate_bits)
```

##### New `execution_payload`

This topic is used to propagate execution payload messages as
`SignedExecutionPayloadEnvelope`.

```python
def validate_execution_payload_envelope_gossip(
    seen: Seen,
    store: Store,
    signed_execution_payload_envelope: SignedExecutionPayloadEnvelope,
) -> None:
    """
    Validate a SignedExecutionPayloadEnvelope for gossip propagation.
    Raises GossipIgnore or GossipReject on validation failure.
    """
    envelope = signed_execution_payload_envelope.message
    payload = envelope.payload
    block_root = envelope.beacon_block_root

    # [IGNORE] The node has not seen another valid envelope for this block root from this builder
    envelope_key = (block_root, envelope.builder_index)
    if envelope_key in seen.execution_payload_envelopes:
        raise GossipIgnore("already seen envelope for this block root from this builder")

    # [IGNORE] The envelope's block root has been seen (via gossip or non-gossip sources)
    # (MAY be queued until block is retrieved)
    if block_root not in store.blocks:
        raise GossipIgnore("envelope's block has not been seen")

    # [REJECT] The envelope's block passes validation
    if block_root not in store.block_states:
        raise GossipReject("envelope's block failed validation")

    state = store.block_states[block_root]

    # [IGNORE] The envelope is from a slot greater than or equal to the latest finalized slot
    finalized_slot = compute_start_slot_at_epoch(store.finalized_checkpoint.epoch)
    if payload.slot_number < finalized_slot:
        raise GossipIgnore("envelope is from a slot before the latest finalized slot")

    block = store.blocks[block_root]
    bid = block.body.signed_execution_payload_bid.message

    # [REJECT] The block's slot matches the payload's slot number
    if block.slot != payload.slot_number:
        raise GossipReject("block's slot does not match payload's slot number")

    # [REJECT] The envelope's parent beacon block root matches the block's parent root
    if envelope.parent_beacon_block_root != block.parent_root:
        raise GossipReject("envelope's parent beacon block root does not match the block's")

    # [REJECT] The envelope is from the builder committed to by the bid
    if envelope.builder_index != bid.builder_index:
        raise GossipReject("envelope's builder index does not match the bid's builder index")

    # [REJECT] The payload's previous randao matches the bid's previous randao
    if payload.prev_randao != bid.prev_randao:
        raise GossipReject("payload's previous randao does not match the bid's previous randao")

    # [REJECT] The payload's gas limit matches the bid's gas limit
    if payload.gas_limit != bid.gas_limit:
        raise GossipReject("payload's gas limit does not match the bid's gas limit")

    # [REJECT] The payload's block hash matches the bid's block hash
    if payload.block_hash != bid.block_hash:
        raise GossipReject("payload's block hash does not match the bid's block hash")

    # [REJECT] The envelope's execution requests root matches the bid's execution requests root
    if hash_tree_root(envelope.execution_requests) != bid.execution_requests_root:
        raise GossipReject("envelope's execution requests root does not match the bid's")

    # [REJECT] The execution request counts are within their limits
    verify_execution_requests_limits(envelope.execution_requests)

    # [REJECT] The number of withdrawals is within the limit
    if len(payload.withdrawals) > MAX_WITHDRAWALS_PER_PAYLOAD:
        raise GossipReject("too many withdrawals")

    # [REJECT] The payload builds on the execution head of the block's post-state
    if payload.parent_hash != state.latest_block_hash:
        raise GossipReject("payload's parent hash does not match the latest block hash")

    # [REJECT] The payload's timestamp is correct with respect to the slot
    if payload.timestamp != compute_time_at_slot(state.genesis_time, block.slot):
        raise GossipReject("incorrect execution payload timestamp")

    # [REJECT] The payload contains no empty transactions
    if any(len(transaction) == 0 for transaction in payload.transactions):
        raise GossipReject("payload contains an empty transaction")

    # [REJECT] The payload's withdrawals match the withdrawals expected by the block's post-state
    if hash_tree_root(payload.withdrawals) != hash_tree_root(state.payload_expected_withdrawals):
        raise GossipReject("payload's withdrawals do not match the expected withdrawals")

    # [REJECT] The envelope signature is valid
    if not verify_execution_payload_envelope_signature(state, signed_execution_payload_envelope):
        raise GossipReject("invalid envelope signature")

    # Mark this envelope as seen and store its payload
    seen.execution_payload_envelopes.add(envelope_key)
    seen.execution_payloads[payload.block_hash] = payload
```

##### New `payload_attestation_message`

This topic is used to propagate signed payload attestation message.

```python
def validate_payload_attestation_message_gossip(
    seen: Seen,
    store: Store,
    payload_attestation_message: PayloadAttestationMessage,
    current_time_ms: Uint64,
) -> None:
    """
    Validate a PayloadAttestationMessage for gossip propagation.
    Raises GossipIgnore or GossipReject on validation failure.
    """
    data = payload_attestation_message.data
    validator_index = payload_attestation_message.validator_index

    # [REJECT] The payload attestation's slot is at or after the Gloas fork
    if compute_epoch_at_slot(data.slot) < GLOAS_FORK_EPOCH:
        raise GossipReject("payload attestation's slot is pre-gloas")

    # [IGNORE] This is the first valid payload attestation from this validator index
    payload_attestation_key = (data.slot, validator_index)
    if payload_attestation_key in seen.payload_attestation_validators:
        raise GossipIgnore("already seen payload attestation from this validator")

    # [IGNORE] The payload attestation's slot is for the current slot
    if not is_current_slot(store, data.slot, current_time_ms):
        raise GossipIgnore("payload attestation is not for the current slot")

    # [IGNORE] The payload attestation's block has been seen (via gossip or non-gossip sources)
    # (MAY be queued until block is retrieved)
    if data.beacon_block_root not in store.blocks:
        raise GossipIgnore("payload attestation's block has not been seen")

    # [REJECT] The payload attestation's block passes validation
    if data.beacon_block_root not in store.block_states:
        raise GossipReject("payload attestation's block failed validation")

    # [IGNORE] The payload attestation's block is at the assigned slot
    if store.blocks[data.beacon_block_root].slot != data.slot:
        raise GossipIgnore("payload attestation's block is not at the assigned slot")

    state = store.block_states[get_head(store).root]

    # [REJECT] The validator index is valid
    if validator_index >= len(state.validators):
        raise GossipReject("validator index out of range")

    # [REJECT] The validator is a member of the payload timeliness committee
    if validator_index not in get_ptc(state, data.slot):
        raise GossipReject("validator is not in the payload timeliness committee")

    # [REJECT] The signature is valid
    validator = state.validators[validator_index]
    domain = get_domain(state, DOMAIN_PTC_ATTESTER, compute_epoch_at_slot(data.slot))
    signing_root = compute_signing_root(data, domain)
    if not bls.Verify(validator.pubkey, signing_root, payload_attestation_message.signature):
        raise GossipReject("invalid payload attestation signature")

    # Mark this payload_attestation as seen
    seen.payload_attestation_validators.add(payload_attestation_key)
```

##### New `execution_payload_bid`

This topic is used to propagate signed bids as `SignedExecutionPayloadBid`.

*Note*: The proposer for `bid.slot` SHOULD consider higher-value bids from a
builder for its block regardless of how many bids it has already seen from that
builder for the same slot and parent. Otherwise, a builder could send low-value
bids to the proposer and a high-value bid to the rest of the network. Nodes that
accepted the high-value bid would not forward competing bids with lower values,
and the proposer would ignore the high-value bid, leaving it with only the
low-value bids. A bid past the builder's bid limit is still ignored for gossip,
so the proposer does not forward it.

```python
def validate_execution_payload_bid_gossip(
    seen: Seen,
    store: Store,
    signed_execution_payload_bid: SignedExecutionPayloadBid,
    current_time_ms: Uint64,
) -> None:
    """
    Validate a SignedExecutionPayloadBid for gossip propagation.
    Raises GossipIgnore or GossipReject on validation failure.
    """
    bid = signed_execution_payload_bid.message

    # [IGNORE] This is the highest value bid seen for the slot and parent
    best_bid_key = (bid.slot, bid.parent_block_hash, bid.parent_block_root)
    if best_bid_key in seen.best_execution_payload_bid:
        if bid.value <= seen.best_execution_payload_bid[best_bid_key]:
            raise GossipIgnore("bid is not the highest value bid seen for this slot and parent")

    # [IGNORE] The bid's slot is the current slot or the next slot
    if not is_current_or_next_slot(store, bid.slot, current_time_ms):
        raise GossipIgnore("bid's slot is not the current or next slot")

    # [REJECT] The bid's execution payment is zero
    if bid.execution_payment != 0:
        raise GossipReject("bid's execution payment must be zero")

    # [REJECT] The bid's block hash is not equal to its parent block hash
    if bid.block_hash == bid.parent_block_hash:
        raise GossipReject("bid's block hash equals its parent block hash")

    # [REJECT] The bid's blob KZG commitment count is within the per-epoch limit
    proposal_epoch = compute_epoch_at_slot(bid.slot)
    max_blobs = get_blob_parameters(proposal_epoch).max_blobs_per_block
    if len(bid.blob_kzg_commitments) > max_blobs:
        raise GossipReject("too many blob kzg commitments")

    # [IGNORE] The bid's parent block root is a known beacon block
    # (MAY be queued until parent is retrieved)
    if bid.parent_block_root not in store.blocks:
        raise GossipIgnore("bid's parent block root is not a known beacon block")

    # [REJECT] The bid is for a higher slot than its parent block
    if bid.slot <= store.blocks[bid.parent_block_root].slot:
        raise GossipReject("bid's slot is not higher than its parent's slot")

    # [IGNORE] The bid's parent block has been imported
    # (MAY be queued until parent is imported)
    if bid.parent_block_root not in store.block_states:
        raise GossipIgnore("bid's parent block post-state is unavailable")

    state = store.block_states[bid.parent_block_root]

    # [IGNORE] The bid's slot is within the parent's proposer lookahead
    if proposal_epoch > get_current_epoch(state) + MIN_SEED_LOOKAHEAD:
        raise GossipIgnore("bid's slot is past the parent's proposer lookahead")

    # [IGNORE] The matching proposer preferences have been seen
    dependent_root = get_shuffling_dependent_root(store, bid.parent_block_root, proposal_epoch)
    prefs_key = (bid.slot, dependent_root)
    if prefs_key not in seen.proposer_preferences:
        raise GossipIgnore("matching proposer preferences have not been seen")

    proposer_preferences = seen.proposer_preferences[prefs_key]

    # [IGNORE] The bid's fee recipient matches the proposer's preference
    if bid.fee_recipient != proposer_preferences.fee_recipient:
        raise GossipIgnore("bid's fee recipient does not match the proposer's preference")

    # [IGNORE] The bid's parent block hash is the hash of a known execution payload
    if bid.parent_block_hash not in seen.execution_payloads:
        raise GossipIgnore("bid's parent block hash is not a known execution payload")

    # [IGNORE] The bid's gas limit is compatible with the proposer's target gas limit
    parent_gas_limit = seen.execution_payloads[bid.parent_block_hash].gas_limit
    if not is_gas_limit_target_compatible(
        parent_gas_limit, bid.gas_limit, proposer_preferences.target_gas_limit
    ):
        raise GossipIgnore("bid's gas limit is not compatible with the proposer's target")

    # [IGNORE] The bid is compatible with the current head branch
    if not is_bid_compatible_with_head(store, bid):
        raise GossipIgnore("bid is not compatible with the current head branch")

    # [REJECT] The bid's previous randao is correct
    if bid.prev_randao != get_randao_mix(state, get_current_epoch(state)):
        raise GossipReject("bid's previous randao is incorrect")

    state = state.copy()
    process_slots(state, bid.slot)

    # [REJECT] The builder index is valid
    if bid.builder_index >= len(state.builders):
        raise GossipReject("builder index out of range")

    builder = state.builders[bid.builder_index]

    # [REJECT] The builder is a payload builder
    if builder.version != PAYLOAD_BUILDER_VERSION:
        raise GossipReject("builder is not a payload builder")

    # [REJECT] The builder is active
    if not is_active_builder(state, bid.builder_index):
        raise GossipReject("builder is not active")

    # [IGNORE] The builder has not reached its bid limit for this slot and parent
    bid_key = (bid.slot, bid.parent_block_hash, bid.parent_block_root, bid.builder_index)
    bid_limit = get_builder_bid_limit(state, bid.builder_index)
    if seen.execution_payload_bid_counts[bid_key] >= bid_limit:
        raise GossipIgnore("builder has reached its bid limit for this slot and parent")

    # [IGNORE] The builder can cover the bid
    if not can_builder_cover_bid(state, bid.builder_index, bid.value):
        raise GossipIgnore("builder cannot cover bid value")

    # [IGNORE] The parent's payload does not try to exit the builder
    if bid.parent_block_hash == state.latest_execution_payload_bid.block_hash:
        envelope = store.payloads[bid.parent_block_root]
        for request in envelope.execution_requests.builder_exits:
            if request.pubkey == builder.pubkey:
                if request.source_address == builder.execution_address:
                    raise GossipIgnore("builder may exit")

    # [REJECT] The bid signature is valid
    if not verify_execution_payload_bid_signature(state, signed_execution_payload_bid):
        raise GossipReject("invalid bid signature")

    # Count this bid and update the highest-value bid for this slot/parent
    seen.execution_payload_bid_counts[bid_key] += 1
    seen.best_execution_payload_bid[best_bid_key] = bid.value
```

*Note*: Implementations SHOULD include DoS prevention measures to mitigate spam
from malicious builders submitting numerous bids with minimal value increments.
Possible strategies include: (1) only forwarding bids that exceed the current
highest bid by a minimum threshold, or (2) forwarding only the highest observed
bid at regular time intervals.

##### New `proposer_preferences`

This topic is used to propagate signed proposer preferences as
`SignedProposerPreferences`. These messages allow validators to communicate
their preferred `fee_recipient` and `target_gas_limit` to builders.

*Note*: Nodes SHOULD subscribe to this topic at least one epoch before the fork
activation. Proposers SHOULD broadcast their preferences in the epoch before the
fork.

```python
def validate_proposer_preferences_gossip(
    seen: Seen,
    store: Store,
    signed_proposer_preferences: SignedProposerPreferences,
    current_time_ms: Uint64,
) -> None:
    """
    Validate a SignedProposerPreferences for gossip propagation.
    Raises GossipIgnore or GossipReject on validation failure.
    """
    preferences = signed_proposer_preferences.message

    # [IGNORE] These are the first valid preferences seen for this dependent root and slot
    prefs_key = (preferences.proposal_slot, preferences.dependent_root)
    if prefs_key in seen.proposer_preferences:
        raise GossipIgnore("already seen preferences for this dependent root and proposal slot")

    # [IGNORE] The proposal epoch is after the Gloas upgrade
    proposal_epoch = compute_epoch_at_slot(preferences.proposal_slot)
    if proposal_epoch < GLOAS_FORK_EPOCH:
        raise GossipIgnore("proposal epoch is pre-gloas")

    # [IGNORE] The proposal slot has not started yet
    if is_past_slot(store, preferences.proposal_slot, current_time_ms):
        raise GossipIgnore("proposal slot has already started")

    # [IGNORE] The proposer for the proposal slot is known
    lookahead_start_slot = compute_shuffling_lookahead_start_slot(proposal_epoch)
    if is_future_slot(store, lookahead_start_slot, current_time_ms):
        raise GossipIgnore("proposer for the proposal slot is not yet known")

    # [IGNORE] The dependent block has been seen (via gossip or non-gossip sources)
    # (MAY be queued until block is retrieved)
    if preferences.dependent_root not in store.blocks:
        raise GossipIgnore("dependent block has not been seen")

    # [IGNORE] The dependent block passes validation
    if preferences.dependent_root not in store.block_states:
        raise GossipIgnore("dependent block failed validation")

    # [REJECT] The dependent block's slot is not after the shuffling dependent slot
    dependent_slot = compute_shuffling_dependent_slot(proposal_epoch)
    if store.blocks[preferences.dependent_root].slot > dependent_slot:
        raise GossipReject("dependent block is after the shuffling dependent slot")

    # [IGNORE] The dependent block is a possible dependent block for the proposer lookahead
    if not is_valid_dependent_root(store, preferences.dependent_root, dependent_slot):
        raise GossipIgnore("dependent block is not a possible dependent block")

    state = store.block_states[preferences.dependent_root].copy()
    if state.slot < lookahead_start_slot:
        process_slots(state, lookahead_start_slot)

    # [REJECT] The validator is the proposer for the given slot in the proposer lookahead
    lookahead_index = preferences.proposal_slot - lookahead_start_slot
    if state.proposer_lookahead[lookahead_index] != preferences.validator_index:
        raise GossipReject("validator is not the proposer for the given slot")

    # [REJECT] The signature is valid
    validator = state.validators[preferences.validator_index]
    domain = compute_domain(
        DOMAIN_PROPOSER_PREFERENCES,
        compute_fork_version(proposal_epoch),
        state.genesis_validators_root,
    )
    signing_root = compute_signing_root(preferences, domain)
    if not bls.Verify(validator.pubkey, signing_root, signed_proposer_preferences.signature):
        raise GossipReject("invalid proposer preferences signature")

    # Mark these preferences as seen
    seen.proposer_preferences[prefs_key] = preferences
```

#### Attestation subnets

##### Modified `beacon_attestation_{subnet_id}`

*Note*: This function is modified per EIP-7732. `attestation.data.index` is now
restricted to `{0, 1}`, encoding whether the execution payload was present at
the slot. Same-slot attestations MUST attest with `index == 0`. Attestations
with `index == 1` require that the corresponding execution payload envelope has
been seen and passes execution-layer validation.

```python
def validate_beacon_attestation_gossip(
    seen: Seen,
    store: Store,
    attestation: SingleAttestation,
    current_time_ms: Uint64,
    subnet_id: SubnetID,
    # [New in Gloas:EIP7732]
    block_payload_statuses: dict[Root, PayloadValidationStatus],
) -> None:
    """
    Validate a SingleAttestation for gossip propagation on a subnet.
    Raises GossipIgnore or GossipReject on validation failure.
    """
    data = attestation.data
    committee_index = attestation.committee_index
    attester_index = attestation.attester_index
    target_epoch = data.target.epoch

    # [IGNORE] No other valid attestation seen for this target epoch and validator
    attestation_epoch_key = (target_epoch, attester_index)
    if attestation_epoch_key in seen.attestation_validator_epochs:
        raise GossipIgnore("already seen attestation for this epoch and validator")

    # [New in Gloas:EIP7732]
    # [REJECT] The attestation's data index is 0 or 1
    if data.index > 1:
        raise GossipReject("attestation data index must be 0 or 1")

    # [IGNORE] The block being voted for has been seen (via gossip or non-gossip sources)
    # (MAY be queued until block is retrieved)
    block_root = data.beacon_block_root
    if block_root not in store.blocks:
        raise GossipIgnore("block being voted for has not been seen")

    # [REJECT] The block being voted for passes validation
    if block_root not in store.block_states:
        raise GossipReject("block being voted for failed validation")

    state = store.block_states[get_head(store).root]

    # [REJECT] The committee index is within the expected range
    committees_per_slot = get_committee_count_per_slot(state, target_epoch)
    if committee_index >= committees_per_slot:
        raise GossipReject("committee index out of range")

    # [REJECT] The attestation is for the correct subnet
    expected_subnet = compute_subnet_for_attestation(
        committees_per_slot, data.slot, committee_index
    )
    if expected_subnet != subnet_id:
        raise GossipReject("attestation is for wrong subnet")

    # [IGNORE] The attestation's slot is not from a future slot
    # (MAY be queued for processing at the appropriate slot)
    if is_future_slot(store, data.slot, current_time_ms):
        raise GossipIgnore("attestation slot is from a future slot")

    # [IGNORE] The attestation's epoch is either the current or previous epoch
    attestation_epoch = compute_epoch_at_slot(data.slot)
    if not is_current_or_previous_epoch(store, attestation_epoch, current_time_ms):
        raise GossipIgnore("attestation epoch is not current or previous epoch")

    # [REJECT] The attestation's epoch matches its target
    if target_epoch != compute_epoch_at_slot(data.slot):
        raise GossipReject("attestation epoch does not match target epoch")

    # [REJECT] The attester is a member of the committee
    committee = get_beacon_committee(state, data.slot, committee_index)
    if attester_index not in committee:
        raise GossipReject("attester is not a member of the committee")

    # [REJECT] The attestation signature is valid
    attester = state.validators[attester_index]
    domain = get_domain(state, DOMAIN_BEACON_ATTESTER, target_epoch)
    signing_root = compute_signing_root(data, domain)
    if not bls.Verify(attester.pubkey, signing_root, attestation.signature):
        raise GossipReject("invalid attestation signature")

    # [REJECT] The attestation's target block is an ancestor of the LMD vote block
    target_checkpoint_block = get_checkpoint_block(store, block_root, target_epoch)
    if target_checkpoint_block != data.target.root:
        raise GossipReject("target block is not an ancestor of LMD vote block")

    # [IGNORE] The current finalized checkpoint is an ancestor of the block
    finalized_epoch = store.finalized_checkpoint.epoch
    finalized_checkpoint_block = get_checkpoint_block(store, block_root, finalized_epoch)
    if finalized_checkpoint_block != store.finalized_checkpoint.root:
        raise GossipIgnore("finalized checkpoint is not an ancestor of block")

    # [New in Gloas:EIP7732]
    # The attested payload status is consistent with the block's execution payload
    verify_attestation_payload_status(store, data, block_payload_statuses)

    # Mark this attestation as seen
    seen.attestation_validator_epochs.add(attestation_epoch_key)
```

#### Blob subnets

##### Modified `data_column_sidecar_{subnet_id}`

The KZG commitments needed to verify a sidecar are now carried by the bid at
`block.body.signed_execution_payload_bid.message.blob_kzg_commitments`, where
`block` is the `BeaconBlock` with root `sidecar.beacon_block_root`.

*Note*: If the sidecar fails deferred validation, its forwarding peers MUST be
downscored retroactively. If validation succeeds, the client MUST re-broadcast
the sidecar.

```python
def validate_data_column_sidecar_gossip(
    seen: Seen,
    store: Store,
    sidecar: DataColumnSidecar,
    current_time_ms: Uint64,
    subnet_id: SubnetID,
) -> None:
    """
    Validate a DataColumnSidecar for gossip propagation on a subnet.
    Raises GossipIgnore or GossipReject on validation failure.
    """
    # [IGNORE] This is the first sidecar seen for this block root and column index
    sidecar_key = (sidecar.beacon_block_root, sidecar.index)
    if sidecar_key in seen.data_column_sidecar_tuples:
        raise GossipIgnore("already seen sidecar for this block root and index")

    # [REJECT] The sidecar is for the correct subnet
    if compute_subnet_for_data_column_sidecar(sidecar.index) != subnet_id:
        raise GossipReject("sidecar is for wrong subnet")

    # [IGNORE] The sidecar is not from a future slot
    # (MAY be queued for processing at the appropriate slot)
    if is_future_slot(store, sidecar.slot, current_time_ms):
        raise GossipIgnore("sidecar is from a future slot")

    # [IGNORE] A block for the sidecar has been seen (via gossip or non-gossip sources)
    # (MAY be queued until block is retrieved)
    # (SHOULD queue at least one sidecar per peer per subnet)
    if sidecar.beacon_block_root not in store.blocks:
        raise GossipIgnore("block for sidecar's beacon block root has not been seen")

    # [REJECT] The block for the sidecar passes validation
    if sidecar.beacon_block_root not in store.block_states:
        raise GossipReject("block for sidecar's beacon block root failed validation")

    block = store.blocks[sidecar.beacon_block_root]

    # [REJECT] The sidecar's slot matches the slot of the block
    if sidecar.slot != block.slot:
        raise GossipReject("sidecar's slot does not match block's slot")

    bid = block.body.signed_execution_payload_bid.message

    # [REJECT] The sidecar passes structural validation
    if not verify_data_column_sidecar(sidecar, bid.blob_kzg_commitments):
        raise GossipReject("invalid sidecar")

    # [REJECT] The sidecar's column data passes KZG verification
    if not verify_data_column_sidecar_kzg_proofs(sidecar, bid.blob_kzg_commitments):
        raise GossipReject("invalid sidecar kzg proofs")

    # Mark this data column sidecar as seen
    seen.data_column_sidecar_tuples.add(sidecar_key)
```

## The Req/Resp domain

### Messages

#### BeaconBlocksByRange v2

**Protocol ID:** `/eth2/beacon_chain/req/beacon_blocks_by_range/2/`

The Gloas fork-digest is introduced to the `context` enum to specify Gloas
beacon block type.

<!-- eth_consensus_specs: skip -->

| `fork_version`           | Chunk SSZ type                |
| ------------------------ | ----------------------------- |
| `GENESIS_FORK_VERSION`   | `phase0.SignedBeaconBlock`    |
| `ALTAIR_FORK_VERSION`    | `altair.SignedBeaconBlock`    |
| `BELLATRIX_FORK_VERSION` | `bellatrix.SignedBeaconBlock` |
| `CAPELLA_FORK_VERSION`   | `capella.SignedBeaconBlock`   |
| `DENEB_FORK_VERSION`     | `deneb.SignedBeaconBlock`     |
| `ELECTRA_FORK_VERSION`   | `electra.SignedBeaconBlock`   |
| `FULU_FORK_VERSION`      | `fulu.SignedBeaconBlock`      |
| `GLOAS_FORK_VERSION`     | `gloas.SignedBeaconBlock`     |

#### BeaconBlocksByRoot v2

**Protocol ID:** `/eth2/beacon_chain/req/beacon_blocks_by_root/2/`

The Gloas fork-digest is introduced to the `context` enum to specify Gloas
beacon block type.

<!-- eth_consensus_specs: skip -->

| `fork_version`           | Chunk SSZ type                |
| ------------------------ | ----------------------------- |
| `GENESIS_FORK_VERSION`   | `phase0.SignedBeaconBlock`    |
| `ALTAIR_FORK_VERSION`    | `altair.SignedBeaconBlock`    |
| `BELLATRIX_FORK_VERSION` | `bellatrix.SignedBeaconBlock` |
| `CAPELLA_FORK_VERSION`   | `capella.SignedBeaconBlock`   |
| `DENEB_FORK_VERSION`     | `deneb.SignedBeaconBlock`     |
| `ELECTRA_FORK_VERSION`   | `electra.SignedBeaconBlock`   |
| `FULU_FORK_VERSION`      | `fulu.SignedBeaconBlock`      |
| `GLOAS_FORK_VERSION`     | `gloas.SignedBeaconBlock`     |

#### ExecutionPayloadEnvelopesByRange v1

**Protocol ID:**
`/eth2/beacon_chain/req/execution_payload_envelopes_by_range/1/`

Request Content:

```
(
  start_slot: Slot
  count: Uint64
)
```

Response Content:

```
(
  SignedExecutionPayloadEnvelopes
)
```

Specifications of request/response methods are equivalent to
[BeaconBlocksByRange v2](#beaconblocksbyrange-v2), with the only difference
being the response content type.

Clients MUST respond with execution payload envelopes from their view of the
current fork choice -- that is, envelopes of payloads that are part of the
single chain defined by the current head. A payload is part of that chain if the
next block in the chain builds on it, i.e. the `parent_block_hash` of that
block's execution payload bid equals the `block_hash` of the payload. For the
head block, the payload is part of the chain if the head `ForkChoiceNode` has
`payload_status` equal to `PAYLOAD_STATUS_FULL`. Clients MUST NOT include
envelopes for blocks whose `ForkChoiceNode` in that chain has `payload_status`
equal to `PAYLOAD_STATUS_EMPTY`. For slots before the finalization, that chain
leads to the finalized block reported in the `Status` handshake.

For each successful `response_chunk`, the `ForkDigest` context epoch is
determined by `compute_epoch_at_slot(beacon_block.slot)` based on the
`beacon_block` referred to by
`signed_execution_payload_envelope.message.beacon_block_root`.

Per `fork_version = compute_fork_version(epoch)`:

<!-- eth_consensus_specs: skip -->

| `fork_version`       | Chunk SSZ type                         |
| -------------------- | -------------------------------------- |
| `GLOAS_FORK_VERSION` | `gloas.SignedExecutionPayloadEnvelope` |

#### ExecutionPayloadEnvelopesByRoot v1

**Protocol ID:** `/eth2/beacon_chain/req/execution_payload_envelopes_by_root/1/`

Request Content:

```
(
  ExecutionPayloadEnvelopeRoots
)
```

Response Content:

```
(
  SignedExecutionPayloadEnvelopes
)
```

Requests execution payload envelopes by
`signed_execution_payload_envelope.message.beacon_block_root`. The response is a
list of `SignedExecutionPayloadEnvelope` whose length is less than or equal to
the number of requested execution payload envelopes. It may be less in the case
that the responding peer is missing payload envelopes.

No more than `MAX_REQUEST_PAYLOADS` may be requested at a time.

ExecutionPayloadEnvelopesByRoot is primarily used to recover recent execution
payload envelopes and attestations (e.g. when receiving a payload attestation or
attestation with revealed status as true but never received a payload).

The request MUST be encoded as an SSZ-field.

The response MUST consist of zero or more `response_chunk`. Each successful
`response_chunk` MUST contain a single `SignedExecutionPayloadEnvelope` payload.

Clients MUST support requesting payload envelopes on the epoch range
`[max(GLOAS_FORK_EPOCH, current_epoch - compute_min_epochs_for_block_requests()), current_epoch]`.
If any root in the request content references a block earlier than this range,
peers MAY respond with error code `3: ResourceUnavailable` or not include the
payload envelope in the response.

*Note*: Clients MUST also keep a record of all payload envelopes more recent
than their latest finalized checkpoint and MUST support serving requests of
these payload envelopes, even if outside of this range.

Clients MUST respond with at least one payload envelope, if they have it.
Clients MAY limit the number of payload envelopes in the response.

For each successful `response_chunk`, the `ForkDigest` context epoch is
determined by `compute_epoch_at_slot(beacon_block.slot)` based on the
`beacon_block` referred to by
`signed_execution_payload_envelope.message.beacon_block_root`.

Per `fork_version = compute_fork_version(epoch)`:

<!-- eth_consensus_specs: skip -->

| `fork_version`       | Chunk SSZ type                         |
| -------------------- | -------------------------------------- |
| `GLOAS_FORK_VERSION` | `gloas.SignedExecutionPayloadEnvelope` |
