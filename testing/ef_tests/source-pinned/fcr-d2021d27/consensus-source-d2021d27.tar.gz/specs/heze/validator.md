# Heze -- Honest Validator

*Note*: This document is a work-in-progress for researchers and implementers.

<!-- mdformat-toc start --slug=github --no-anchors --maxlevel=6 --minlevel=2 -->

- [Introduction](#introduction)
- [Configs](#configs)
- [Helpers](#helpers)
  - [New `GetInclusionListResponse`](#new-getinclusionlistresponse)
- [Protocols](#protocols)
  - [`ExecutionEngine`](#executionengine)
    - [New `get_inclusion_list`](#new-get_inclusion_list)
- [Validator assignments](#validator-assignments)
  - [Inclusion list committee](#inclusion-list-committee)
  - [Lookahead](#lookahead)
- [Beacon chain responsibilities](#beacon-chain-responsibilities)
  - [Block and sidecar proposal](#block-and-sidecar-proposal)
    - [Constructing the `BeaconBlockBody`](#constructing-the-beaconblockbody)
      - [Eth1 data](#eth1-data)
      - [Deposits](#deposits)
      - [Signed execution payload bid](#signed-execution-payload-bid)
      - [ExecutionPayload](#executionpayload)
  - [Inclusion list proposal](#inclusion-list-proposal)
    - [Constructing the `SignedInclusionList`](#constructing-the-signedinclusionlist)

<!-- mdformat-toc end -->

## Introduction

This document represents the changes to be made in the code of an "honest
validator" to implement Heze.

## Configs

## Helpers

### New `GetInclusionListResponse`

```python
@dataclass
class GetInclusionListResponse:
    inclusion_list_transactions: Sequence[Transaction]
```

## Protocols

### `ExecutionEngine`

*Note*: The `get_inclusion_list` function is added to the `ExecutionEngine`
protocol for use as an inclusion list committee member.

The body of this function is implementation dependent. The Engine API may be
used to implement it with an external execution engine.

#### New `get_inclusion_list`

*Note*: `get_inclusion_list` returns `GetInclusionListResponse` with the most
recent inclusion list transactions that has been built based on the latest view
of the public mempool.

```python
def get_inclusion_list(self: ExecutionEngine) -> GetInclusionListResponse:
    """
    Return inclusion list transactions (as Sequence[Transaction]) object.
    """
```

## Validator assignments

### Inclusion list committee

A validator may be a member of the new inclusion list committee for a given
slot. To check for inclusion list committee assignments, use
`get_inclusion_list_committee_assignment(state, epoch, validator_index)` where
`epoch <= next_epoch`, as inclusion list committee selection is only stable
within the context of the current and next epoch.

```python
def get_inclusion_list_committee_assignment(
    state: BeaconState, epoch: Epoch, validator_index: ValidatorIndex
) -> Slot | None:
    """
    Returns the slot during the requested epoch in which the validator with
    index ``validator_index`` is a member of the inclusion list committee.
    Returns None if no assignment is found.
    """
    next_epoch = get_current_epoch(state) + 1
    assert epoch <= next_epoch

    start_slot = compute_start_slot_at_epoch(epoch)
    for slot in range(start_slot, start_slot + SLOTS_PER_EPOCH):
        if validator_index in get_inclusion_list_committee(state, Slot(slot)):
            return Slot(slot)
    return None
```

### Lookahead

`get_inclusion_list_committee_assignment` should be called at the start of each
epoch to get the assignment for the next epoch (`current_epoch + 1`). A
validator should plan for future assignments by noting their assigned inclusion
list committee slot.

## Beacon chain responsibilities

All validator responsibilities remain unchanged other than those noted below.

### Block and sidecar proposal

#### Constructing the `BeaconBlockBody`

##### Eth1 data

*[Modified in Heze:EIP8015]*

*Note*: The `eth1_data` field is removed from `BeaconBlockBody`.

##### Deposits

*[Modified in Heze:EIP8015]*

*Note*: The `deposits` field is removed from `BeaconBlockBody`.

##### Signed execution payload bid

*Note*: The only change made to `signed_execution_payload_bid` is to require
that `bid.inclusion_list_bits` must satisfy `is_inclusion_list_bits_inclusive()`
with respect to the proposer's inclusion list view, which comprises all valid
and non-equivocating inclusion lists they have observed.

- The `bid.inclusion_list_bits` must satisfy
  `is_inclusion_list_bits_inclusive(get_inclusion_list_store(), inclusion_list_committee, slot, dependent_root, bid.inclusion_list_bits, only_timely=False)`,
  where `inclusion_list_committee` is
  `get_inclusion_list_committee(state, slot)`, `slot` is `bid.slot - 1`,
  `dependent_root` is
  `get_shuffling_dependent_root(store, bid.parent_block_root, compute_epoch_at_slot(slot))`,
  and `store` is the fork choice store.

##### ExecutionPayload

`prepare_execution_payload` is updated from the Gloas specification to provide
the inclusion list transactions.

*Note*: In this section, `state` is the state of the slot for the block proposal
_without_ the block yet applied. That is, `state` is the `previous_state`
processed through any empty slots up to the assigned slot using
`process_slots(previous_state, slot)`.

*Note*: A proposer should produce an execution payload that satisfies the
inclusion list constraints with respect to their inclusion list view at the time
of payload construction, which comprises all valid and non-equivocating
inclusion lists they have observed.

```python
def prepare_execution_payload(
    store: Store,
    head: ForkChoiceNode,
    state: BeaconState,
    safe_block_hash: Hash32,
    finalized_block_hash: Hash32,
    suggested_fee_recipient: ExecutionAddress,
    target_gas_limit: Uint64,
    execution_engine: ExecutionEngine,
) -> PayloadId | None:
    parent_bid = state.latest_execution_payload_bid
    if should_build_on_full(store, head, state.slot):
        envelope = store.payloads[head.root]
        # Make a copy of the state to avoid mutability issues
        state = state.copy()
        # Apply parent payload before computing withdrawals
        apply_parent_execution_payload(state, envelope.execution_requests)
        withdrawals = get_expected_withdrawals(state).withdrawals
        head_block_hash = parent_bid.block_hash
    else:
        withdrawals = state.payload_expected_withdrawals
        head_block_hash = parent_bid.parent_block_hash

    # Set the forkchoice head and initiate the payload build process
    payload_attributes = PayloadAttributes(
        timestamp=compute_time_at_slot(state.genesis_time, state.slot),
        prev_randao=get_randao_mix(state, get_current_epoch(state)),
        suggested_fee_recipient=suggested_fee_recipient,
        withdrawals=withdrawals,
        parent_beacon_block_root=hash_tree_root(state.latest_block_header),
        slot_number=state.slot,
        target_gas_limit=target_gas_limit,
        # [New in Heze:EIP7805]
        inclusion_list_transactions=get_inclusion_list_transactions(
            get_inclusion_list_store(),
            state.slot - 1,
            get_shuffling_dependent_root(store, head.root, compute_epoch_at_slot(state.slot - 1)),
            only_timely=False,
        ),
    )
    return execution_engine.notify_forkchoice_updated(
        head_block_hash=head_block_hash,
        safe_block_hash=safe_block_hash,
        finalized_block_hash=finalized_block_hash,
        payload_attributes=payload_attributes,
        custody_columns=None,
    )
```

### Inclusion list proposal

A validator is expected to propose a
[`SignedInclusionList`](./beacon-chain.md#signedinclusionlist) during any `slot`
for which
`get_inclusion_list_committee_assignment(state, epoch, validator_index)`
returns.

If a validator is in the current inclusion list committee, the validator should
create and broadcast the `signed_inclusion_list` to the global `inclusion_list`
subnet by `get_inclusion_list_due_ms()` milliseconds into the slot, built
against the block for the current slot if it has been processed and confirmed as
head, or against the local head returned by `get_head()` otherwise.

#### Constructing the `SignedInclusionList`

A validator constructs the `signed_inclusion_list` with
`get_signed_inclusion_list` for the assigned `slot` returned by
`get_inclusion_list_committee_assignment`. Let `head_root` be the validator's
current head root and `inclusion_list_transactions` be the inclusion list
transactions obtained from `ExecutionEngine` via `get_inclusion_list`.

```python
def get_inclusion_list_signature(
    state: BeaconState, inclusion_list: InclusionList, privkey: int
) -> BLSSignature:
    domain = compute_domain(
        DOMAIN_INCLUSION_LIST_COMMITTEE,
        compute_fork_version(compute_epoch_at_slot(inclusion_list.slot)),
        state.genesis_validators_root,
    )
    signing_root = compute_signing_root(inclusion_list, domain)
    return bls.Sign(privkey, signing_root)
```

```python
def get_signed_inclusion_list(
    store: Store,
    state: BeaconState,
    head_root: Root,
    slot: Slot,
    validator_index: ValidatorIndex,
    inclusion_list_transactions: Sequence[Transaction],
    privkey: int,
) -> SignedInclusionList:
    inclusion_list = InclusionList(
        slot=slot,
        validator_index=validator_index,
        dependent_root=get_shuffling_dependent_root(store, head_root, compute_epoch_at_slot(slot)),
        transactions=Transactions(data=inclusion_list_transactions),
    )
    signature = get_inclusion_list_signature(state, inclusion_list, privkey)
    return SignedInclusionList(message=inclusion_list, signature=signature)
```
